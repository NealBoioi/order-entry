' Double-click to launch the NEW PHP Order Entry app (with login) on port 8000.
' Silently starts MariaDB + the PHP web server via run-dev.ps1, then opens the
' login page in your browser. Portable: finds run-dev.ps1 next to this file.
Dim fso, shell, here
Set fso  = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
here = fso.GetParentFolderName(WScript.ScriptFullName)
shell.Run "powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & here & "\run-dev.ps1""", 0, False
