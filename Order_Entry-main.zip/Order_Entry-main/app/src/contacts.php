<?php
// Contact directory — plant contacts (routing targets) + branch directory.
// Admin-editable; customers view read-only. Backs the Contact page and email routing.
require_once __DIR__ . '/db.php';

// Plants (from the orgs reference) LEFT JOINed with their editable contact, so a newly
// added org shows up with blank contact fields ready to fill in.
function list_plants_with_contacts(): array
{
    return db()->query(
        'SELECT o.inventory_org, o.plant_code, o.name AS plant_name,
                c.contact_name, c.contact_email, c.contact_phone
         FROM orgs o
         LEFT JOIN plant_contacts c ON c.inventory_org = o.inventory_org
         ORDER BY o.name'
    )->fetchAll();
}

// Upsert a plant contact by inventory_org. Returns [true, null] or [false, message].
function save_plant_contact(string $org, ?string $name, ?string $email, ?string $phone): array
{
    $org = trim($org);
    if ($org === '') return [false, 'Missing plant.'];
    $email = trim((string) $email);
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return [false, 'Enter a valid contact email (or leave it blank).'];
    }
    // Positional placeholders + VALUES(col): native prepares forbid reusing a named
    // placeholder, and VALUES() re-uses the inserted value in the UPDATE branch.
    db()->prepare(
        'INSERT INTO plant_contacts (inventory_org, contact_name, contact_email, contact_phone)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
             contact_name  = VALUES(contact_name),
             contact_email = VALUES(contact_email),
             contact_phone = VALUES(contact_phone)'
    )->execute([
        $org,
        trim((string) $name) ?: null,
        $email ?: null,
        trim((string) $phone) ?: null,
    ]);
    return [true, null];
}

// --- Branch directory --------------------------------------------------------
function list_branches(): array
{
    return db()->query(
        'SELECT b.branch, b.name, b.default_org, b.contact_name, b.contact_email, b.contact_phone,
                o.name AS plant_name
         FROM branches b
         LEFT JOIN orgs o ON o.inventory_org = b.default_org
         ORDER BY b.branch'
    )->fetchAll();
}

function get_branch(string $branch): ?array
{
    $st = db()->prepare('SELECT * FROM branches WHERE branch = ?');
    $st->execute([$branch]);
    return $st->fetch() ?: null;
}

// Upsert a branch by 4-digit code. Returns [true, null] or [false, message].
function save_branch(string $branch, ?string $name, ?string $defaultOrg, ?string $cName, ?string $cEmail, ?string $cPhone): array
{
    $branch = trim($branch);
    if (!preg_match('/^\d{4}$/', $branch)) return [false, 'Branch # must be exactly 4 digits.'];
    $cEmail = trim((string) $cEmail);
    if ($cEmail !== '' && !filter_var($cEmail, FILTER_VALIDATE_EMAIL)) {
        return [false, 'Enter a valid contact email (or leave it blank).'];
    }
    $defaultOrg = trim((string) $defaultOrg) ?: null;
    db()->prepare(
        'INSERT INTO branches (branch, name, default_org, contact_name, contact_email, contact_phone)
         VALUES (?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
             name          = VALUES(name),
             default_org   = VALUES(default_org),
             contact_name  = VALUES(contact_name),
             contact_email = VALUES(contact_email),
             contact_phone = VALUES(contact_phone)'
    )->execute([
        $branch,
        trim((string) $name) ?: null,
        $defaultOrg,
        trim((string) $cName) ?: null,
        $cEmail ?: null,
        trim((string) $cPhone) ?: null,
    ]);
    return [true, null];
}

function delete_branch(string $branch): void
{
    db()->prepare('DELETE FROM branches WHERE branch = ?')->execute([$branch]);
}

// --- Program Assignments (the Contact List page) -----------------------------
// The plant's customer contact list. Admin-editable; sales/customers read-only, and the
// plant_order_inbox column is only shown to admins (gated in the page, not here).

// List assignments, with an optional case-insensitive filter across the searchable columns.
function list_program_assignments(string $q = ''): array
{
    $q = trim($q);
    $sql = 'SELECT * FROM program_assignments';
    $params = [];
    if ($q !== '') {
        $like = '%' . $q . '%';
        $sql .= ' WHERE customer LIKE ? OR sales_contact LIKE ? OR sales_branch LIKE ? OR pm LIKE ? OR bdm LIKE ?';
        $params = [$like, $like, $like, $like, $like];
    }
    $sql .= ' ORDER BY sort_order, customer, id';
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function get_program_assignment(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM program_assignments WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

// Insert (id null/0) or update a program assignment. Returns [true, null] or [false, message].
// Customer resolution is canonical-only: either the posted name must already exist in the
// `customers` picklist (case-insensitive), or the admin explicitly checked "new customer" —
// in which case it's added to `customers` (or reused if it already matches) before saving.
function save_program_assignment(?int $id, array $post): array
{
    if (!empty($post['is_new_customer'])) {
        $raw = trim($post['new_customer_name'] ?? '');
        if ($raw === '') return [false, 'Enter the new customer name.'];
        $customer = get_or_create_customer($raw);
    } else {
        $raw = trim($post['customer'] ?? '');
        if ($raw === '') return [false, 'Customer is required.'];
        if (!customer_exists($raw)) {
            return [false, 'Unrecognized customer "' . $raw . '" — pick one from the list, or check “add new customer.”'];
        }
        $customer = canonical_customer_name($raw) ?? $raw;
    }
    $inbox = trim($post['plant_order_inbox'] ?? '');
    if ($inbox !== '' && !filter_var($inbox, FILTER_VALIDATE_EMAIL)) {
        return [false, 'Plant Order Inbox must be a valid email (or left blank).'];
    }
    $vals = [
        $customer,
        trim($post['pm'] ?? '') ?: null,
        $inbox ?: null,
        trim($post['plant_site'] ?? '') ?: null,
        trim($post['sales_contact'] ?? '') ?: null,
        trim($post['sales_branch'] ?? '') ?: null,
        trim($post['bdm'] ?? '') ?: null,
    ];
    if ($id) {
        $vals[] = $id;
        db()->prepare(
            'UPDATE program_assignments SET customer=?, pm=?, plant_order_inbox=?, plant_site=?,
                    sales_contact=?, sales_branch=?, bdm=? WHERE id=?'
        )->execute($vals);
    } else {
        $so = (int) db()->query('SELECT COALESCE(MAX(sort_order),0)+1 FROM program_assignments')->fetchColumn();
        $vals[] = $so;
        db()->prepare(
            'INSERT INTO program_assignments
                (customer, pm, plant_order_inbox, plant_site, sales_contact, sales_branch, bdm, sort_order)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute($vals);
    }
    return [true, null];
}

function delete_program_assignment(int $id): void
{
    db()->prepare('DELETE FROM program_assignments WHERE id = ?')->execute([$id]);
}

// --- Canonical customers picklist (§26 follow-up) -----------------------------
// Backs the Customer field on the add/edit form so duplicate spellings of the same
// customer (TKE / ThyssenKrupp / TkE) don't pile up. `customers.name` has a UNIQUE key
// under the DB's case-insensitive collation, so lookups/inserts naturally collide on
// case-only differences; genuinely different spellings still need a human to pick the
// right one from the list (that's what the search/datalist + explicit "add new" is for).

// All canonical names, alphabetical — small table (~100s of rows), fine to load whole
// for a browser-native <datalist> type-ahead (no AJAX endpoint needed).
function list_customers(): array
{
    return db()->query('SELECT name FROM customers ORDER BY name')->fetchAll(PDO::FETCH_COLUMN);
}

// Case-insensitive existence check against the canonical list.
function customer_exists(string $name): bool
{
    $name = trim($name);
    if ($name === '') return false;
    $st = db()->prepare('SELECT COUNT(*) FROM customers WHERE name = ?');
    $st->execute([$name]);
    return (int) $st->fetchColumn() > 0;
}

// Resolve a (possibly differently-cased) name to the exact string stored in `customers`,
// or null if there's no match.
function canonical_customer_name(string $name): ?string
{
    $st = db()->prepare('SELECT name FROM customers WHERE name = ? LIMIT 1');
    $st->execute([trim($name)]);
    $v = $st->fetchColumn();
    return $v === false ? null : $v;
}

// Add a new canonical customer, or — if a case-insensitive match already exists — reuse
// it instead of creating a near-duplicate. Returns the canonical stored name either way.
function get_or_create_customer(string $name): string
{
    $name = trim($name);
    db()->prepare('INSERT IGNORE INTO customers (name) VALUES (?)')->execute([$name]);
    return canonical_customer_name($name) ?? $name;
}
