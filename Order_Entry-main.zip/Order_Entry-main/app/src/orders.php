<?php
// Site order entry — cart (session) + persistence helpers.
//   - The cart lives in $_SESSION until the user submits; only then is a row written.
//   - Prices are resolved server-side (never trusted from the form) and SNAPSHOTTED
//     onto the order line, so later tier/price changes don't rewrite history.
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/pricing.php';

// Plant/org options for the plant selector: [inventory_org => label].
function org_options(): array
{
    $rows = db()->query('SELECT inventory_org, name FROM orgs ORDER BY name')->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $out[$r['inventory_org']] = $r['name'] . ' (' . $r['inventory_org'] . ')';
    }
    return $out;
}

// Resolve a single item by exact item number. Customers are restricted to assemblies
// (WES-ETO) — mirrors the price-lookup rule so buy-item pricing never leaks to branches.
function find_item(string $itemNumber, string $role): ?array
{
    $sql = 'SELECT item_number, description, item_type, list_price, primary_uom FROM items WHERE item_number = ?';
    if ($role !== 'admin') $sql .= " AND item_type = 'WES-ETO'";
    $st = db()->prepare($sql . ' LIMIT 1');
    $st->execute([$itemNumber]);
    return $st->fetch() ?: null;
}

// Price snapshot for an item at a qty. Returns ['unit_price' => float|null, 'source' => string].
// Pricing switch (Batch 2): assembly (WES-ETO) items now price from the QUOTING module first —
// quote_transfer_price() finds the most recent quote for the part that carries Quote Summary
// tiers and picks the tier whose build_qty is the largest <= qty (or the smallest tier if qty
// is below all of them), returning that tier's transfer_price. ONLY when no quote exists yet
// for the part does this fall back to the legacy admin Tiered Pricing table (assembly_price(),
// app/src/pricing.php) — this keeps existing items priced the old way until someone quotes
// them, per the transition plan. Buy-item (WES-PUR-RE) pricing is unchanged (Oracle list_price).
function price_for_item(array $item, int $qty): array
{
    if (($item['item_type'] ?? '') === 'WES-ETO') {
        $q = quote_transfer_price($item['item_number'], $qty);
        if ($q) {
            // Kept short so it fits site_order_lines.price_source VARCHAR(20) and still
            // traces back to the exact quote (see price_source_label() for the on-screen hint).
            return ['unit_price' => $q['unit_price'], 'source' => 'quote:' . $q['quote_number']];
        }
        $p = assembly_price($item['item_number'], $qty);
        return $p
            ? ['unit_price' => (float) $p['unit_price'], 'source' => 'legacy-tier']
            : ['unit_price' => null, 'source' => 'none'];
    }
    if (($item['item_type'] ?? '') === 'WES-PUR-RE' && $item['list_price'] !== null && $item['list_price'] !== '') {
        return ['unit_price' => (float) $item['list_price'], 'source' => 'oracle-list'];
    }
    return ['unit_price' => null, 'source' => 'none'];
}

// Friendly on-screen label for a price_source value (see price_for_item()) — traces an
// assembly's new-order price back to "quote Q-2026-0001" vs the legacy tier table, per the
// Batch 2 pricing-switch spec. Pure display helper; doesn't change what's stored.
function price_source_label(?string $source): ?string
{
    $source = (string) $source;
    if ($source === '' || $source === 'none') return null;
    if (str_starts_with($source, 'quote:')) {
        $qn = substr($source, 6);
        return $qn !== '' ? 'quote ' . $qn : 'quote';
    }
    if ($source === 'legacy-tier') return 'legacy tier';
    if ($source === 'oracle-list') return 'Oracle list price';
    return $source;
}

// --- Session cart (a list of line arrays) -----------------------------------
function &cart(): array
{
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) $_SESSION['cart'] = [];
    return $_SESSION['cart'];
}

function cart_add(array $line): void   { $c =& cart(); $c[] = $line; }
function cart_remove(int $i): void     { $c =& cart(); if (isset($c[$i])) { array_splice($c, $i, 1); } }
function cart_clear(): void            { $_SESSION['cart'] = []; }

// Cart total, ignoring lines with no resolved price.
function cart_total(): float
{
    $t = 0.0;
    foreach (cart() as $l) {
        if ($l['unit_price'] !== null) $t += $l['unit_price'] * $l['quantity'];
    }
    return $t;
}

// --- Persistence -------------------------------------------------------------
// Writes the header + lines in one transaction. Returns the new order id.
function create_site_order(int $userId, string $branch, string $org, string $po, ?string $notes, array $lines, ?string $shipTo = null, ?string $billTo = null, ?string $shipMethod = null, ?string $requestedDeliveryDate = null, bool $urgent = false, ?string $shipmentRef = null): int
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $pdo->prepare(
            'INSERT INTO site_orders (po_number, branch, inventory_org, notes, ship_to, bill_to, ship_method, requested_delivery_date, urgent, shipment_ref, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([$po, $branch, $org, $notes ?: null, $shipTo ?: null, $billTo ?: null, $shipMethod ?: null, $requestedDeliveryDate ?: null, $urgent ? 1 : 0, $shipmentRef ?: null, $userId]);
        $orderId = (int) $pdo->lastInsertId();

        $ins = $pdo->prepare(
            'INSERT INTO site_order_lines
               (order_id, item_number, description, item_type, uom, quantity, unit_price, price_source)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        foreach ($lines as $l) {
            $ins->execute([
                $orderId, $l['item_number'], $l['description'] ?? null, $l['item_type'] ?? null,
                $l['uom'] ?? null, $l['quantity'], $l['unit_price'], $l['price_source'] ?? 'none',
            ]);
        }
        $pdo->commit();
        return $orderId;
    } catch (\Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// List portal-submitted orders (site_orders), newest first, with line count + total.
// $branch limits to one branch (customers); null = all branches (admins). $limit is
// inlined as an int because native prepares mis-bind a placeholder in LIMIT.
function list_site_orders(?string $branch, int $limit = 100): array
{
    $sql = 'SELECT o.id, o.po_number, o.branch, o.inventory_org, o.status, o.created_at,
                   g.name AS plant_name,
                   COUNT(l.id) AS line_count,
                   COALESCE(SUM(l.unit_price * l.quantity), 0) AS total
            FROM site_orders o
            LEFT JOIN orgs g ON g.inventory_org = o.inventory_org
            LEFT JOIN site_order_lines l ON l.order_id = o.id';
    $params = [];
    if ($branch !== null) { $sql .= ' WHERE o.branch = ?'; $params[] = $branch; }
    $sql .= ' GROUP BY o.id, o.po_number, o.branch, o.inventory_org, o.status, o.created_at, g.name
              ORDER BY o.created_at DESC, o.id DESC
              LIMIT ' . (int) $limit;
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

// Load an order header + lines. Returns ['order' => row, 'lines' => rows] or null.
function get_site_order(int $id): ?array
{
    $st = db()->prepare(
        'SELECT o.*, u.email AS created_by_email, g.name AS plant_name
         FROM site_orders o
         LEFT JOIN users u ON u.id = o.created_by
         LEFT JOIN orgs  g ON g.inventory_org = o.inventory_org
         WHERE o.id = ?'
    );
    $st->execute([$id]);
    $order = $st->fetch();
    if (!$order) return null;
    $ls = db()->prepare('SELECT * FROM site_order_lines WHERE order_id = ? ORDER BY id');
    $ls->execute([$id]);
    return ['order' => $order, 'lines' => $ls->fetchAll()];
}

// --- On-hand stock allocation (Order Search) ---------------------------------
// The plant's on-hand qty for an item (RG 'On Hand Qty', repeated on each of the item's
// order lines) is allocated to that item's OPEN orders in REQUEST-DATE order — soonest-due
// first consumes stock. So each line sees the pool that's left after all earlier-due orders
// took their share. Example: 400 on hand; a 25 due 7/22 then a 200 due 7/31 → the 200 line
// shows 375 available (400 − 25). Lines whose need exceeds what's left come up short.

// Parse a stored date string (M/D/YYYY, ISO, or D-Mon-YY) to a timestamp; blank/unparseable
// sort LAST (so undated orders never grab stock ahead of a real due date).
function order_date_ts(?string $s): int
{
    $s = trim((string) $s);
    if ($s === '') return PHP_INT_MAX;
    $t = strtotime($s);
    return $t === false ? PHP_INT_MAX : $t;
}

/**
 * Allocate on-hand stock across the OPEN order lines of each given item, by request date.
 * Returns a map keyed by order_line id → [
 *   'on_hand'      => item's total on-hand (null if not imported),
 *   'avail_before' => stock left in the pool when this line is reached ("we have X for it"),
 *   'allocated'    => how much this line pulls from stock,
 *   'shortfall'    => qty still needed after stock ('avail' short of 'remaining'),
 *   'remaining'    => this line's still-to-ship qty (ordered − shipped),
 * ]. Only OPEN lines (remaining > 0, not cancelled) appear. Considers ALL of the item's
 * lines — not just a search's result set — so allocation is correct regardless of the filter.
 */
function allocate_on_hand(array $itemNumbers): array
{
    $items = array_values(array_unique(array_filter(
        array_map(fn($x) => trim((string) $x), $itemNumbers),
        fn($x) => $x !== ''
    )));
    if (!$items) return [];

    $ph = implode(',', array_fill(0, count($items), '?'));
    $st = db()->prepare(
        "SELECT id, ordered_item, on_hand_qty, ordered_qty, shipped_qty, request_date, ship_line_status
         FROM order_lines WHERE ordered_item IN ($ph)"
    );
    $st->execute($items);

    $byItem = [];
    foreach ($st->fetchAll() as $r) $byItem[$r['ordered_item']][] = $r;

    $out = [];
    foreach ($byItem as $lines) {
        $onHand = null;
        foreach ($lines as $l) {
            if ($l['on_hand_qty'] !== null) {
                $onHand = ($onHand === null) ? (float) $l['on_hand_qty'] : max($onHand, (float) $l['on_hand_qty']);
            }
        }
        // Keep only OPEN lines (still qty to ship, not cancelled).
        $open = [];
        foreach ($lines as $l) {
            $remaining = (float) $l['ordered_qty'] - (float) ($l['shipped_qty'] ?? 0);
            if ($remaining <= 0) continue;
            if (strpos(strtolower((string) $l['ship_line_status']), 'cancel') !== false) continue;
            $open[] = ['id' => (int) $l['id'], 'remaining' => $remaining, 'req' => $l['request_date']];
        }
        // Earliest request date first; undated last; id as a stable tiebreak.
        usort($open, fn($a, $b) => [order_date_ts($a['req']), $a['id']] <=> [order_date_ts($b['req']), $b['id']]);

        $running = $onHand ?? 0.0;
        foreach ($open as $o) {
            $availBefore = $running;
            $alloc = min($running, $o['remaining']);
            $running -= $alloc;
            $out[$o['id']] = [
                'on_hand'      => $onHand,
                'avail_before' => ($onHand === null) ? null : $availBefore,
                'allocated'    => ($onHand === null) ? null : $alloc,
                'shortfall'    => ($onHand === null) ? null : max(0.0, $o['remaining'] - $alloc),
                'remaining'    => $o['remaining'],
            ];
        }
    }
    return $out;
}
