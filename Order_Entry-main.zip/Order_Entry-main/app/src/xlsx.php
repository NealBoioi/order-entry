<?php
// Minimal pure-PHP .xlsx reader (no Composer). Reads the first worksheet and
// returns an array of associative rows keyed by the header row's cell text.
// Handles shared strings, inline strings, and sparse cells. Good enough for the
// flat Oracle warehouse export; not a general-purpose spreadsheet engine.

function xlsx_col_index(string $letters): int
{
    $n = 0;
    for ($i = 0, $len = strlen($letters); $i < $len; $i++) {
        $n = $n * 26 + (ord($letters[$i]) - 64);
    }
    return $n - 1;
}

function xlsx_read(string $path): array
{
    if (!is_file($path)) {
        throw new RuntimeException("xlsx not found: $path");
    }
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) {
        throw new RuntimeException("cannot open xlsx: $path");
    }

    // Shared strings table
    $shared = [];
    $ssXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($ssXml !== false) {
        $x = simplexml_load_string($ssXml);
        foreach ($x->si as $si) {
            if (isset($si->t)) {
                $shared[] = (string) $si->t;
            } else {
                $text = '';
                foreach ($si->r as $r) { $text .= (string) $r->t; }
                $shared[] = $text;
            }
        }
    }

    // First worksheet (sheet1, else first matching)
    $sheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
    if ($sheetXml === false) {
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if (preg_match('#^xl/worksheets/sheet\d+\.xml$#', $name)) {
                $sheetXml = $zip->getFromName($name);
                break;
            }
        }
    }
    $zip->close();
    if (!$sheetXml) {
        throw new RuntimeException("no worksheet found in $path");
    }

    $x = simplexml_load_string($sheetXml);
    $grid = [];
    foreach ($x->sheetData->row as $row) {
        $cells = [];
        foreach ($row->c as $c) {
            preg_match('/^([A-Z]+)/', (string) $c['r'], $m);
            $col = xlsx_col_index($m[1]);
            $t = (string) $c['t'];
            if ($t === 's') {
                $val = $shared[(int) $c->v] ?? '';
            } elseif ($t === 'inlineStr') {
                $val = (string) $c->is->t;
            } else {
                $val = isset($c->v) ? (string) $c->v : '';
            }
            $cells[$col] = $val;
        }
        $grid[] = $cells;
    }
    if (!$grid) return [];

    $header = $grid[0];
    $maxCol = $header ? max(array_keys($header)) : 0;
    $out = [];
    for ($i = 1, $n = count($grid); $i < $n; $i++) {
        $assoc = [];
        $hasData = false;
        for ($c = 0; $c <= $maxCol; $c++) {
            $key = isset($header[$c]) ? trim($header[$c]) : "col$c";
            $val = $grid[$i][$c] ?? '';
            if ($val !== '') $hasData = true;
            $assoc[$key] = $val;
        }
        if ($hasData) $out[] = $assoc;
    }
    return $out;
}
