<?php
// Shared branded HTML wrapper for outbound emails, so every message (magic-link,
// order notifications, onboarding) matches the website's Wesco look: charcoal (#1D252D)
// header, "ASSEMBLIES" wordmark + green "Order Entry" tag, white card, green (#00AA13)
// primary button. Table-based + inline styles so it renders consistently across mail
// clients (Gmail/Outlook strip <style> blocks and external CSS).

// Wrap inner HTML in the full branded shell. $preheader is the hidden preview-text
// line inboxes show next to the subject.
function email_wrap(string $heading, string $bodyHtml, string $preheader = ''): string
{
    $esc = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
    $pre = $preheader !== ''
        ? '<div style="display:none;max-height:0;overflow:hidden;mso-hide:all;opacity:0;">' . $esc($preheader) . '</div>'
        : '';
    return '<!doctype html><html lang="en"><head><meta charset="utf-8">'
      . '<meta name="viewport" content="width=device-width,initial-scale=1"></head>'
      . '<body style="margin:0;padding:0;background:#F4F6F7;">' . $pre
      . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
      .   'style="background:#F4F6F7;padding:26px 12px;">'
      . '<tr><td align="center">'
      . '<table role="presentation" cellpadding="0" cellspacing="0" width="540" '
      .   'style="width:540px;max-width:100%;font-family:Segoe UI,Arial,Helvetica,sans-serif;">'
      // header band — Wesco charcoal, "ASSEMBLIES" wordmark + green "ORDER ENTRY" tag (matches the site)
      . '<tr><td style="background:#1D252D;border-radius:12px 12px 0 0;padding:18px 26px;">'
      .   '<span style="font-size:22px;font-weight:800;color:#ffffff;letter-spacing:.4px;">ASSEMBLIES</span>'
      .   '<span style="font-size:12px;font-weight:700;color:#00AA13;letter-spacing:1.5px;'
      .     'text-transform:uppercase;">&nbsp;&nbsp;Order Entry</span>'
      .   '</td></tr>'
      // white card
      . '<tr><td style="background:#ffffff;border:1px solid #E2E7EA;border-top:none;'
      .   'border-radius:0 0 12px 12px;padding:28px 26px;color:#1D252D;">'
      .   '<h1 style="margin:0 0 16px;font-size:20px;font-weight:700;color:#1D252D;">' . $esc($heading) . '</h1>'
      .   $bodyHtml
      . '</td></tr>'
      // footer
      . '<tr><td style="padding:16px 26px 4px;text-align:center;color:#8A97A2;font-size:12px;line-height:1.5;">'
      .   'Assemblies Order Entry &middot; assembly-plant order &amp; quoting portal<br>'
      .   'This is an automated message — please don\'t reply directly.'
      . '</td></tr>'
      . '</table></td></tr></table></body></html>';
}

// Absolute site root for building links in emails: config 'app.base_url' if set, else
// derived from the request (fine for local dev). Shared by every email that links back in
// (magic-link, set-password, password reset).
if (!function_exists('app_base_url')) {
    function app_base_url(): string
    {
        $c   = require __DIR__ . '/../config/config.php';
        $cfg = trim((string) ($c['app']['base_url'] ?? ''));
        if ($cfg !== '') return rtrim($cfg, '/');
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host   = $_SERVER['HTTP_HOST'] ?? '127.0.0.1:8000';
        return $scheme . '://' . $host;
    }
}

// A bulletproof-ish call-to-action button (table cell, not a styled <a>, so Outlook
// renders the fill).
function email_button(string $label, string $url, string $bg = '#00AA13'): string
{
    $esc = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
    return '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:6px 0 18px;">'
      . '<tr><td style="border-radius:6px;background:' . $esc($bg) . ';">'
      . '<a href="' . $esc($url) . '" style="display:inline-block;padding:12px 28px;font-size:15px;'
      .   'font-weight:600;color:#ffffff;text-decoration:none;border-radius:6px;">' . $esc($label) . '</a>'
      . '</td></tr></table>';
}
