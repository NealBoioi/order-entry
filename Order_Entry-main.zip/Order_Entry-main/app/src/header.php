<?php
// Shared app header: brand + a "☰ Menu" dropdown of all destinations + a user dropdown
// (email → Settings / Sign out). Centralized so nav lives in ONE place. Uses native <details>
// dropdowns (no JS). Call render_header('<active-key>') on any logged-in page.
require_once __DIR__ . '/auth.php';

function render_header(string $active = ''): void
{
    $me      = current_user() ?? [];
    $role    = $me['role'] ?? '';
    $isAdmin = $role === 'admin';
    $branch  = $me['branch'] ?? '';
    $email   = $me['email'] ?? '';

    // [key, label, href, adminOnly]
    $items = [
        ['status',     'Order Status', 'index.php',           false],
        ['components', 'Components',   'components.php',      true],   // admin-only quoting aid (raw materials)
        ['new',        'New Order',    'new-order.php',        false],
        ['pending',    'Pending',      'my-orders.php',        false],
        ['contacts',   'Contact list', 'contacts.php',         false],
        ['quotes',     'Quotes',       'quotes.php',           true],
        ['presets',    'Quoting Presets', 'quoting-presets.php', true],
        ['import',     'Import',       'admin-import.php',     true],
        ['users',      'Users',        'admin-users.php',      true],
    ];
    // Top-bar quick links (right of the ☰ Menu button) — the two most-used destinations,
    // duplicated from the menu above for one-click access. Same active-state highlighting.
    $quickLinks = [
        ['status', 'Order Status', 'index.php'],
        ['new',    'New Order',    'new-order.php'],
    ];
    ?>
    <header>
      <a class="brand" href="index.php">
        <svg class="wmark" viewBox="217 219 943 441" xmlns="http://www.w3.org/2000/svg"><path fill="#00AA13" d="M938.2,652.9l221.1-415.8c4.1-7.8-1.5-17.2-10.3-17.2H934.2c-6.2,0-11.8,3.4-14.7,8.9L804.8,444.3l110.9,208.6c2.2,4.2,6.5,6.8,11.2,6.8h0C931.7,659.6,936,657,938.2,652.9z"/><path fill="#00AA13" d="M221.3,237.1l211.1,397.1l115.3-216.9L447.5,228.7c-2.9-5.4-8.6-8.9-14.7-8.9H231.6C222.8,219.9,217.2,229.3,221.3,237.1z"/><path fill="#00AA13" d="M446,659.6h234.3c6.2,0,11.8-3.4,14.7-8.9l109.8-206.5L693.9,235.7c-2.2-4.1-6.5-6.8-11.2-6.8l0,0c-4.7,0-9,2.6-11.2,6.8L446,659.6z"/></svg>
        <span class="brand-text"><b>ASSEMBLIES</b><i>Order Entry</i></span>
      </a>
      <details class="dd">
        <summary class="menu-btn">&#9776; Menu</summary>
        <div class="dd-panel">
          <?php foreach ($items as [$k, $label, $href, $adminOnly]): ?>
            <?php if ($adminOnly && !$isAdmin) continue; ?>
            <a class="<?= $active === $k ? 'on' : '' ?>" href="<?= h($href) ?>"><?= h($label) ?></a>
          <?php endforeach; ?>
        </div>
      </details>
      <nav class="hdr-quick">
        <?php foreach ($quickLinks as [$k, $label, $href]): ?>
          <a class="<?= $active === $k ? 'on' : '' ?>" href="<?= h($href) ?>"><?= h($label) ?></a>
        <?php endforeach; ?>
      </nav>
      <div class="usr">
        <?php if ($role === 'customer' && $branch): ?><span class="rolechip">branch <?= h($branch) ?></span><?php endif; ?>
        <span class="rolechip <?= $isAdmin ? 'admin' : '' ?>"><?= h($role) ?></span>
        <details class="dd">
          <summary class="who"><?= h($email) ?> &#9662;</summary>
          <div class="dd-panel right">
            <div class="dd-head"><?= h($email) ?></div>
            <a class="<?= $active === 'settings' ? 'on' : '' ?>" href="settings.php">Settings</a>
            <div class="dd-divider"></div>
            <form method="post" action="logout.php" style="margin:0;"><?= csrf_field() ?><button type="submit" class="linklike">Sign out</button></form>
          </div>
        </details>
      </div>
    </header>
    <script src="confirm-modal.js?v=3"></script>
    <?php
}
