<?php
// Plant notification for new orders (ROADMAP #3 — now wired to real SMTP via mailer.php).
// Behaviour:
//   - Resolves the plant contact for the order's org (Contact directory).
//   - If mail is enabled + a contact exists, sends the order via PHPMailer.
//   - ALWAYS appends an audit line to app/storage/notifications.log (sent / failed /
//     skipped), so there's a record even when email is off or fails.
//   - NEVER throws: an email problem must not break order submission (the order is
//     already committed by the time this runs).
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/email_theme.php';

// Plant contact email for an order's org. Prefers the admin-editable Contact directory
// (plant_contacts); falls back to the legacy orgs.contact_email.
function plant_contact_for_org(string $inventoryOrg): ?string
{
    $st = db()->prepare('SELECT contact_email FROM plant_contacts WHERE inventory_org = ?');
    $st->execute([$inventoryOrg]);
    $row = $st->fetch();
    if ($row && !empty($row['contact_email'])) return $row['contact_email'];

    $st = db()->prepare('SELECT contact_email FROM orgs WHERE inventory_org = ?');
    $st->execute([$inventoryOrg]);
    $row = $st->fetch();
    return $row && !empty($row['contact_email']) ? $row['contact_email'] : null;
}

// Load order header (+ plant name + who entered it) and its lines for the message.
function notify_load_order(int $orderId): array
{
    $st = db()->prepare(
        'SELECT o.*, g.name AS plant_name, u.email AS created_by_email
         FROM site_orders o
         LEFT JOIN orgs  g ON g.inventory_org = o.inventory_org
         LEFT JOIN users u ON u.id = o.created_by
         WHERE o.id = ?'
    );
    $st->execute([$orderId]);
    $order = $st->fetch() ?: [];
    $ls = db()->prepare('SELECT * FROM site_order_lines WHERE order_id = ? ORDER BY id');
    $ls->execute([$orderId]);
    return ['order' => $order, 'lines' => $ls->fetchAll()];
}

// Build [subject, htmlBody, textBody] for the notification (branded via email_theme.php).
function notify_build_message(array $data, string $po, string $org): array
{
    $o = $data['order'];
    $plant = ($o['plant_name'] ?? $org) . " ($org)";
    $urgent = !empty($o['urgent']);
    $subject = ($urgent ? '🚩 URGENT — ' : '') . "New order $po — $plant";
    $esc = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

    // Prominent URGENT banner at the very top of the card when flagged.
    $urgentBanner = $urgent
        ? '<table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:0 0 18px;">'
          . '<tr><td style="background:#C0392B;border-radius:8px;padding:12px 16px;text-align:center;'
          . 'color:#ffffff;font-size:16px;font-weight:800;letter-spacing:1px;">⚠ URGENT ORDER — PLEASE PRIORITISE</td></tr></table>'
        : '';

    // Order meta — a bordered spreadsheet-style grid (label | value), in the requested field order.
    $shipRef = trim((string) ($o['shipment_ref'] ?? ''));
    $meta = [
        'Date Submitted'       => $o['created_at'] ?? '',
        'PO #'                 => $po,
        'Shipment Reference #' => $shipRef !== '' ? $shipRef : '—',
        'Entered by'           => $o['created_by_email'] ?? '',
        'Plant Site'           => $plant,
    ];
    if (!empty($o['ship_to']))     $meta['Ship to']     = str_replace("\n", ', ', $o['ship_to']);
    if (!empty($o['ship_method'])) $meta['Ship method'] = $o['ship_method'];
    if (!empty($o['bill_to']))     $meta['Bill to']     = str_replace("\n", ', ', $o['bill_to']);
    if (!empty($o['notes']))       $meta['Notes']       = $o['notes'];

    $mL = 'style="padding:8px 12px;border:1px solid #E2E7EA;background:#EDF1F2;color:#55636E;font-size:13px;font-weight:600;white-space:nowrap;vertical-align:top;width:160px;"';
    $mR = 'style="padding:8px 12px;border:1px solid #E2E7EA;color:#1D252D;font-size:13px;font-weight:600;"';
    $metaHtml = '<table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;border:1px solid #E2E7EA;margin:0 0 18px;">';
    foreach ($meta as $k => $v) {
        $metaHtml .= '<tr><td ' . $mL . '>' . $esc($k) . '</td><td ' . $mR . '>' . $esc($v) . '</td></tr>';
    }
    $metaHtml .= '</table>';

    // Line items — spreadsheet-style bordered grid; adds UOM + Requested Delivery Date columns.
    $rdd = !empty($o['requested_delivery_date']) ? $o['requested_delivery_date'] : '—';
    $thL = 'style="text-align:left;padding:8px 10px;background:#EDF1F2;color:#37485a;font-size:13px;border:1px solid #E2E7EA;"';
    $thC = 'style="text-align:center;padding:8px 10px;background:#EDF1F2;color:#37485a;font-size:13px;border:1px solid #E2E7EA;"';
    $thR = 'style="text-align:right;padding:8px 10px;background:#EDF1F2;color:#37485a;font-size:13px;border:1px solid #E2E7EA;"';
    $tdL = 'style="text-align:left;padding:8px 10px;border:1px solid #E2E7EA;font-size:13px;color:#1D252D;"';
    $tdC = 'style="text-align:center;padding:8px 10px;border:1px solid #E2E7EA;font-size:13px;color:#1D252D;"';
    $tdR = 'style="text-align:right;padding:8px 10px;border:1px solid #E2E7EA;font-size:13px;color:#1D252D;"';
    $rowsHtml = ''; $rowsText = ''; $total = 0.0;
    foreach ($data['lines'] as $l) {
        $ext = $l['unit_price'] !== null ? $l['unit_price'] * $l['quantity'] : null;
        if ($ext !== null) $total += $ext;
        $priceH = $l['unit_price'] !== null ? '$' . number_format($l['unit_price'], 4) : '—';
        $extH   = $ext !== null ? '$' . number_format($ext, 2) : 'no price';
        $uom    = ($l['uom'] ?? '') !== '' ? $l['uom'] : '—';
        $rowsHtml .= '<tr><td ' . $tdL . '>' . $esc($l['item_number']) . '</td><td ' . $tdL . '>' . $esc($l['description'])
                   . '</td><td ' . $tdR . '>' . $esc($l['quantity']) . '</td><td ' . $tdC . '>' . $esc($uom)
                   . '</td><td ' . $tdR . '>' . $priceH . '</td><td ' . $tdR . '>' . $extH
                   . '</td><td ' . $tdC . '>' . $esc($rdd) . '</td></tr>';
        $rowsText .= sprintf("  %-14s %-28s %sx%-5s %s\n", $l['item_number'], $l['description'], $uom . ' ', $l['quantity'], $extH);
    }
    $table = '<table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;border:1px solid #E2E7EA;">'
           . '<thead><tr><th ' . $thL . '>Item</th><th ' . $thL . '>Description</th><th ' . $thR . '>Qty</th>'
           . '<th ' . $thC . '>UOM</th><th ' . $thR . '>Unit</th><th ' . $thR . '>Ext</th>'
           . '<th ' . $thC . '>Requested Delivery Date</th></tr></thead>'
           . '<tbody>' . $rowsHtml . '</tbody>'
           . '<tfoot><tr><td colspan="5" style="text-align:right;padding:8px 10px;background:#F6F8F9;font-weight:700;border:1px solid #E2E7EA;">Total</td>'
           . '<td style="text-align:right;padding:8px 10px;background:#F6F8F9;font-weight:700;border:1px solid #E2E7EA;">$' . number_format($total, 2) . '</td>'
           . '<td style="background:#F6F8F9;border:1px solid #E2E7EA;"></td></tr></tfoot>'
           . '</table>';

    $inner = $urgentBanner
           . '<p style="margin:0 0 16px;font-size:15px;line-height:1.55;color:#55636E;">'
           . 'A new order was submitted on the Order Entry portal. Key it into Oracle to fulfil.</p>'
           . $metaHtml . $table;
    $html = email_wrap(($urgent ? 'URGENT — ' : '') . 'New order ' . $po, $inner,
                       ($urgent ? 'URGENT — ' : '') . "New order $po — $plant");

    $text = ($urgent ? "*** URGENT ORDER — PLEASE PRIORITISE ***\n\n" : '')
          . "New order $po\n"
          . 'Date Submitted: ' . ($o['created_at'] ?? '') . "\n"
          . ($shipRef !== '' ? "Shipment Reference #: $shipRef\n" : '')
          . 'Entered by: ' . ($o['created_by_email'] ?? '') . "\n"
          . "Plant Site: $plant\n"
          . (!empty($o['ship_to'])     ? 'Ship to: ' . str_replace("\n", ', ', $o['ship_to']) . "\n" : '')
          . (!empty($o['ship_method']) ? 'Ship method: ' . $o['ship_method'] . "\n" : '')
          . (!empty($o['bill_to'])     ? 'Bill to: ' . str_replace("\n", ', ', $o['bill_to']) . "\n" : '')
          . (!empty($o['notes'])       ? 'Notes: ' . $o['notes'] . "\n" : '')
          . "\nLines:\n" . $rowsText
          . 'Total: $' . number_format($total, 2) . "\n";

    return [$subject, $html, $text];
}

function notify_log(int $orderId, string $po, string $org, string $to, string $status): void
{
    $dir = __DIR__ . '/../storage';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $line = sprintf("[%s] ORDER #%d  PO=%s  org=%s  to=%s  %s\n",
        date('c'), $orderId, $po, $org, $to, $status);
    @file_put_contents($dir . '/notifications.log', $line, FILE_APPEND | LOCK_EX);
}

// Fire the new-order notification. Best-effort: sends if configured, always logs, never throws.
function notify_new_order(int $orderId, string $poNumber, string $inventoryOrg): void
{
    try {
        $to = plant_contact_for_org($inventoryOrg);

        if (!$to) {
            notify_log($orderId, $poNumber, $inventoryOrg, '(none)', 'SKIPPED: no plant contact configured');
            return;
        }
        if (!mail_enabled()) {
            notify_log($orderId, $poNumber, $inventoryOrg, $to, 'LOGGED ONLY: mail disabled (would email)');
            return;
        }

        $data = notify_load_order($orderId);
        [$subject, $html, $text] = notify_build_message($data, $poNumber, $inventoryOrg);
        [$ok, $err] = send_email($to, $subject, $html, $text);
        notify_log($orderId, $poNumber, $inventoryOrg, $to, $ok ? 'SENT' : ('SEND FAILED: ' . $err));
    } catch (\Throwable $e) {
        // Absolute backstop — never let notification issues surface to the ordering user.
        notify_log($orderId, $poNumber, $inventoryOrg, '(error)', 'ERROR: ' . $e->getMessage());
    }
}
