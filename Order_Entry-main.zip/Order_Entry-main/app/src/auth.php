<?php
// Auth / onboarding core for the Order Entry app.
//   Flow:  request access (email + branch) -> admin approves & assigns role
//          -> one-time token -> user sets password -> login (session).
// Passwords hashed with password_hash() (bcrypt). Tokens stored only as sha256.
require_once __DIR__ . '/db.php';

// --- Session bootstrap -------------------------------------------------------
function auth_boot(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'secure'   => $https,          // set automatically once served over HTTPS at go-live
        'samesite' => 'Lax',
    ]);
    session_name('oe_sid');
    session_start();
}

// --- Shared view helpers (guarded so index.php can also define them) ---------
if (!function_exists('h')) {
    function h($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }
}

function redirect(string $to): never
{
    header('Location: ' . $to);
    exit;
}

// --- Rate limiting -----------------------------------------------------------
// Best-effort client IP (no proxy trust yet — add X-Forwarded-For handling behind a
// known reverse proxy at go-live).
function client_ip(): string
{
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

// Fixed-window limiter. Records one hit for (action,key) and returns [allowed, retryAfterSec].
// Once `hits` reaches `$limit` within the window, further calls return [false, secondsLeft]
// without extending the window. Fails OPEN (allows) on any DB error so auth never hard-breaks.
function rate_limit_hit(string $action, string $key, int $limit, int $windowSec): array
{
    try {
        $bucket = hash('sha256', $action . '|' . strtolower(trim($key)));
        $w   = (int) $windowSec;                 // inlined — MySQL won't bind INTERVAL quantity
        $pdo = db();
        $st  = $pdo->prepare('SELECT hits, UNIX_TIMESTAMP(reset_at) AS reset_ts FROM auth_rate_limits WHERE bucket = ?');
        $st->execute([$bucket]);
        $row = $st->fetch();
        $now = time();

        if (!$row || (int) $row['reset_ts'] <= $now) {           // fresh window (new or expired)
            $pdo->prepare(
                "INSERT INTO auth_rate_limits (bucket, hits, reset_at)
                 VALUES (?, 1, DATE_ADD(NOW(), INTERVAL $w SECOND))
                 ON DUPLICATE KEY UPDATE hits = 1, reset_at = DATE_ADD(NOW(), INTERVAL $w SECOND)"
            )->execute([$bucket]);
            return [true, 0];
        }
        if ((int) $row['hits'] >= $limit) {
            return [false, max(1, (int) $row['reset_ts'] - $now)];
        }
        $pdo->prepare('UPDATE auth_rate_limits SET hits = hits + 1 WHERE bucket = ?')->execute([$bucket]);
        return [true, 0];
    } catch (\Throwable $e) {
        return [true, 0];                        // fail open — don't lock people out on a limiter bug
    }
}

// --- Password policy ---------------------------------------------------------
const PASSWORD_MIN = 10;

// Returns an error message if the password is unacceptable, or null if it passes.
function password_policy_error(string $pw): ?string
{
    if (strlen($pw) < PASSWORD_MIN) {
        return 'Password must be at least ' . PASSWORD_MIN . ' characters.';
    }
    if (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) {
        return 'Password must include at least one letter and one number.';
    }
    $common = ['password1!', 'password123', '1234567890', 'qwerty1234', 'letmein123',
               'changeme123', 'welcome1234', 'admin123456', 'orderentry1'];
    if (in_array(strtolower($pw), $common, true)) {
        return 'That password is too common — please choose a less predictable one.';
    }
    return null;
}

// --- CSRF --------------------------------------------------------------------
function csrf_token(): string
{
    auth_boot();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . h(csrf_token()) . '">';
}

// Verify the token on a POST; aborts with 400 on mismatch.
function csrf_check(): void
{
    auth_boot();
    $sent = $_POST['_csrf'] ?? '';
    if (!is_string($sent) || $sent === '' || empty($_SESSION['csrf'])
        || !hash_equals($_SESSION['csrf'], $sent)) {
        http_response_code(400);
        exit('Bad request (invalid form token). Go back and try again.');
    }
}

// --- Current user / guards ---------------------------------------------------
function current_user(): ?array
{
    static $cache = false;
    if ($cache !== false) return $cache;
    auth_boot();
    $id = $_SESSION['uid'] ?? null;
    if (!$id) return $cache = null;
    $st = db()->prepare('SELECT id, email, branch, role, status FROM users WHERE id = ?');
    $st->execute([$id]);
    $u = $st->fetch();
    // A user disabled mid-session is logged out.
    if (!$u || $u['status'] !== 'active') { logout(); return $cache = null; }
    return $cache = $u;
}

function require_login(): array
{
    $u = current_user();
    if (!$u) redirect('login.php');
    // Approved customers must finish account setup before using the rest of the app.
    // (Admins skip this; the setup/logout/set-password pages are exempt to avoid a loop.)
    if ($u['role'] === 'customer') {
        $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
        $exempt = ['account-setup.php', 'logout.php', 'set-password.php'];
        if (!in_array($script, $exempt, true)) {
            require_once __DIR__ . '/profile.php';
            if (!profile_complete((int) $u['id'])) redirect('account-setup.php');
        }
    }
    return $u;
}

function require_admin(): array
{
    $u = require_login();
    if ($u['role'] !== 'admin') {
        http_response_code(403);
        exit('403 — admin access required.');
    }
    return $u;
}

// --- Login / logout ----------------------------------------------------------
// Returns [true, null] on success or [false, message] on failure.
function attempt_login(string $email, string $password): array
{
    $email = trim(strtolower($email));
    $st = db()->prepare('SELECT id, password_hash, status FROM users WHERE email = ?');
    $st->execute([$email]);
    $u = $st->fetch();
    // Uniform failure message — don't reveal which accounts exist / are approved.
    $fail = [false, 'Incorrect email or password, or the account is not yet active.'];
    if (!$u || $u['status'] !== 'active' || !$u['password_hash']) return $fail;
    if (!password_verify($password, $u['password_hash'])) return $fail;

    auth_boot();
    session_regenerate_id(true);          // prevent session fixation
    $_SESSION['uid'] = (int) $u['id'];
    return [true, null];
}

function logout(): void
{
    auth_boot();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

// --- Onboarding --------------------------------------------------------------
// Create a pending access request. Returns [true, null] or [false, message].
function create_access_request(string $email, string $branch): array
{
    $email  = trim(strtolower($email));
    $branch = trim($branch);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return [false, 'Please enter a valid email address.'];
    if (!preg_match('/^\d{4}$/', $branch))          return [false, 'Branch # must be exactly 4 digits.'];

    $exists = db()->prepare('SELECT status FROM users WHERE email = ?');
    $exists->execute([$email]);
    if ($row = $exists->fetch()) {
        // Don't leak account state; the message is the same either way.
        return [true, null];
    }
    $st = db()->prepare(
        "INSERT INTO users (email, branch, status) VALUES (?, ?, 'pending')"
    );
    $st->execute([$email, $branch]);
    return [true, null];
}

// Email address for a user id (or null). Used when emailing set-password links.
function user_email_by_id(int $id): ?string
{
    $st = db()->prepare('SELECT email FROM users WHERE id = ?');
    $st->execute([$id]);
    $e = $st->fetchColumn();
    return $e !== false ? (string) $e : null;
}

function list_users(?string $status = null): array
{
    $sql = "SELECT id, email, branch, role, status, created_at, approved_at FROM users";
    $params = [];
    if ($status !== null) { $sql .= " WHERE status = ?"; $params[] = $status; }
    // Pending requests float to the top so admins see new requests first.
    $sql .= " ORDER BY (status = 'pending') DESC, created_at DESC";
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

// Approve a pending user: set role + branch, activate, and issue a one-time
// set-password token. Returns [true, rawToken] or [false, message].
function approve_user(int $userId, string $role, ?string $branch): array
{
    $role = $role === 'admin' ? 'admin' : 'customer';
    $branch = $branch !== null ? trim($branch) : null;
    if ($branch === '') $branch = null;
    // Customers are scoped to a branch; admins are plant-wide (branch optional).
    if ($role === 'customer' && !preg_match('/^\d{4}$/', (string) $branch)) {
        return [false, 'Customer accounts need a 4-digit branch #.'];
    }
    if ($branch !== null && !preg_match('/^\d{4}$/', $branch)) {
        return [false, 'Branch # must be 4 digits (or blank for an admin).'];
    }
    $st = db()->prepare(
        "UPDATE users SET role = ?, branch = ?, status = 'active', approved_at = NOW()
         WHERE id = ?"
    );
    $st->execute([$role, $branch, $userId]);
    return [true, issue_password_token($userId)];
}

function set_user_status(int $userId, string $status): void
{
    $status = in_array($status, ['active', 'disabled'], true) ? $status : 'disabled';
    db()->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$status, $userId]);
}

/**
 * Deny (reject) a PENDING access request: deletes the account row so the email is freed for a
 * fresh request later. Guarded to `status = 'pending'` so it can never remove an active/disabled
 * account. Cleans up any password tokens too. Returns true if a pending request was removed.
 */
function deny_user(int $userId): bool
{
    // Only touch tokens tied to a still-pending user.
    db()->prepare(
        'DELETE t FROM password_tokens t JOIN users u ON u.id = t.user_id
         WHERE t.user_id = ? AND u.status = "pending"'
    )->execute([$userId]);
    $st = db()->prepare("DELETE FROM users WHERE id = ? AND status = 'pending'");
    $st->execute([$userId]);
    return $st->rowCount() === 1;
}

/**
 * Permanently delete a user account (any status). The profile / address-book / ship-method /
 * token tables all FK to users(id) ON DELETE CASCADE, so this also removes all of that user's
 * saved data. Their submitted `site_orders` are preserved (no FK; the order view LEFT-joins the
 * user, so "Entered by" just goes blank). Callers must block self-deletion. Returns true if a row
 * was removed.
 */
function delete_user(int $userId): bool
{
    $st = db()->prepare('DELETE FROM users WHERE id = ?');
    $st->execute([$userId]);
    return $st->rowCount() === 1;
}

// Issue a fresh one-time password token (used for both initial set and resets).
// Returns the RAW token (only shown once); DB stores its sha256 only.
function issue_password_token(int $userId): string
{
    $raw  = bin2hex(random_bytes(32));
    $hash = hash('sha256', $raw);
    // Invalidate any earlier unused tokens for this user.
    db()->prepare('UPDATE password_tokens SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL')
        ->execute([$userId]);
    db()->prepare(
        'INSERT INTO password_tokens (user_id, token_hash, expires_at)
         VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 72 HOUR))'
    )->execute([$userId, $hash]);
    return $raw;
}

// Look up a live (unused, unexpired) token. Returns the token row or null.
function find_valid_token(string $rawToken): ?array
{
    $hash = hash('sha256', trim($rawToken));
    $st = db()->prepare(
        'SELECT id, user_id FROM password_tokens
         WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW() LIMIT 1'
    );
    $st->execute([$hash]);
    return $st->fetch() ?: null;
}

// --- Magic-link (passwordless) sign-in ---------------------------------------
// Issue a fresh one-time LOGIN token for a user (short-lived — default 20 min).
// Any earlier unused login tokens for the user are invalidated first, so only the
// newest link works. Returns the RAW token (goes only into the emailed link).
function issue_login_token(int $userId, int $ttlMinutes = 20): string
{
    $raw  = bin2hex(random_bytes(32));
    $hash = hash('sha256', $raw);
    db()->prepare('UPDATE login_tokens SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL')
        ->execute([$userId]);
    // $ttlMinutes is inlined as a cast int — MySQL won't bind a placeholder inside INTERVAL.
    db()->prepare(
        'INSERT INTO login_tokens (user_id, token_hash, expires_at)
         VALUES (?, ?, DATE_ADD(NOW(), INTERVAL ' . (int) $ttlMinutes . ' MINUTE))'
    )->execute([$userId, $hash]);
    return $raw;
}

// Look up a live (unused, unexpired) login token. Returns the token row or null.
function find_valid_login_token(string $rawToken): ?array
{
    $hash = hash('sha256', trim($rawToken));
    $st = db()->prepare(
        'SELECT id, user_id FROM login_tokens
         WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW() LIMIT 1'
    );
    $st->execute([$hash]);
    return $st->fetch() ?: null;
}

// Consume a magic-link token and start a session. The token is marked used ATOMICALLY
// (UPDATE ... WHERE used_at IS NULL, rowCount() must be 1) so a link can't be replayed,
// even under a double-click race. Returns [true, null] or [false, message].
function login_with_token(string $rawToken): array
{
    $tok = find_valid_login_token($rawToken);
    if (!$tok) return [false, 'This sign-in link is invalid or has expired. Request a new one below.'];

    $st = db()->prepare('UPDATE login_tokens SET used_at = NOW() WHERE id = ? AND used_at IS NULL');
    $st->execute([$tok['id']]);
    if ($st->rowCount() !== 1) return [false, 'This sign-in link has already been used. Request a new one below.'];

    $u = db()->prepare('SELECT id, status FROM users WHERE id = ?');
    $u->execute([$tok['user_id']]);
    $row = $u->fetch();
    if (!$row || $row['status'] !== 'active') return [false, 'That account is not active.'];

    auth_boot();
    session_regenerate_id(true);          // prevent session fixation (same as password login)
    $_SESSION['uid'] = (int) $row['id'];
    return [true, null];
}

// Consume a token and set the user's password. Returns [true, null] or [false, message].
function set_password_with_token(string $rawToken, string $password): array
{
    if ($msg = password_policy_error($password)) return [false, $msg];
    $tok = find_valid_token($rawToken);
    if (!$tok) return [false, 'This link is invalid or has expired. Ask an admin for a new one.'];

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE users SET password_hash = ?, status = 'active' WHERE id = ?")
            ->execute([password_hash($password, PASSWORD_DEFAULT), $tok['user_id']]);
        $pdo->prepare('UPDATE password_tokens SET used_at = NOW() WHERE id = ?')
            ->execute([$tok['id']]);
        $pdo->commit();
    } catch (\Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return [true, null];
}
