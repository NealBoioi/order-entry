<?php
// Quoting module — persistence + cost math for the plant's quote workbook.
//   quotes                   = Bid Prep header (Pre-Bid Proposal "must-have" info)
//   quote_bom_lines          = Costed BOM
//   quote_bom_price_breaks   = per-BOM-line volume price breaks (Batch 2)
//   quote_cost_tiers         = Labor Breakdown (one row per labor type × build qty)
//   quote_summary_tiers      = Quote Summary (computed transfer/sale price per build qty)
//   quote_revisions          = Quote Rev (project-pack revision log)
// Admin/quoting-side only — see quote.php/quotes.php pages, gated with require_admin().
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/pricing.php';   // assembly_price() — tier-price fallback for BOM autofill
require_once __DIR__ . '/presets.php';   // get_quoting_preset()/labor_rate_for() — plant rates & burdens

// Whitelisted, user-editable header columns (Bid Prep). Anything not in this list can
// never be written from a form — the update builds its SQL from this map only.
// NOTE: quote_number is deliberately NOT here — it's system-assigned (generate_quote_number()),
// never taken from a form post.
const QUOTE_FIELDS = [
    'quote_id', 'tsg_number', 'kit_sim', 'customer', 'part_number', 'description',
    'revision', 'branch', 'inventory_org', 'outside_sales', 'inside_sales', 'bdm',
    'program_manager', 'eau', 'release_qty', 'ncnr_signed', 'quote_requested_date',
    'first_build_date', 'production_date', 'pre_bid_meeting_date', 'customer_drawings',
    'customer_bom', 'crossed_material', 'engineering_required', 'fai_required', 'coc_required',
    'ul_label', 'certifications', 'testing_details', 'packaging_reqs', 'customer_quality_reqs',
    'target_pricing', 'build_status', 'nda_signed', 'cbc_part', 'customer_web', 'current_sales',
    'global_account', 'as_customer', 'facility_supplier', 'additional_notes', 'status',
];
// Integer columns (blank -> NULL, else cast). Everything else is trimmed text.
const QUOTE_INT_FIELDS  = ['eau', 'release_qty'];
// DATE columns (blank -> NULL, kept as YYYY-MM-DD text for the DATE type).
const QUOTE_DATE_FIELDS = ['quote_requested_date', 'first_build_date', 'production_date', 'pre_bid_meeting_date'];
const QUOTE_STATUSES    = ['Draft', 'Quoting', 'Submitted', 'Won', 'Lost'];

// --- Quote header ------------------------------------------------------------
function list_quotes(int $limit = 200): array
{
    $sql = 'SELECT q.id, q.quote_id, q.quote_number, q.tsg_number, q.customer, q.part_number, q.description,
                   q.revision, q.eau, q.status, q.created_at, q.updated_at,
                   COUNT(l.id) AS line_count
            FROM quotes q
            LEFT JOIN quote_bom_lines l ON l.quote_id = q.id
            GROUP BY q.id
            ORDER BY q.updated_at DESC, q.id DESC
            LIMIT ' . (int) $limit;
    return db()->query($sql)->fetchAll();
}

function get_quote(int $id): ?array
{
    $st = db()->prepare(
        'SELECT q.*, u.email AS created_by_email, g.name AS plant_name
         FROM quotes q
         LEFT JOIN users u ON u.id = q.created_by
         LEFT JOIN orgs  g ON g.inventory_org = q.inventory_org
         WHERE q.id = ?'
    );
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

// Next sequential quote number "Q-<YYYY>-<4-digit seq>", unique, derived from the highest
// existing sequence already used THIS year (legacy/other-year numbers don't collide).
function generate_quote_number(): string
{
    $year = date('Y');
    $prefix = "Q-$year-";
    $st = db()->prepare('SELECT quote_number FROM quotes WHERE quote_number LIKE ?');
    $st->execute([$prefix . '%']);
    $max = 0;
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $qn) {
        if (preg_match('/^' . preg_quote($prefix, '/') . '(\d+)$/', (string) $qn, $m)) {
            $max = max($max, (int) $m[1]);
        }
    }
    // Guard against a stray hand-entered duplicate — walk forward until the candidate is free.
    do {
        $max++;
        $candidate = $prefix . str_pad((string) $max, 4, '0', STR_PAD_LEFT);
        $chk = db()->prepare('SELECT COUNT(*) FROM quotes WHERE quote_number = ?');
        $chk->execute([$candidate]);
    } while ((int) $chk->fetchColumn() > 0);
    return $candidate;
}

// Resolve a Part Number entry and pull the header fields tied to it from the item master.
// The app-wide "%" wildcard works here too, but the header names ONE part — it only
// resolves when the pattern matches exactly one item-master part number.
// Returns [$resolvedPart, $autofill (col => value), $warning|null].
function quote_part_autofill(string $partNo): array
{
    $partNo = trim($partNo);
    if ($partNo === '') return ['', [], null];
    $resolved = $partNo;
    if (strpos($partNo, '%') !== false) {
        $st = db()->prepare('SELECT DISTINCT item_number FROM items WHERE item_number LIKE ? ORDER BY item_number LIMIT 2');
        $st->execute([$partNo]);
        $m = $st->fetchAll(PDO::FETCH_COLUMN);
        if (count($m) !== 1) {
            return [$partNo, [], count($m)
                ? "\"$partNo\" matches more than one item-master part — Part Number left as typed."
                : "No item-master parts match \"$partNo\" — Part Number left as typed."];
        }
        $resolved = $m[0];
    }
    $st = db()->prepare(
        'SELECT MIN(description) AS description, MIN(sim_number) AS sim_number,
                MIN(organization) AS organization
         FROM items WHERE item_number = ? GROUP BY item_number'
    );
    $st->execute([$resolved]);
    $it = $st->fetch();
    if (!$it) return [$resolved, [], "$resolved isn't in the item master — nothing to autofill."];

    $fill = ['description' => $it['description'], 'kit_sim' => $it['sim_number']];
    // items.organization reads "A10 - Little Rock Assembly (MFG)" (or "3908 - …") — the
    // leading token matches orgs.inventory_org or orgs.plant_code.
    $tok = trim(explode(' - ', (string) $it['organization'], 2)[0]);
    if ($tok !== '') {
        $st = db()->prepare('SELECT inventory_org FROM orgs WHERE inventory_org = ? OR plant_code = ? LIMIT 1');
        $st->execute([$tok, $tok]);
        if ($org = $st->fetchColumn()) $fill['inventory_org'] = $org;
    }
    return [$resolved, array_filter($fill, fn($v) => $v !== null && $v !== ''), null];
}

// Match a customer + assembly plant to a Program Manager from program_assignments.
// program_assignments.plant_site is free text like "Little Rock (3908)" — matched against
// the org's plant_code (in parens) or its name with " Assembly" stripped ("Little Rock").
// Builds the whole customer|org -> pm index in one pass (both tables are small — the whole
// index is also embedded client-side for the JS auto-fill, see quote.php).
function pm_lookup_index(): array
{
    $orgs = db()->query('SELECT inventory_org, plant_code, name FROM orgs')->fetchAll();
    $rows = db()->query(
        "SELECT customer, plant_site, pm FROM program_assignments
         WHERE pm IS NOT NULL AND pm <> '' AND plant_site IS NOT NULL AND plant_site <> ''"
    )->fetchAll();

    $idx = [];
    foreach ($rows as $r) {
        $site = (string) $r['plant_site'];
        foreach ($orgs as $o) {
            $city = trim(str_ireplace('Assembly', '', (string) $o['name']));
            $matches = (stripos($site, '(' . $o['plant_code'] . ')') !== false)
                     || ($city !== '' && stripos($site, $city) !== false);
            if (!$matches) continue;
            $key = strtolower(trim($r['customer'])) . '|' . $o['inventory_org'];
            if (!isset($idx[$key])) $idx[$key] = $r['pm'];
        }
    }
    return $idx;
}

function find_program_manager(string $customer, string $org): ?string
{
    $customer = trim($customer); $org = trim($org);
    if ($customer === '' || $org === '') return null;
    $idx = pm_lookup_index();
    return $idx[strtolower($customer) . '|' . $org] ?? null;
}

// Create a shell quote (customer + part are enough to start). The part number resolves
// through the item master (wildcard allowed) and its tied fields prefill. A quote number
// is assigned immediately (also re-checked/assigned on every save, in case this ever runs
// on a legacy row). Returns the new id.
function create_quote(int $userId, string $customer, string $partNumber): int
{
    [$part, $fill] = quote_part_autofill($partNumber);
    db()->prepare(
        'INSERT INTO quotes (quote_number, customer, part_number, description, kit_sim, inventory_org, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    )->execute([
        generate_quote_number(),
        $customer !== '' ? $customer : null,
        $part !== '' ? $part : null,
        $fill['description'] ?? null,
        $fill['kit_sim'] ?? null,
        $fill['inventory_org'] ?? null,
        $userId,
    ]);
    return (int) db()->lastInsertId();
}

// Update the Bid Prep header from a posted field map. Only QUOTE_FIELDS are honoured;
// ints/dates are normalised; blanks become NULL. Returns [true, null] or [false, message].
function update_quote(int $id, array $post): array
{
    $sets = [];
    $vals = [];
    foreach (QUOTE_FIELDS as $f) {
        if (!array_key_exists($f, $post)) continue;
        $raw = is_string($post[$f]) ? trim($post[$f]) : $post[$f];
        if ($f === 'status' && !in_array($raw, QUOTE_STATUSES, true)) {
            return [false, 'Invalid status.'];
        }
        if ($raw === '' || $raw === null) {
            $val = null;
        } elseif (in_array($f, QUOTE_INT_FIELDS, true)) {
            $val = (int) $raw;
        } elseif (in_array($f, QUOTE_DATE_FIELDS, true)) {
            $val = preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw) ? $raw : null;
        } else {
            $val = $raw;
        }
        $sets[] = "$f = ?";
        $vals[] = $val;
    }
    if (!$sets) return [true, null];
    $vals[] = $id;
    db()->prepare('UPDATE quotes SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($vals);
    return [true, null];
}

function delete_quote(int $id): void
{
    db()->prepare('DELETE FROM quotes WHERE id = ?')->execute([$id]);   // cascades to lines/tiers/revs
}

// --- Costed BOM lines --------------------------------------------------------
// Type dropdown (sits directly right of Lvl): items.item_type -> line_type mapping.
const BOM_LINE_TYPES = ['Buy item', 'Sub-assembly', 'OSP'];

function bom_type_label(?string $itemType): string
{
    switch (strtoupper(trim((string) $itemType))) {
        case 'WES-ETO': return 'Sub-assembly';
        case 'WES-OSP': return 'OSP';
        default:        return 'Buy item';       // WES-PUR-RE and anything unrecognized
    }
}

// Normalise a stored/posted line_type into one of BOM_LINE_TYPES for the <select> — tolerates
// the pre-Batch-2 free-text values ("Sub Assembly" / "Purchase Item") from older rows.
function bom_line_type_normalize(?string $v): string
{
    $v = trim((string) $v);
    if (in_array($v, BOM_LINE_TYPES, true)) return $v;
    if (strcasecmp($v, 'Sub Assembly') === 0)  return 'Sub-assembly';
    if (strcasecmp($v, 'Purchase Item') === 0) return 'Buy item';
    return 'Buy item';
}

// Fields locked (greyed out, ignored server-side) on a Sub-assembly BOM line — they don't
// apply to a sub-assembly, which carries its own costed BOM elsewhere.
const BOM_SUBASSEMBLY_LOCKED_FIELDS = [
    'standard_cost', 'moq', 'flm', 'manufacturer', 'project_supplier',
    'sim_supplier_item', 'quote_number', 'crossed_items',
];

function list_bom_lines(int $quoteId): array
{
    $st = db()->prepare('SELECT * FROM quote_bom_lines WHERE quote_id = ? ORDER BY sort_order, id');
    $st->execute([$quoteId]);
    return $st->fetchAll();
}

function get_bom_line(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM quote_bom_lines WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

// Editable BOM columns (excludes id/quote_id/sort_order, which are managed).
const BOM_FIELDS = [
    'level', 'customer_pn', 'mfg_item', 'description', 'uom', 'qty_per', 'line_type',
    'moq', 'flm', 'lead_time_weeks', 'manufacturer', 'project_supplier',
    'sim_supplier_item', 'quote_number', 'notes', 'crossed_items', 'standard_cost',
];
const BOM_INT_FIELDS = ['level', 'moq', 'flm', 'lead_time_weeks'];
const BOM_DEC_FIELDS = ['qty_per', 'standard_cost'];

// Normalise a posted BOM field map into [column => value] using the whitelist above.
function normalise_bom_fields(array $post): array
{
    $out = [];
    foreach (BOM_FIELDS as $f) {
        $raw = isset($post[$f]) && is_string($post[$f]) ? trim($post[$f]) : ($post[$f] ?? '');
        if ($f === 'line_type') {
            $out[$f] = bom_line_type_normalize((string) $raw);
            continue;
        }
        if ($raw === '' || $raw === null) {
            $out[$f] = ($f === 'qty_per') ? 1 : null;              // qty_per defaults to 1
        } elseif (in_array($f, BOM_INT_FIELDS, true)) {
            $out[$f] = (int) $raw;
        } elseif (in_array($f, BOM_DEC_FIELDS, true)) {
            $out[$f] = is_numeric($raw) ? (float) $raw : (($f === 'qty_per') ? 1 : null);
        } else {
            $out[$f] = $raw;
        }
    }
    return $out;
}

// $vals must already be a normalised BOM_FIELDS map (see normalise_bom_fields). Returns the
// new line's id.
function add_bom_line(int $quoteId, array $vals): int
{
    $st = db()->prepare('SELECT COALESCE(MAX(sort_order), 0) + 1 FROM quote_bom_lines WHERE quote_id = ?');
    $st->execute([$quoteId]);
    $sort = (int) $st->fetchColumn();

    $cols = array_merge(['quote_id', 'sort_order'], BOM_FIELDS);
    $ph   = implode(', ', array_fill(0, count($cols), '?'));
    $params = array_merge([$quoteId, $sort], array_map(fn($f) => $vals[$f], BOM_FIELDS));
    db()->prepare('INSERT INTO quote_bom_lines (' . implode(', ', $cols) . ") VALUES ($ph)")
        ->execute($params);
    return (int) db()->lastInsertId();
}

// $vals must already be a normalised BOM_FIELDS map (see normalise_bom_fields).
function update_bom_line(int $id, array $vals): void
{
    $sets = implode(', ', array_map(fn($f) => "$f = ?", BOM_FIELDS));
    $params = array_merge(array_map(fn($f) => $vals[$f], BOM_FIELDS), [$id]);
    db()->prepare("UPDATE quote_bom_lines SET $sets WHERE id = ?")->execute($params);
}

function delete_bom_line(int $id): void
{
    db()->prepare('DELETE FROM quote_bom_lines WHERE id = ?')->execute([$id]);   // cascades price breaks
}

// Per-unit unburdened material cost = Σ(standard_cost × qty_per) across BOM lines.
// This is the "Component cost" input the Quote Summary rolls up (same figure feeds §21's
// legacy cost_rollup() too, for anything still calling it).
function quote_material_per_unit(int $quoteId): float
{
    $st = db()->prepare(
        'SELECT COALESCE(SUM(standard_cost * qty_per), 0) FROM quote_bom_lines
         WHERE quote_id = ? AND standard_cost IS NOT NULL'
    );
    $st->execute([$quoteId]);
    return (float) $st->fetchColumn();
}

// --- Item-warehouse lookup for the BOM typeahead (quote-item-suggest.php) ----
// Wildcard-friendly CONTAINS match on item # or description; excludes obsolete-looking
// statuses (items.item_status has only ever shown "Active" in this install's data, but the
// real Oracle export can carry others — anything with "obsolete" in it is excluded).
function bom_lookup_items(string $term, int $limit = 20): array
{
    $term = trim($term);
    if ($term === '') return [];
    $like = '%' . $term . '%';
    $st = db()->prepare(
        "SELECT item_number, MIN(description) AS description, MIN(item_type) AS item_type,
                MIN(primary_uom) AS primary_uom, MIN(min_order_qty) AS moq, MIN(flm) AS flm,
                MIN(supplier) AS supplier, MIN(supplier_item) AS supplier_item
         FROM items
         WHERE (item_number LIKE ? OR description LIKE ?)
           AND (item_status IS NULL OR item_status NOT LIKE '%Obsolete%')
         GROUP BY item_number
         ORDER BY item_number
         LIMIT " . max(1, min(50, $limit))
    );
    $st->execute([$like, $like]);
    $rows = $st->fetchAll();
    foreach ($rows as &$r) $r['type_label'] = bom_type_label($r['item_type']);
    unset($r);
    return $rows;
}

// --- Per-line volume price breaks (quote_bom_price_breaks) -------------------
function list_bom_price_breaks(int $lineId): array
{
    $st = db()->prepare('SELECT * FROM quote_bom_price_breaks WHERE bom_line_id = ? ORDER BY min_qty');
    $st->execute([$lineId]);
    return $st->fetchAll();
}

// Std Cost auto-resolution: the largest min_qty <= the line's MOQ. Null if there are no
// breaks, or the MOQ doesn't reach any of them.
function resolve_std_cost_from_breaks(array $breaks, ?int $moq): ?float
{
    if (!$breaks || $moq === null) return null;
    $best = null;
    foreach ($breaks as $b) {
        $min = (int) $b['min_qty'];
        if ($min <= $moq && ($best === null || $min > (int) $best['min_qty'])) $best = $b;
    }
    return $best ? (float) $best['unit_price'] : null;
}

// Sync one BOM line's price-break sub-rows from posted edit/delete/add maps, appending
// human-readable change lines. Throws on a duplicate min_qty (caught by save_quote_all's
// transaction, which rolls back with the message).
function sync_bom_breaks(int $lineId, string $name, ?array $edits, ?array $deletes, ?array $adds, array &$changes): void
{
    $existing = list_bom_price_breaks($lineId);
    $finalMins = [];
    foreach ($existing as $b) $finalMins[(int) $b['id']] = (int) $b['min_qty'];

    foreach ($existing as $b) {
        $bid = (int) $b['id'];
        if (!empty($deletes[$bid])) {
            db()->prepare('DELETE FROM quote_bom_price_breaks WHERE id = ?')->execute([$bid]);
            $changes[] = "BOM $name: price break removed (min " . (int) $b['min_qty'] . ')';
            unset($finalMins[$bid]);
            continue;
        }
        if (!isset($edits[$bid]) || !is_array($edits[$bid])) continue;
        $minRaw   = trim((string) ($edits[$bid]['min_qty'] ?? ''));
        $priceRaw = trim((string) ($edits[$bid]['unit_price'] ?? ''));
        $min   = ($minRaw !== '' && is_numeric($minRaw)) ? (int) $minRaw : (int) $b['min_qty'];
        $price = ($priceRaw !== '' && is_numeric($priceRaw)) ? (float) $priceRaw : (float) $b['unit_price'];
        if (qchanged($b['min_qty'], $min) || qchanged($b['unit_price'], $price)) {
            $others = $finalMins; unset($others[$bid]);
            if (in_array($min, $others, true)) {
                throw new RuntimeException("BOM $name: two price breaks can't share the same min qty ($min).");
            }
            db()->prepare('UPDATE quote_bom_price_breaks SET min_qty = ?, unit_price = ? WHERE id = ?')
                ->execute([$min, $price, $bid]);
            $changes[] = "BOM $name: price break min " . (int) $b['min_qty'] . " → min $min @ \$" . number_format($price, 4);
            $finalMins[$bid] = $min;
        }
    }
    foreach ((array) $adds as $row) {
        if (!is_array($row)) continue;
        $minRaw   = trim((string) ($row['min_qty'] ?? ''));
        $priceRaw = trim((string) ($row['unit_price'] ?? ''));
        if ($minRaw === '' && $priceRaw === '') continue;                     // untouched blank sub-row
        if (!is_numeric($minRaw) || !is_numeric($priceRaw)) continue;
        $min = (int) $minRaw; $price = (float) $priceRaw;
        if (in_array($min, $finalMins, true)) {
            throw new RuntimeException("BOM $name: two price breaks can't share the same min qty ($min).");
        }
        db()->prepare('INSERT INTO quote_bom_price_breaks (bom_line_id, min_qty, unit_price) VALUES (?, ?, ?)')
            ->execute([$lineId, $min, $price]);
        $changes[] = "BOM $name: price break added (min $min @ \$" . number_format($price, 4) . ')';
        $finalMins[] = $min;
    }
}

// --- Labor Breakdown (formerly "Cost roll-up") -------------------------------
const LABOR_TYPES = ['Production', 'Engineering'];

function normalize_labor_type(?string $v): string
{
    return strcasecmp(trim((string) $v), 'Engineering') === 0 ? 'Engineering' : 'Production';
}

function list_cost_tiers(int $quoteId): array
{
    $st = db()->prepare('SELECT * FROM quote_cost_tiers WHERE quote_id = ? ORDER BY sort_order, build_qty, id');
    $st->execute([$quoteId]);
    return $st->fetchAll();
}

function get_cost_tier(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM quote_cost_tiers WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

// Distinct build quantities in play across the Labor Breakdown — these ARE the Quote
// Summary's tiers.
function list_cost_tier_build_qtys(int $quoteId): array
{
    $st = db()->prepare('SELECT DISTINCT build_qty FROM quote_cost_tiers WHERE quote_id = ? ORDER BY build_qty');
    $st->execute([$quoteId]);
    return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
}

// Legacy per-tier roll-up (§21) — burden/OSP/margin all live on the ONE quote_cost_tiers
// row. Superseded by the Quote Summary block for display, but kept (and still correct) for
// any row that still carries its own burden/margin values.
function cost_rollup(array $tier, float $materialPerUnit): array
{
    $burden = (float) $tier['burden'];
    $margin = (float) $tier['margin'];
    $osp    = (float) $tier['osp_labor'];
    $bd     = ($burden < 1) ? (1 - $burden) : 1e-9;   // guard against ÷0 / nonsense >=100%
    $mg     = ($margin < 1) ? (1 - $margin) : 1e-9;

    $burdenedMaterial = $materialPerUnit / $bd;
    $laborPerUnit     = ((float) $tier['labor_rate'] * (float) $tier['labor_hours']) / $bd;
    $transfer         = $burdenedMaterial + $laborPerUnit + $osp;
    $resale           = $transfer / $mg;
    return [
        'unburdened_material' => $materialPerUnit,
        'burdened_material'   => $burdenedMaterial,
        'labor_per_unit'      => $laborPerUnit,
        'osp_labor'           => $osp,
        'transfer_cost'       => $transfer,
        'resale'              => $resale,
        'ext_resale'          => $resale * max(1, (int) $tier['build_qty']),
    ];
}

// NOTE: burden/osp_labor/margin used to live here too (§21) — Batch 2 moved them to the
// Quote Summary block (quote_summary_tiers), computed per BUILD QTY rather than per labor
// row. The DB columns stay (NOT NULL DEFAULT 0) for back-compat with cost_rollup(), but this
// save path no longer reads or writes them — leaving them out of the diff/column list is
// what keeps a save with nothing actually posted for them from logging a false "0 -> blank"
// change on every single save.
const COST_TIER_FIELDS = ['label', 'labor_type', 'build_qty', 'labor_rate', 'labor_hours'];

// Insert or update a Labor Breakdown row. Returns [true, null] or [false, message].
function save_cost_tier(int $quoteId, ?int $id, array $post): array
{
    $buildQty = max(1, (int) ($post['build_qty'] ?? 1));
    $vals = [
        'label'       => trim($post['label'] ?? '') ?: null,
        'labor_type'  => normalize_labor_type($post['labor_type'] ?? 'Production'),
        'build_qty'   => $buildQty,
        'labor_rate'  => (float) ($post['labor_rate'] ?? 0),
        'labor_hours' => (float) ($post['labor_hours'] ?? 0),
    ];
    if ($id) {
        $sets = implode(', ', array_map(fn($f) => "$f = ?", COST_TIER_FIELDS));
        $params = array_merge(array_map(fn($f) => $vals[$f], COST_TIER_FIELDS), [$id, $quoteId]);
        db()->prepare("UPDATE quote_cost_tiers SET $sets WHERE id = ? AND quote_id = ?")->execute($params);
    } else {
        $st = db()->prepare('SELECT COALESCE(MAX(sort_order), 0) + 1 FROM quote_cost_tiers WHERE quote_id = ?');
        $st->execute([$quoteId]);
        $sort = (int) $st->fetchColumn();
        $cols = array_merge(['quote_id', 'sort_order'], COST_TIER_FIELDS);
        $ph   = implode(', ', array_fill(0, count($cols), '?'));
        $params = array_merge([$quoteId, $sort], array_map(fn($f) => $vals[$f], COST_TIER_FIELDS));
        db()->prepare('INSERT INTO quote_cost_tiers (' . implode(', ', $cols) . ") VALUES ($ph)")->execute($params);
    }
    return [true, null];
}

function delete_cost_tier(int $id): void
{
    db()->prepare('DELETE FROM quote_cost_tiers WHERE id = ?')->execute([$id]);
}

// --- Quote Summary (quote_summary_tiers) -------------------------------------
// Transfer Price = burden markup on material AND labor, each burdened by the PLANT's own
// preset (materials vs. labor can differ — see presets.php/Quoting Presets), consistent
// with §21's F+G convention:
//   Transfer = material/(1 - plant_burden_materials) + labor/(1 - plant_burden_labor)
//   Sale     = Transfer / (1 - margin)                    (margin blank -> 25% default)
function compute_summary_tier(float $componentCost, float $laborCost, float $burdenMat, float $burdenLabor, ?float $margin): array
{
    $bm = ($burdenMat   < 1) ? (1 - $burdenMat)   : 1e-9;
    $bl = ($burdenLabor < 1) ? (1 - $burdenLabor) : 1e-9;
    $mg = $margin ?? 0.25;
    $mgDenom = ($mg < 1) ? (1 - $mg) : 1e-9;

    $transfer = ($componentCost / $bm) + ($laborCost / $bl);
    $sale     = $transfer / $mgDenom;
    return ['transfer_price' => $transfer, 'sale_price' => $sale, 'effective_margin' => $mg];
}

// Keyed by build_qty for easy lookup while rendering / diffing.
function list_summary_tiers(int $quoteId): array
{
    $st = db()->prepare('SELECT * FROM quote_summary_tiers WHERE quote_id = ? ORDER BY build_qty');
    $st->execute([$quoteId]);
    $out = [];
    foreach ($st->fetchAll() as $r) $out[(int) $r['build_qty']] = $r;
    return $out;
}

// --- Revision log (Quote Rev) ------------------------------------------------
function list_revisions(int $quoteId): array
{
    $st = db()->prepare('SELECT * FROM quote_revisions WHERE quote_id = ? ORDER BY rev_no, id');
    $st->execute([$quoteId]);
    return $st->fetchAll();
}

function add_revision(int $quoteId, array $post): array
{
    $revNo = trim($post['rev_no'] ?? '');
    if ($revNo === '') return [false, 'Rev # is required.'];
    $date = trim($post['rev_date'] ?? '');
    $date = preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ? $date : null;
    db()->prepare(
        'INSERT INTO quote_revisions (quote_id, rev_no, rev_date, approved_by, description)
         VALUES (?, ?, ?, ?, ?)'
    )->execute([
        $quoteId, $revNo, $date,
        trim($post['approved_by'] ?? '') ?: null,
        trim($post['description'] ?? '') ?: null,
    ]);
    return [true, null];
}

function delete_revision(int $id): void
{
    db()->prepare('DELETE FROM quote_revisions WHERE id = ?')->execute([$id]);
}

// --- One-shot save (whole workspace) + auto revision log ----------------------
// The quote page posts EVERYTHING at once (header + every BOM line/price-break + labor
// lines). save_quote_all() diffs each piece against the DB, applies the changes in one
// transaction, and — if anything actually changed — logs ONE revision whose `changes`
// column lists every field that moved. No change → no revision.

// Loose equality for diffing form input against DB values: NULL == '' and numerics
// compare as numbers ("46.50" == "46.5"), so retyping the same value never logs.
function qchanged($old, $new): bool
{
    $o = $old === null ? '' : trim((string) $old);
    $n = $new === null ? '' : trim((string) $new);
    if ($o === $n) return false;
    if ($o !== '' && $n !== '' && is_numeric($o) && is_numeric($n)) return (float) $o !== (float) $n;
    return true;
}

function qfmt($v): string { return ($v === null || trim((string) $v) === '') ? '—' : trim((string) $v); }
function qlabel(string $f): string { return ucwords(str_replace('_', ' ', $f)); }

// Format a fraction (0.25) as a percent string ("25%") for change-log readability; null/blank
// reads as "default 25%" (the Quote Summary's margin-blank convention).
function qpct(?float $frac): string
{
    if ($frac === null) return 'default 25%';
    return rtrim(rtrim(number_format($frac * 100, 2), '0'), '.') . '%';
}

// Apply the whole-workspace form. Returns [ok, err, changeCount, warnings[]].
function save_quote_all(int $id, array $post, string $savedBy): array
{
    $pdo = db();
    $quote = get_quote($id);
    if (!$quote) return [false, 'Quote not found.', 0, []];
    $changes  = [];
    $warnings = [];

    // ── Part Number resolution + tied-field autofill (before the diff, so the fills are
    // logged like any other change). The wildcard resolves when it names exactly one part;
    // item-master values fill ONLY fields left empty — typed values are never overwritten.
    if (array_key_exists('part_number', $post)) {
        [$resolved, $fill, $warn] = quote_part_autofill(trim((string) $post['part_number']));
        $post['part_number'] = $resolved;
        if ($warn) $warnings[] = $warn;
        foreach ($fill as $f => $val) {
            if (trim((string) ($post[$f] ?? '')) === '') $post[$f] = $val;
        }
    }

    // ── Program Manager auto-fill: only when left empty, from the (possibly just-typed)
    // customer + assembly plant matched against program_assignments (see pm_lookup_index()).
    if (trim((string) ($post['program_manager'] ?? '')) === '') {
        $cust = trim((string) ($post['customer'] ?? $quote['customer'] ?? ''));
        $org  = trim((string) ($post['inventory_org'] ?? $quote['inventory_org'] ?? ''));
        $pm = find_program_manager($cust, $org);
        if ($pm) $post['program_manager'] = $pm;
    }

    $pdo->beginTransaction();
    try {
        // ── Header (Bid Prep + new header block) — diff each whitelisted field, one UPDATE.
        $sets = []; $vals = [];
        foreach (QUOTE_FIELDS as $f) {
            if (!array_key_exists($f, $post)) continue;
            $raw = is_string($post[$f]) ? trim($post[$f]) : $post[$f];
            if ($f === 'status' && !in_array($raw, QUOTE_STATUSES, true)) {
                throw new RuntimeException('Invalid status.');
            }
            if ($raw === '' || $raw === null) {
                $val = null;
            } elseif (in_array($f, QUOTE_INT_FIELDS, true)) {
                $val = (int) $raw;
            } elseif (in_array($f, QUOTE_DATE_FIELDS, true)) {
                $val = preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw) ? $raw : null;
            } else {
                $val = $raw;
            }
            if (qchanged($quote[$f], $val)) {
                $changes[] = qlabel($f) . ': ' . qfmt($quote[$f]) . ' → ' . qfmt($val);
                $sets[] = "$f = ?"; $vals[] = $val;
            }
        }
        if ($sets) {
            $vals[] = $id;
            $pdo->prepare('UPDATE quotes SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($vals);
        }

        // ── Quote Number: system-assigned, only when blank.
        if (empty($quote['quote_number'])) {
            $qn = generate_quote_number();
            $pdo->prepare('UPDATE quotes SET quote_number = ? WHERE id = ?')->execute([$qn, $id]);
            $changes[] = 'Quote Number: — → ' . $qn;
        }

        // The plant in effect for THIS save (header may have just changed it) — used below
        // for labor-rate auto-fill and the Quote Summary burdens.
        $org = trim((string) ($post['inventory_org'] ?? $quote['inventory_org'] ?? ''));

        // ── Existing BOM lines: per-field diffs, type-lock, price breaks, deletions.
        $postedLines = $post['line'] ?? [];
        $deleteLines = $post['line_delete'] ?? [];
        $breakEdits  = $post['break'] ?? [];
        $breakDelete = $post['break_delete'] ?? [];
        $breakAdds   = $post['break_new'] ?? [];
        foreach (list_bom_lines($id) as $l) {
            $lid  = (int) $l['id'];
            $name = $l['mfg_item'] ?: ($l['customer_pn'] ?: "line #$lid");
            if (!empty($deleteLines[$lid])) {
                delete_bom_line($lid);
                $changes[] = "BOM removed: $name";
                continue;
            }
            if (!isset($postedLines[$lid]) || !is_array($postedLines[$lid])) continue;
            $new = normalise_bom_fields($postedLines[$lid]);
            $isSub = ($new['line_type'] === 'Sub-assembly');
            if ($isSub) foreach (BOM_SUBASSEMBLY_LOCKED_FIELDS as $f) $new[$f] = null;

            sync_bom_breaks($lid, $name, $breakEdits[$lid] ?? null, $breakDelete[$lid] ?? null, $breakAdds[$lid] ?? null, $changes);
            if (!$isSub) {
                $breaks = list_bom_price_breaks($lid);
                if ($breaks) {
                    $resolved = resolve_std_cost_from_breaks($breaks, $new['moq']);
                    if ($resolved !== null) $new['standard_cost'] = $resolved;
                }
            }

            $lineChanges = [];
            foreach (BOM_FIELDS as $f) {
                if (qchanged($l[$f], $new[$f])) $lineChanges[] = qlabel($f) . ' ' . qfmt($l[$f]) . ' → ' . qfmt($new[$f]);
            }
            if ($lineChanges) {
                update_bom_line($lid, $new);
                $changes[] = "BOM $name: " . implode('; ', $lineChanges);
            }
        }

        // ── Brand-new BOM lines (added client-side via "+ New Line", no reload).
        $newLines  = $post['newline'] ?? [];
        $newBreaks = $post['newline_break'] ?? [];
        foreach ($newLines as $key => $row) {
            if (!is_array($row)) continue;
            $hasContent = false;
            foreach ($row as $f => $v) {
                if ($f !== 'line_type' && trim((string) $v) !== '') { $hasContent = true; break; }
            }
            if (!$hasContent) continue;                                   // untouched template row

            $new = normalise_bom_fields($row);
            $isSub = ($new['line_type'] === 'Sub-assembly');
            if ($isSub) foreach (BOM_SUBASSEMBLY_LOCKED_FIELDS as $f) $new[$f] = null;

            $newId = add_bom_line($id, $new);
            $name = $new['mfg_item'] ?: ($new['customer_pn'] ?: 'new line');
            sync_bom_breaks($newId, $name, null, null, $newBreaks[$key] ?? null, $changes);
            if (!$isSub) {
                $breaks = list_bom_price_breaks($newId);
                if ($breaks) {
                    $resolved = resolve_std_cost_from_breaks($breaks, $new['moq']);
                    if ($resolved !== null) {
                        $pdo->prepare('UPDATE quote_bom_lines SET standard_cost = ? WHERE id = ?')->execute([$resolved, $newId]);
                    }
                }
            }
            $changes[] = "BOM added: $name";
        }

        // ── Existing Labor Breakdown rows: per-field diffs, rate auto-fill, deletions.
        $postedTiers = $post['tier'] ?? [];
        $deleteTiers = $post['tier_delete'] ?? [];
        foreach (list_cost_tiers($id) as $t) {
            $tid  = (int) $t['id'];
            $name = ($t['labor_type'] ?: 'Production') . ' — qty ' . (int) $t['build_qty'];
            if (!empty($deleteTiers[$tid])) {
                delete_cost_tier($tid);
                $changes[] = "Labor line removed: $name";
                continue;
            }
            if (!isset($postedTiers[$tid]) || !is_array($postedTiers[$tid])) continue;
            $row = $postedTiers[$tid];
            $laborType = normalize_labor_type($row['labor_type'] ?? $t['labor_type']);
            $row['labor_type'] = $laborType;
            if (trim((string) ($row['labor_rate'] ?? '')) === '') {
                $rate = labor_rate_for($org, $laborType);
                if ($rate !== null) $row['labor_rate'] = (string) $rate;
            }
            $tierChanges = [];
            foreach (COST_TIER_FIELDS as $f) {
                $raw = ($f === 'labor_type') ? $laborType : trim((string) ($row[$f] ?? ''));
                if (qchanged($t[$f], $raw)) $tierChanges[] = qlabel($f) . ' ' . qfmt($t[$f]) . ' → ' . qfmt($raw);
            }
            if ($tierChanges) {
                [$ok, $err] = save_cost_tier($id, $tid, $row);
                if (!$ok) throw new RuntimeException($err);
                $changes[] = "Labor line $name: " . implode('; ', $tierChanges);
            }
        }
        // Brand-new Labor Breakdown rows (added client-side, keyed like the BOM's newline[]).
        foreach (($post['newtier'] ?? []) as $row) {
            if (!is_array($row)) continue;
            $bq = trim((string) ($row['build_qty'] ?? ''));
            if ($bq === '') continue;                                     // untouched template row
            $laborType = normalize_labor_type($row['labor_type'] ?? 'Production');
            $row['labor_type'] = $laborType;
            if (trim((string) ($row['labor_rate'] ?? '')) === '') {
                $rate = labor_rate_for($org, $laborType);
                if ($rate !== null) $row['labor_rate'] = (string) $rate;
            }
            [$ok, $err] = save_cost_tier($id, null, $row);
            if (!$ok) throw new RuntimeException($err);
            $changes[] = "Labor line added: $laborType, build qty $bq";
        }

        // ── Quote Summary: one tier per distinct Labor Breakdown build qty. Authoritative
        // recompute every save (component/labor cost + plant burdens); margin is the only
        // user input, persisted per tier (blank -> 25% default applied but NOT stored as 0.25,
        // so a later plant-burden change keeps recomputing off the true "use default" intent).
        $oldSummary = list_summary_tiers($id);
        $preset = $org !== '' ? get_quoting_preset($org) : null;
        $burdenMat   = $preset ? (float) $preset['plant_burden_materials'] : 0.0;
        $burdenLabor = $preset ? (float) $preset['plant_burden_labor']     : 0.0;
        $componentCost = quote_material_per_unit($id);
        $summaryPost = $post['summary'] ?? [];
        $keepQtys = [];
        foreach (list_cost_tier_build_qtys($id) as $bq) {
            $keepQtys[] = $bq;
            $st = $pdo->prepare('SELECT COALESCE(SUM(labor_rate * labor_hours), 0) FROM quote_cost_tiers WHERE quote_id = ? AND build_qty = ?');
            $st->execute([$id, $bq]);
            $laborCost = (float) $st->fetchColumn();

            $marginRaw = trim((string) ($summaryPost[$bq]['margin'] ?? ''));
            $marginFrac = ($marginRaw !== '' && is_numeric($marginRaw)) ? ((float) $marginRaw / 100) : null;
            $calc = compute_summary_tier($componentCost, $laborCost, $burdenMat, $burdenLabor, $marginFrac);

            $old = $oldSummary[$bq] ?? null;
            $pdo->prepare(
                'INSERT INTO quote_summary_tiers
                    (quote_id, build_qty, margin, component_cost, labor_cost, burden_materials, burden_labor, transfer_price, sale_price)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                    margin = VALUES(margin), component_cost = VALUES(component_cost), labor_cost = VALUES(labor_cost),
                    burden_materials = VALUES(burden_materials), burden_labor = VALUES(burden_labor),
                    transfer_price = VALUES(transfer_price), sale_price = VALUES(sale_price)'
            )->execute([$id, $bq, $marginFrac, $componentCost, $laborCost, $burdenMat, $burdenLabor, $calc['transfer_price'], $calc['sale_price']]);

            if (!$old) {
                $changes[] = "Quote Summary tier added: qty $bq (margin " . qpct($marginFrac) . ')';
            } elseif (qchanged($old['margin'], $marginFrac)) {
                $changes[] = "Quote Summary (qty $bq): Margin " . qpct($old['margin'] !== null ? (float) $old['margin'] : null) . ' → ' . qpct($marginFrac);
            }
        }
        foreach ($oldSummary as $bq => $row) {
            if (!in_array($bq, $keepQtys, true)) {
                $pdo->prepare('DELETE FROM quote_summary_tiers WHERE id = ?')->execute([$row['id']]);
                $changes[] = "Quote Summary tier removed: qty $bq";
            }
        }

        // ── One revision per save that changed anything.
        if ($changes) {
            $n = count($changes);
            $pdo->prepare(
                'INSERT INTO quote_revisions (quote_id, rev_no, rev_date, approved_by, description, changes)
                 VALUES (?, ?, CURDATE(), ?, ?, ?)'
            )->execute([
                $id, next_rev_no($id), $savedBy,
                "Saved from quote workspace ($n change" . ($n === 1 ? '' : 's') . ')',
                implode("\n", $changes),
            ]);
        }
        $pdo->commit();
        return [true, null, count($changes), $warnings];
    } catch (\Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return [false, $e->getMessage(), 0, []];
    }
}

// Next sequential rev # ("01", "02", …) — non-numeric legacy rev labels count as 0.
function next_rev_no(int $quoteId): string
{
    $st = db()->prepare('SELECT COALESCE(MAX(CAST(rev_no AS UNSIGNED)), 0) + 1 FROM quote_revisions WHERE quote_id = ?');
    $st->execute([$quoteId]);
    return str_pad((string) (int) $st->fetchColumn(), 2, '0', STR_PAD_LEFT);
}
