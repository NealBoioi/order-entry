<?php
// Quoting Presets — per-plant defaults (overhaul item 4a, §35/§36 of the Project Bible).
// Schema: app/sql/quoting_presets.sql (quoting_presets, one row per orgs.inventory_org).
//
// Storage convention (matches quote_cost_tiers.burden/margin exactly — see
// app/sql/quotes.sql + app/src/quotes.php::cost_rollup()): plant_burden_materials and
// plant_burden_labor are stored as a DECIMAL FRACTION 0-1 (0.15 = 15%). The page/these
// helpers accept and return burden as a PERCENT (0-100) at the save()/get() boundary —
// friendlier for plant-admin data entry — and do the /100, *100 conversion here so
// nothing above this file needs to know the DB stores a fraction.
require_once __DIR__ . '/db.php';

// Whitelisted, user-editable columns — mirrors the QUOTE_FIELDS pattern in src/quotes.php:
// nothing can be written that isn't in this map.
const PRESET_FIELDS = [
    'engineering_labor_rate', 'production_labor_rate',
    'plant_burden_materials', 'plant_burden_labor',
];

// All assembly plants (orgs), LEFT JOINed with their preset row so a plant with no
// preset yet still appears (preset_* fields come back NULL -> the page shows blanks).
// Burden fields are converted fraction -> percent here (×100) for display.
function list_quoting_presets(): array
{
    $rows = db()->query(
        'SELECT o.inventory_org, o.plant_code, o.name,
                p.engineering_labor_rate, p.production_labor_rate,
                p.plant_burden_materials, p.plant_burden_labor, p.updated_at
         FROM orgs o
         LEFT JOIN quoting_presets p ON p.inventory_org = o.inventory_org
         ORDER BY o.name, o.inventory_org'
    )->fetchAll();

    foreach ($rows as &$r) {
        $r['plant_burden_materials_pct'] = $r['plant_burden_materials'] !== null ? (float) $r['plant_burden_materials'] * 100 : null;
        $r['plant_burden_labor_pct']     = $r['plant_burden_labor']     !== null ? (float) $r['plant_burden_labor']     * 100 : null;
    }
    unset($r);
    return $rows;
}

// One plant's preset row, or null if it hasn't been saved yet. Burden fields come back
// as a PERCENT (0-100), converted from the stored fraction.
function get_quoting_preset(string $org): ?array
{
    $st = db()->prepare('SELECT * FROM quoting_presets WHERE inventory_org = ?');
    $st->execute([trim($org)]);
    $row = $st->fetch();
    if (!$row) return null;
    $row['plant_burden_materials_pct'] = (float) $row['plant_burden_materials'] * 100;
    $row['plant_burden_labor_pct']     = (float) $row['plant_burden_labor'] * 100;
    return $row;
}

// Upsert one plant's preset. $post carries the PAGE's field names (percent for the two
// burden inputs): engineering_labor_rate, production_labor_rate, plant_burden_materials
// (percent), plant_burden_labor (percent). Validates numeric + non-negative; burden
// percent must be 0-99.99 (mirrors the quote_cost_tiers guard against a >=100% burden,
// which would divide by zero in cost_rollup()). Returns [true, null] or [false, error].
function save_quoting_preset(string $org, array $post): array
{
    $org = trim($org);
    if ($org === '') return [false, 'Missing plant.'];

    $numeric = fn($v): bool => is_numeric(trim((string) $v));

    $eng  = trim((string) ($post['engineering_labor_rate'] ?? ''));
    $prod = trim((string) ($post['production_labor_rate'] ?? ''));
    $bMat = trim((string) ($post['plant_burden_materials'] ?? ''));
    $bLab = trim((string) ($post['plant_burden_labor'] ?? ''));

    // Blank = 0 (an empty preset field should save as 0, not reject).
    if ($eng === '')  $eng = '0';
    if ($prod === '') $prod = '0';
    if ($bMat === '') $bMat = '0';
    if ($bLab === '') $bLab = '0';

    foreach (['Engineering labor rate' => $eng, 'Production labor rate' => $prod,
              'Plant burden — materials' => $bMat, 'Plant burden — labor' => $bLab] as $label => $v) {
        if (!$numeric($v)) return [false, "$label must be a number."];
    }

    $eng  = (float) $eng;
    $prod = (float) $prod;
    $bMat = (float) $bMat;
    $bLab = (float) $bLab;

    if ($eng < 0)  return [false, 'Engineering labor rate can\'t be negative.'];
    if ($prod < 0) return [false, 'Production labor rate can\'t be negative.'];
    if ($bMat < 0 || $bMat >= 100) return [false, 'Plant burden — materials must be a percent from 0 to 99.99.'];
    if ($bLab < 0 || $bLab >= 100) return [false, 'Plant burden — labor must be a percent from 0 to 99.99.'];

    db()->prepare(
        'INSERT INTO quoting_presets
            (inventory_org, engineering_labor_rate, production_labor_rate, plant_burden_materials, plant_burden_labor)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
            engineering_labor_rate = VALUES(engineering_labor_rate),
            production_labor_rate  = VALUES(production_labor_rate),
            plant_burden_materials = VALUES(plant_burden_materials),
            plant_burden_labor     = VALUES(plant_burden_labor)'
    )->execute([$org, $eng, $prod, $bMat / 100, $bLab / 100]);

    return [true, null];
}

// The rate a later quote worker will pull for a given plant + labor type. $laborType is
// 'Production' or 'Engineering' (case-insensitive); returns null if the plant has no
// preset saved yet, or the type isn't recognized.
function labor_rate_for(string $org, string $laborType): ?float
{
    $preset = get_quoting_preset($org);
    if ($preset === null) return null;

    switch (strtolower(trim($laborType))) {
        case 'production':  return (float) $preset['production_labor_rate'];
        case 'engineering': return (float) $preset['engineering_labor_rate'];
        default:             return null;
    }
}
