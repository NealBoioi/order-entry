<?php
// Customer account setup + settings: per-user profile (name/title), address books for ship-to
// and bill-to, and saved ship methods. Backs account-setup.php, settings.php, addresses.php,
// admin-user-account.php, and prefills new-order.php.
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/geocode.php';

// ---- Titles offered in the profile dropdown ---------------------------------
const PROFILE_TITLES = ['Buyer', 'Inside Sales Rep', 'Outside Sales Rep', 'Purchasing Manager', 'Engineer', 'Other'];

// ---- Address verification gate ----------------------------------------------
// Every ship-to / bill-to save must resolve to a REAL address (blocks junk like "35").
const ADDRESS_UNVERIFIED_MSG = 'That street address could not be verified — pick a suggested address as you type, or double-check it for typos.';

function address_is_verified(array $data): bool
{
    [$ok] = geocode_verify(
        (string) ($data['addr1'] ?? ''), (string) ($data['city'] ?? ''),
        (string) ($data['state'] ?? ''), (string) ($data['zip'] ?? ''),
        (string) ($data['country'] ?? '')
    );
    return $ok;
}

// ---- Per-user profile (name/title) ------------------------------------------
function get_profile(int $uid): ?array
{
    $st = db()->prepare('SELECT * FROM customer_profiles WHERE user_id = ?');
    $st->execute([$uid]);
    return $st->fetch() ?: null;
}

function profile_complete(int $uid): bool
{
    $st = db()->prepare('SELECT setup_complete FROM customer_profiles WHERE user_id = ?');
    $st->execute([$uid]);
    return (int) $st->fetchColumn() === 1;
}

// Ensure a profile row exists (so ship addresses/defaults can attach before setup finishes).
function ensure_profile(int $uid): void
{
    db()->prepare('INSERT IGNORE INTO customer_profiles (user_id) VALUES (?)')->execute([$uid]);
}

// Save name/title/bill-to. $markComplete flips setup_complete. Returns [true,null]/[false,msg].
function save_profile_core(int $uid, array $post, bool $markComplete): array
{
    $name = trim($post['full_name'] ?? '');
    if ($name === '') return [false, 'Please enter your name.'];
    $data = ['full_name' => $name, 'title' => trim($post['title'] ?? '') ?: null];
    if (get_profile($uid)) {
        $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
        $sql = "UPDATE customer_profiles SET $set" . ($markComplete ? ', setup_complete = 1' : '') . ' WHERE user_id = ?';
        db()->prepare($sql)->execute(array_merge(array_values($data), [$uid]));
    } else {
        $cols = array_merge(['user_id'], array_keys($data), ['setup_complete']);
        $ph   = implode(', ', array_fill(0, count($cols), '?'));
        db()->prepare('INSERT INTO customer_profiles (' . implode(', ', $cols) . ") VALUES ($ph)")
            ->execute(array_merge([$uid], array_values($data), [$markComplete ? 1 : 0]));
    }
    return [true, null];
}

function set_setup_complete(int $uid): void
{
    db()->prepare('UPDATE customer_profiles SET setup_complete = 1 WHERE user_id = ?')->execute([$uid]);
}

// ---- Ship-to address book ---------------------------------------------------
const SHIP_FIELDS = ['label','attn','addr1','addr2','city','state','zip','country'];

function list_ship_addresses(int $uid): array
{
    $st = db()->prepare('SELECT * FROM customer_ship_addresses WHERE user_id = ? ORDER BY id');
    $st->execute([$uid]);
    return $st->fetchAll();
}

function get_ship_address(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM customer_ship_addresses WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

// Insert/update a ship address. Reads either `ship_<f>` or `<f>` from $post. Returns [true,id]/[false,msg].
function save_ship_address(int $uid, ?int $id, array $post): array
{
    $data = [];
    foreach (SHIP_FIELDS as $f) {
        $v = trim($post['ship_' . $f] ?? $post[$f] ?? '');
        if ($f === 'country' && $v === '') $v = 'USA';
        $data[$f] = $v !== '' ? $v : null;
    }
    foreach (['addr1' => 'street', 'city' => 'city', 'state' => 'state', 'zip' => 'ZIP'] as $f => $lbl) {
        if (($data[$f] ?? null) === null) return [false, "Ship-to needs a $lbl."];
    }
    if (!address_is_verified($data)) return [false, ADDRESS_UNVERIFIED_MSG];
    if ($id) {
        $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
        db()->prepare("UPDATE customer_ship_addresses SET $set WHERE id = ? AND user_id = ?")
            ->execute(array_merge(array_values($data), [$id, $uid]));
        return [true, $id];
    }
    $cols = array_merge(['user_id'], array_keys($data));
    $ph   = implode(', ', array_fill(0, count($cols), '?'));
    db()->prepare('INSERT INTO customer_ship_addresses (' . implode(', ', $cols) . ") VALUES ($ph)")
        ->execute(array_merge([$uid], array_values($data)));
    return [true, (int) db()->lastInsertId()];
}

function delete_ship_address(int $uid, int $id): void
{
    db()->prepare('DELETE FROM customer_ship_addresses WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
    // Clear the default pointer if it referenced the deleted row.
    db()->prepare('UPDATE customer_profiles SET default_ship_id = NULL WHERE user_id = ? AND default_ship_id = ?')
        ->execute([$uid, $id]);
}

// ---- Bill-to address book ---------------------------------------------------
const BILL_ADDR_FIELDS = ['label','company','addr1','addr2','city','state','zip','country'];

function list_bill_addresses(int $uid): array
{
    $st = db()->prepare('SELECT * FROM customer_bill_addresses WHERE user_id = ? ORDER BY id');
    $st->execute([$uid]);
    return $st->fetchAll();
}
function get_bill_address(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM customer_bill_addresses WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}
// Insert/update a bill address. Reads either `bill_<f>` (setup form) or `<f>` (address page).
function save_bill_address(int $uid, ?int $id, array $post): array
{
    $data = [];
    foreach (BILL_ADDR_FIELDS as $f) {
        $v = trim($post['bill_' . $f] ?? $post[$f] ?? '');
        if ($f === 'country' && $v === '') $v = 'USA';
        $data[$f] = $v !== '' ? $v : null;
    }
    foreach (['addr1' => 'street', 'city' => 'city', 'state' => 'state', 'zip' => 'ZIP'] as $f => $lbl) {
        if (($data[$f] ?? null) === null) return [false, "Bill-to needs a $lbl."];
    }
    if (!address_is_verified($data)) return [false, ADDRESS_UNVERIFIED_MSG];
    if ($id) {
        $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
        db()->prepare("UPDATE customer_bill_addresses SET $set WHERE id = ? AND user_id = ?")
            ->execute(array_merge(array_values($data), [$id, $uid]));
        return [true, $id];
    }
    $cols = array_merge(['user_id'], array_keys($data));
    $ph   = implode(', ', array_fill(0, count($cols), '?'));
    db()->prepare('INSERT INTO customer_bill_addresses (' . implode(', ', $cols) . ") VALUES ($ph)")
        ->execute(array_merge([$uid], array_values($data)));
    return [true, (int) db()->lastInsertId()];
}
function delete_bill_address(int $uid, int $id): void
{
    db()->prepare('DELETE FROM customer_bill_addresses WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
    db()->prepare('UPDATE customer_profiles SET default_bill_id = NULL WHERE user_id = ? AND default_bill_id = ?')->execute([$uid, $id]);
}

// ---- Ship methods -----------------------------------------------------------
const METHOD_FIELDS = ['label','terms','method','carrier_acct'];

function list_ship_methods(int $uid): array
{
    $st = db()->prepare('SELECT * FROM customer_ship_methods WHERE user_id = ? ORDER BY id');
    $st->execute([$uid]);
    return $st->fetchAll();
}

function get_ship_method(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM customer_ship_methods WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function save_ship_method(int $uid, ?int $id, array $post): array
{
    $data = [];
    foreach (METHOD_FIELDS as $f) { $v = trim($post[$f] ?? ''); $data[$f] = $v !== '' ? $v : null; }
    if (($data['method'] ?? null) === null) return [false, 'Enter a ship method (e.g. UPS Ground).'];
    if ($id) {
        $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
        db()->prepare("UPDATE customer_ship_methods SET $set WHERE id = ? AND user_id = ?")
            ->execute(array_merge(array_values($data), [$id, $uid]));
        return [true, $id];
    }
    $cols = array_merge(['user_id'], array_keys($data));
    $ph   = implode(', ', array_fill(0, count($cols), '?'));
    db()->prepare('INSERT INTO customer_ship_methods (' . implode(', ', $cols) . ") VALUES ($ph)")
        ->execute(array_merge([$uid], array_values($data)));
    return [true, (int) db()->lastInsertId()];
}

function delete_ship_method(int $uid, int $id): void
{
    db()->prepare('DELETE FROM customer_ship_methods WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
    db()->prepare('UPDATE customer_profiles SET default_method_id = NULL WHERE user_id = ? AND default_method_id = ?')
        ->execute([$uid, $id]);
}

// ---- Default selectors ------------------------------------------------------
function set_default_ship(int $uid, int $id): void
{
    db()->prepare('UPDATE customer_profiles SET default_ship_id = ? WHERE user_id = ?')->execute([$id ?: null, $uid]);
}
function set_default_bill(int $uid, int $id): void
{
    db()->prepare('UPDATE customer_profiles SET default_bill_id = ? WHERE user_id = ?')->execute([$id ?: null, $uid]);
}
function set_default_method(int $uid, int $id): void
{
    db()->prepare('UPDATE customer_profiles SET default_method_id = ? WHERE user_id = ?')->execute([$id ?: null, $uid]);
}

// Resolve the ship-to to use: an explicit id (if it belongs to the user), else the profile
// default, else the first saved address. Same idea for ship method.
function resolve_ship_address(int $uid, ?int $id): ?array
{
    if ($id) { $a = get_ship_address($id); if ($a && (int) $a['user_id'] === $uid) return $a; }
    $p = get_profile($uid);
    if ($p && !empty($p['default_ship_id'])) { $a = get_ship_address((int) $p['default_ship_id']); if ($a) return $a; }
    return list_ship_addresses($uid)[0] ?? null;
}
function resolve_ship_method(int $uid, ?int $id): ?array
{
    if ($id) { $m = get_ship_method($id); if ($m && (int) $m['user_id'] === $uid) return $m; }
    $p = get_profile($uid);
    if ($p && !empty($p['default_method_id'])) { $m = get_ship_method((int) $p['default_method_id']); if ($m) return $m; }
    return list_ship_methods($uid)[0] ?? null;
}
function resolve_bill_address(int $uid, ?int $id): ?array
{
    if ($id) { $a = get_bill_address($id); if ($a && (int) $a['user_id'] === $uid) return $a; }
    $p = get_profile($uid);
    if ($p && !empty($p['default_bill_id'])) { $a = get_bill_address((int) $p['default_bill_id']); if ($a) return $a; }
    return list_bill_addresses($uid)[0] ?? null;
}

// ---- Formatting (dropdown labels + order snapshots) -------------------------
function ship_address_label(array $a): string
{
    $l = trim((string) ($a['label'] ?? ''));
    $loc = trim(trim(($a['city'] ?? '') . ', ' . ($a['state'] ?? '')), ', ');
    return ($l !== '' ? $l . ' — ' : '') . ($a['addr1'] ?? '') . ($loc !== '' ? ' (' . $loc . ')' : '');
}
function ship_method_label(array $m): string
{
    $l = trim((string) ($m['label'] ?? ''));
    return ($l !== '' ? $l . ' — ' : '') . ($m['method'] ?? '') . (!empty($m['terms']) ? ' / ' . $m['terms'] : '');
}
function format_ship_address(?array $a): string
{
    if (!$a) return '';
    $lines = array_filter([
        $a['attn'] ?? '', $a['addr1'] ?? '', $a['addr2'] ?? '',
        trim(trim(($a['city'] ?? '') . ', ' . ($a['state'] ?? '') . ' ' . ($a['zip'] ?? '')), ', '),
        $a['country'] ?? '',
    ], fn($l) => trim((string) $l) !== '');
    return implode("\n", $lines);
}
function format_ship_method(?array $m): string
{
    if (!$m) return '';
    return implode(' · ', array_filter([
        $m['method'] ?? '',
        !empty($m['terms']) ? 'Terms: ' . $m['terms'] : '',
        !empty($m['carrier_acct']) ? 'Acct: ' . $m['carrier_acct'] : '',
    ]));
}
function format_bill_address(?array $b): string
{
    if (!$b) return '';
    $lines = array_filter([
        $b['company'] ?? '', $b['addr1'] ?? '', $b['addr2'] ?? '',
        trim(trim(($b['city'] ?? '') . ', ' . ($b['state'] ?? '') . ' ' . ($b['zip'] ?? '')), ', '),
        $b['country'] ?? '',
    ], fn($l) => trim((string) $l) !== '');
    return implode("\n", $lines);
}
function bill_address_label(array $b): string
{
    $l = trim((string) ($b['label'] ?? ''));
    $loc = trim(trim(($b['city'] ?? '') . ', ' . ($b['state'] ?? '')), ', ');
    return ($l !== '' ? $l . ' — ' : '') . ($b['company'] ?: ($b['addr1'] ?? '')) . ($loc !== '' ? ' (' . $loc . ')' : '');
}
