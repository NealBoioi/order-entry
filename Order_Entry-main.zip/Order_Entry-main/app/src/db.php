<?php
// Returns a shared PDO connection to the order_entry database.
function db(): PDO
{
    static $pdo = null;
    if ($pdo !== null) return $pdo;
    $cfg = (require __DIR__ . '/../config/config.php')['db'];
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        $cfg['host'], $cfg['port'], $cfg['name']
    );
    $pdo = new PDO($dsn, $cfg['user'], $cfg['pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    return $pdo;
}

// Executes a multi-statement SQL script one statement at a time (PDO::exec runs a single
// statement). Strips /* */ and -- comments FIRST so a semicolon inside a comment can't be
// mistaken for a statement terminator. Safe for our schema files, which never contain
// -- or /* inside string literals.
function run_sql_script(PDO $pdo, string $sql): void
{
    $sql = preg_replace('!/\*.*?\*/!s', '', $sql);   // block comments
    $sql = preg_replace('/--[^\r\n]*/', '', $sql);   // line comments (to end of line)
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '') $pdo->exec($stmt);
    }
}
