<?php
// Shared import logic — used by BOTH the admin Import page (admin-import.php) and the CLI
// importer (bin/import.php), so the daily job and the button run identical code.
//
// SECURITY: this only READS whatever files sit in the server's configured folders; the item
// data never leaves the box. Pricing/cost columns stay admin-gated downstream per §8.2.
//
// SAFETY: each import is an ATOMIC REPLACE — the delete + reload run in one transaction, so if the
// load fails partway the old data is rolled back (you never end up with an empty table on error).
//
// SOURCES: each feed comes from its OWN folder via config 'import_sources' (the item warehouse
// export and the RG report live in different server shares). A feed not set falls back to 'import_dir'.
//
// DATE-PINNED: the importer pulls the file for a specific date (default TODAY) — e.g. on 2026-07-19 it
// looks for `lr_item_warehouse_all_2026-07-19.xlsx` and `A10_daily_rg_2026-07-19.csv`. This means it
// never silently re-imports a previous day's leftover file.
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/xlsx.php';

/** The single fallback folder Oracle drops exports into (config 'import_dir'). */
function import_dir(): string
{
    $cfg = require __DIR__ . '/../config/config.php';
    return (string) ($cfg['import_dir'] ?? '');
}

/**
 * Folder for a specific feed ($key = 'items' | 'orders'). Resolution order:
 *   1. config.php 'import_sources'[$key]  — optional per-machine override
 *   2. config/sources.php[$key]           — the committed default (real work-network UNC shares)
 *   3. 'import_dir'                        — single shared fallback
 * This is what lets each feed be pulled from a different server location with NO per-machine setup.
 */
function import_source(string $key): string
{
    $cfg = require __DIR__ . '/../config/config.php';
    $override = $cfg['import_sources'][$key] ?? '';
    if (is_string($override) && trim($override) !== '') return trim($override);

    $defaults = @require __DIR__ . '/../config/sources.php';
    $def = is_array($defaults) ? ($defaults[$key] ?? '') : '';
    if (is_string($def) && trim($def) !== '') return trim($def);

    return import_dir();
}

/** Today's date (server local) in the YYYY-MM-DD form the export filenames use. */
function import_today(): string { return date('Y-m-d'); }

/** Exact/patterned filename for a feed on a given date (default today). */
function import_item_pattern(?string $date = null): string  { return 'lr_item_warehouse_all_' . ($date ?? import_today()) . '.xlsx'; }
function import_order_pattern(?string $date = null): string { return '*_daily_rg_' . ($date ?? import_today()) . '.csv'; }
function import_stats_pattern(?string $date = null): string { return 'all_orgs_material_stats_' . ($date ?? import_today()) . '.xlsx'; }

/**
 * Files in $dir whose BASENAME matches $pattern, skipping Excel ~$ lock files. Uses scandir + fnmatch
 * (not glob) so it's safe on UNC network paths and folders whose names contain glob metacharacters
 * (e.g. "#Oracle", brackets, spaces). Case-insensitive.
 */
function import_matching_files(string $dir, string $pattern): array
{
    if ($dir === '' || !is_dir($dir)) return [];
    $entries = @scandir($dir);
    if ($entries === false) return [];
    $out = [];
    foreach ($entries as $name) {
        if ($name === '.' || $name === '..') continue;
        if (str_starts_with($name, '~$')) continue;                 // Excel lock files
        if (!fnmatch($pattern, $name, FNM_CASEFOLD)) continue;
        $full = $dir . DIRECTORY_SEPARATOR . $name;
        if (is_file($full)) $out[] = $full;
    }
    return $out;
}

/** Newest file matching $pattern in $dir (by mtime). Null if none / no dir. */
function import_newest_file(string $dir, string $pattern): ?string
{
    $files = import_matching_files($dir, $pattern);
    if (!$files) return null;
    usort($files, fn($a, $b) => filemtime($b) <=> filemtime($a));
    return $files[0];
}

function import_num($v) { $v = trim((string) $v); return $v === '' ? null : $v; }

function count_items(): int { return (int) db()->query('SELECT COUNT(*) FROM items')->fetchColumn(); }
function count_material_stats(): int { return (int) db()->query('SELECT COUNT(*) FROM material_stats')->fetchColumn(); }

/** Today's (or $date's) item / order file in its source folder, or null if it isn't there yet. */
function import_items_source(?string $dir = null, ?string $date = null): ?string
{
    return import_newest_file($dir ?? import_source('items'), import_item_pattern($date));
}
function import_orders_source(?string $dir = null, ?string $date = null): ?string
{
    return import_newest_file($dir ?? import_source('orders'), import_order_pattern($date));
}
function import_stats_source(?string $dir = null, ?string $date = null): ?string
{
    return import_newest_file($dir ?? import_source('material_stats'), import_stats_pattern($date));
}

/** Erase ALL imported item rows (local DB only — never touches the source server files). Returns count removed. */
function erase_items(): int
{
    $pdo = db();
    $n = count_items();
    $pdo->exec('TRUNCATE TABLE items');
    return $n;
}

/**
 * Import the item warehouse xlsx for $date (default today) from the items source folder into `items`
 * (atomic replace). Returns ['ok'=>bool, 'file'=>?string, 'count'=>int, 'error'=>?string]. Never throws.
 */
function import_items(?string $dir = null, ?string $date = null): array
{
    $dir  = $dir ?? import_source('items');
    $date = $date ?? import_today();
    $file = null;
    try {
        if ($dir === '' || !is_dir($dir)) {
            return ['ok' => false, 'file' => null, 'count' => 0, 'error' => 'Item folder not reachable: ' . ($dir ?: '(not configured)')];
        }
        $file = import_newest_file($dir, import_item_pattern($date));
        if (!$file) {
            return ['ok' => false, 'file' => null, 'count' => 0, 'error' => "No item file for $date (" . import_item_pattern($date) . ') in the folder.'];
        }
        $rows = xlsx_read($file);

        $pdo = db();
        $pdo->beginTransaction();
        $pdo->exec('DELETE FROM items');   // transactional (unlike TRUNCATE) so a failed load rolls back
        // UPSERT + MERGE: the real Oracle export contains duplicate (organization, item_number) rows,
        // and different rows carry different populated fields (e.g. the sourcing columns live on one
        // row, planning on another). Last-row-wins would wipe populated values with blanks, so the
        // duplicate handler keeps each column's existing value unless the new row actually has one.
        $ins = $pdo->prepare(
            'INSERT INTO items
               (organization, item_number, description, primary_uom, item_status, item_type,
                list_price, frozen_cost, min_order_qty, flm, supplier, sim_number, supplier_item,
                fixed_lead_time, cumulative_lead_time)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
             ON DUPLICATE KEY UPDATE
               description = COALESCE(NULLIF(VALUES(description), \'\'), description),
               primary_uom = COALESCE(NULLIF(VALUES(primary_uom), \'\'), primary_uom),
               item_status = COALESCE(NULLIF(VALUES(item_status), \'\'), item_status),
               item_type   = COALESCE(NULLIF(VALUES(item_type), \'\'), item_type),
               list_price  = COALESCE(VALUES(list_price), list_price),
               frozen_cost = COALESCE(VALUES(frozen_cost), frozen_cost),
               min_order_qty = COALESCE(VALUES(min_order_qty), min_order_qty),
               flm         = COALESCE(VALUES(flm), flm),
               supplier    = COALESCE(VALUES(supplier), supplier),
               sim_number  = COALESCE(VALUES(sim_number), sim_number),
               supplier_item = COALESCE(VALUES(supplier_item), supplier_item),
               fixed_lead_time = COALESCE(VALUES(fixed_lead_time), fixed_lead_time),
               cumulative_lead_time = COALESCE(VALUES(cumulative_lead_time), cumulative_lead_time)'
        );
        foreach ($rows as $r) {
            if (import_num($r['item_number'] ?? '') === null) continue;   // skip blank rows
            $ins->execute([
                $r['organization'] ?? null,
                $r['item_number'] ?? null,
                $r['description'] ?? null,
                $r['primary_uom'] ?? null,
                $r['item_status'] ?? null,
                $r['item_type'] ?? null,
                import_num($r['list_price'] ?? ''),
                import_num($r['frozen_cost'] ?? ''),
                // Primary column first, then the report's alternate column when it's blank.
                import_num($r['min_order_qty'] ?? '') ?? import_num($r['approved_min_order_qty'] ?? ''),
                import_num($r['flm'] ?? '')           ?? import_num($r['approved_flm'] ?? ''),
                import_num($r['source_rule_name'] ?? '') ?? import_num($r['vendor_name'] ?? ''),   // Supplier
                import_num($r['sim_number'] ?? ''),
                import_num($r['line_supplier_item'] ?? ''),
                import_num($r['fixed_lead_time'] ?? ''),
                import_num($r['cummulative_lead_time'] ?? ''), // note: source header is misspelled
            ]);
        }
        $count = count_items();   // actual unique items loaded (duplicates collapsed by the upsert)
        $pdo->commit();
        return ['ok' => true, 'file' => basename($file), 'count' => $count, 'error' => null];
    } catch (\Throwable $e) {
        try { if (db()->inTransaction()) db()->rollBack(); } catch (\Throwable $e2) {}
        return ['ok' => false, 'file' => $file ? basename($file) : null, 'count' => 0, 'error' => $e->getMessage()];
    }
}

/**
 * Import the RG csv for $date (default today) from the orders source folder into `order_lines` (atomic
 * replace) — the status/shipping/tracking feed. Returns ['ok'=>bool,'file'=>?string,'count'=>int,'error'=>?string].
 */
function import_order_lines(?string $dir = null, ?string $date = null): array
{
    $dir  = $dir ?? import_source('orders');
    $date = $date ?? import_today();
    $file = null;
    try {
        if ($dir === '' || !is_dir($dir)) {
            return ['ok' => false, 'file' => null, 'count' => 0, 'error' => 'Order folder not reachable: ' . ($dir ?: '(not configured)')];
        }
        $file = import_newest_file($dir, import_order_pattern($date));
        if (!$file) {
            return ['ok' => false, 'file' => null, 'count' => 0, 'error' => "No order file for $date (" . import_order_pattern($date) . ') in the folder.'];
        }
        $fh = fopen($file, 'r');
        if (!$fh) return ['ok' => false, 'file' => basename($file), 'count' => 0, 'error' => 'Could not open the order file.'];
        $header = fgetcsv($fh);
        if ($header && isset($header[0])) $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', $header[0]);
        // Normalise headers (lowercase, single-spaced) so lookups tolerate casing/spacing
        // differences between exports. $get matches a column by its normalised name; $getAny
        // returns the first of several candidate names that's present and non-empty.
        $norm = fn(string $s) => preg_replace('/\s+/', ' ', strtolower(trim($s)));
        $idx = [];
        foreach (($header ?: []) as $i => $name) { $idx[$norm((string) $name)] = $i; }
        $get = function (array $row, string $col) use ($idx, $norm) {
            $k = $norm($col);
            return isset($idx[$k], $row[$idx[$k]]) ? trim($row[$idx[$k]]) : null;
        };
        $getAny = function (array $row, array $cols) use ($get) {
            foreach ($cols as $c) { $v = $get($row, $c); if ($v !== null && $v !== '') return $v; }
            return null;
        };

        $pdo = db();
        $pdo->beginTransaction();
        $pdo->exec('DELETE FROM order_lines');
        $ins = $pdo->prepare(
            'INSERT INTO order_lines
               (order_number, customer_po_number, branch, line_number, order_date, order_status,
                line_status, ship_line_status, ordered_item, item_description, ordered_qty,
                shipped_qty, on_hand_qty, unit_price, extended_price, unit_cost, tracking_number,
                actual_ship_date, scheduled_ship_date, promise_date, request_date,
                invoice_number, invoice_date, inventory_org)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        );
        $count = 0;
        while (($row = fgetcsv($fh)) !== false) {
            if (count(array_filter($row, fn($v) => trim((string) $v) !== '')) === 0) continue;
            $po = $get($row, 'Customer Po Number');
            $branch = ($po && preg_match('/^(\d{4})/', $po, $m)) ? $m[1] : null;
            $ins->execute([
                $get($row, 'Order Number'), $po, $branch,
                $get($row, 'Order Extended Line Number'), $get($row, 'Order Date'),
                $get($row, 'Order Status'), $get($row, 'Line Status'), $get($row, 'Ship Line Status'),
                $get($row, 'Ordered Item'), $get($row, 'Item Description'),
                import_num($get($row, 'Ordered Qty')), import_num($get($row, 'Shipped Qty')),
                // On Hand Qty: named column first; else the RG report keeps it in column AC
                // (0-based index 28), per Matt — robust even if that header's text differs.
                import_num($getAny($row, ['On Hand Qty', 'Onhand Qty', 'On-Hand Qty', 'On Hand Quantity', 'Qty On Hand'])
                           ?? (isset($row[28]) ? trim((string) $row[28]) : null)),
                import_num($get($row, 'Unit Price')), import_num($get($row, 'Extended Price')),
                import_num($get($row, 'Unit Cost')), $get($row, 'Tracking Number'),
                $get($row, 'Actual Ship Date'), $get($row, 'Scheduled Ship Date'),
                $get($row, 'Promise Date'), $get($row, 'Request Date'),
                $get($row, 'Invoice Number'), $get($row, 'Invoice Date'), $get($row, 'Inventory Org'),
            ]);
            $count++;
        }
        fclose($fh);
        $pdo->commit();
        return ['ok' => true, 'file' => basename($file), 'count' => $count, 'error' => null];
    } catch (\Throwable $e) {
        try { if (db()->inTransaction()) db()->rollBack(); } catch (\Throwable $e2) {}
        return ['ok' => false, 'file' => $file ? basename($file) : null, 'count' => 0, 'error' => $e->getMessage()];
    }
}

/**
 * Import the "Material Stats" xlsx for $date (default today) from the material_stats source
 * folder into `material_stats` (atomic replace) — per-plant component qty/value/availability,
 * ALL orgs in one file, sheet "df_oh" (one row per item per org). Same shared code path pattern
 * as import_items()/import_order_lines(): date-pinned, scandir+fnmatch matching, one transaction.
 * Returns ['ok'=>bool,'file'=>?string,'count'=>int,'error'=>?string]. Never throws.
 */
function import_material_stats(?string $dir = null, ?string $date = null): array
{
    $dir  = $dir ?? import_source('material_stats');
    $date = $date ?? import_today();
    $file = null;
    try {
        if ($dir === '' || !is_dir($dir)) {
            return ['ok' => false, 'file' => null, 'count' => 0, 'error' => 'Material Stats folder not reachable: ' . ($dir ?: '(not configured)')];
        }
        $file = import_newest_file($dir, import_stats_pattern($date));
        if (!$file) {
            return ['ok' => false, 'file' => null, 'count' => 0, 'error' => "No material stats file for $date (" . import_stats_pattern($date) . ') in the folder.'];
        }
        $rows = xlsx_read($file);   // sheet "df_oh" is the workbook's only worksheet

        $pdo = db();
        $pdo->beginTransaction();
        $pdo->exec('DELETE FROM material_stats');   // transactional (unlike TRUNCATE) so a failed load rolls back
        $ins = $pdo->prepare(
            'INSERT INTO material_stats
               (item_number, description, qty, value, uom, org, months_inactive, aged, demand,
                excess, excess_value, allocated_value, toxic_value, address_value)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        );
        $count = 0;
        foreach ($rows as $r) {
            $item = trim((string) ($r['Item'] ?? ''));
            $org  = trim((string) ($r['ORG'] ?? ''));
            if ($item === '' || $org === '') continue;   // skip blank rows
            $ins->execute([
                $item,
                $r['Description'] ?? null,
                import_num($r['qty'] ?? ''),
                import_num($r['value'] ?? ''),
                $r['uom'] ?? null,
                $org,
                import_num($r['months_inactive'] ?? ''),
                import_num($r['aged'] ?? ''),
                import_num($r['demand'] ?? ''),
                import_num($r['excess'] ?? ''),
                import_num($r['excess value'] ?? ''),      // source header has a space, not underscore
                import_num($r['allocated_value'] ?? ''),
                import_num($r['toxic_value'] ?? ''),
                import_num($r['address_value'] ?? ''),
            ]);
            $count++;
        }
        $pdo->commit();
        return ['ok' => true, 'file' => basename($file), 'count' => $count, 'error' => null];
    } catch (\Throwable $e) {
        try { if (db()->inTransaction()) db()->rollBack(); } catch (\Throwable $e2) {}
        return ['ok' => false, 'file' => $file ? basename($file) : null, 'count' => 0, 'error' => $e->getMessage()];
    }
}
