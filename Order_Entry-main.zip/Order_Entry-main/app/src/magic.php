<?php
// Magic-link (passwordless) sign-in — the mail/orchestration layer.
//   auth.php owns the TOKEN lifecycle (issue/find/consume + session); this file owns
//   turning a request into an emailed link, and the mail-disabled fallback. Kept out of
//   auth.php so PHPMailer isn't pulled into every page load (mirrors notify.php).
// Security posture:
//   - Uniform, silent response: we never reveal whether an email maps to an account.
//   - The raw token is NEVER shown to the requester; it only goes out by email, or (when
//     SMTP is off) is written to a SERVER-SIDE log for the admin/dev to relay — the same
//     honest stand-in the onboarding flow uses (§14).
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/email_theme.php';

// Build [subject, htmlBody, textBody] for the sign-in email (branded shell — email_theme.php).
function magic_build_message(string $link, int $ttlMinutes = 20): array
{
    $subject = 'Your Order Entry sign-in link';
    $esc = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
    $inner = '<p style="margin:0 0 16px;font-size:15px;line-height:1.55;color:#46586a;">'
           . 'Click the button below to sign in to <strong>Order Entry</strong>. '
           . 'This link works once and expires in ' . (int) $ttlMinutes . ' minutes.</p>'
           . email_button('Sign in', $link)
           . '<p style="margin:14px 0 0;font-size:13px;line-height:1.5;color:#8494a4;">'
           . 'Or paste this link into your browser:<br>'
           . '<a href="' . $esc($link) . '" style="color:#1e6fd0;word-break:break-all;">' . $esc($link) . '</a></p>'
           . '<p style="margin:18px 0 0;font-size:13px;color:#8494a4;">'
           . 'If you didn\'t request this, you can safely ignore this email — nothing will happen.</p>';
    $html = email_wrap('Sign in to Order Entry', $inner,
        'Your one-time sign-in link (expires in ' . (int) $ttlMinutes . ' minutes)');
    $text = "Sign in to Order Entry\n\n"
          . "Open this link to sign in (works once, expires in $ttlMinutes minutes):\n$link\n\n"
          . "If you didn't request this, ignore this email.\n";
    return [$subject, $html, $text];
}

// Audit line to app/storage/notifications.log. When mail is disabled the full link is
// recorded (server-side only) so it can be relayed; when mail is sent, the link is not
// logged (it went by email). Mirrors notify_log().
function magic_log(string $email, string $status, string $link = ''): void
{
    $dir = __DIR__ . '/../storage';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $line = sprintf("[%s] MAGIC-LINK  email=%s  %s%s\n",
        date('c'), $email, $status, $link !== '' ? '  link=' . $link : '');
    @file_put_contents($dir . '/notifications.log', $line, FILE_APPEND | LOCK_EX);
}

// Handle a sign-in-link request for $email. Best-effort and ALWAYS silent to the caller
// (no return value the page can use to infer account existence). $baseUrl is the absolute
// site root (e.g. https://host) used to build the link. Never throws.
function request_and_send_magic_link(string $email, string $baseUrl): void
{
    try {
        $email = trim(strtolower($email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return;      // silent: bad address

        $st = db()->prepare('SELECT id, status FROM users WHERE email = ?');
        $st->execute([$email]);
        $u = $st->fetch();
        if (!$u || $u['status'] !== 'active') {                       // silent: no enumeration
            magic_log($email, 'NO ACTIVE ACCOUNT (no link issued)');
            return;
        }

        $raw  = issue_login_token((int) $u['id']);
        $link = rtrim($baseUrl, '/') . '/magic-login.php?token=' . urlencode($raw);
        [$subject, $html, $text] = magic_build_message($link);

        if (mail_enabled()) {
            [$ok, $err] = send_email($email, $subject, $html, $text);
            magic_log($email, $ok ? 'SENT' : ('SEND FAILED: ' . $err), $ok ? '' : $link);
        } else {
            magic_log($email, 'LOGGED ONLY: mail disabled (would email)', $link);
        }
    } catch (\Throwable $e) {
        magic_log($email ?? '(unknown)', 'ERROR: ' . $e->getMessage());
    }
}
// app_base_url() now lives in email_theme.php (required above) — shared by all email links.
