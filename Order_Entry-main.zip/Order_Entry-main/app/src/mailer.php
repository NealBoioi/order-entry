<?php
// SMTP transport for outbound mail, wrapping the vendored PHPMailer (app/lib/PHPMailer).
// Config lives under the 'mail' key in config/config.php. Kept isolated so the rest of
// the app doesn't touch PHPMailer directly and swapping providers is a config change.
require_once __DIR__ . '/../lib/PHPMailer/src/Exception.php';
require_once __DIR__ . '/../lib/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../lib/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;

function mail_config(): array
{
    static $cfg = null;
    if ($cfg === null) {
        $c   = require __DIR__ . '/../config/config.php';
        $cfg = $c['mail'] ?? [];
    }
    return $cfg;
}

function mail_enabled(): bool
{
    return !empty(mail_config()['enabled']);
}

// Send one email. Returns [true, null] on success or [false, error] on failure.
// Never throws — callers (e.g. order notifications) must not break on mail errors.
function send_email(string $toEmail, string $subject, string $htmlBody, string $textBody = ''): array
{
    $c = mail_config();
    try {
        $m = new PHPMailer(true);
        $m->isSMTP();
        $m->Host    = $c['host'] ?? '127.0.0.1';
        $m->Port    = (int) ($c['port'] ?? 25);
        $m->Timeout = 10;

        if (!empty($c['username'])) {
            $m->SMTPAuth = true;
            $m->Username = $c['username'];
            $m->Password = $c['password'] ?? '';
        } else {
            $m->SMTPAuth = false;
        }

        switch (strtolower((string) ($c['encryption'] ?? ''))) {
            case 'tls': $m->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; break;
            case 'ssl': $m->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;    break;
            default:    $m->SMTPSecure = false; $m->SMTPAutoTLS = false;  // plain (local catcher)
        }

        $m->setFrom($c['from_email'] ?? 'no-reply@localhost', $c['from_name'] ?? 'Order Entry');
        if (!empty($c['reply_to'])) $m->addReplyTo($c['reply_to']);
        $m->addAddress($toEmail);

        $m->CharSet = 'UTF-8';   // else PHPMailer defaults to ISO-8859-1 and UTF-8 chars (·, —) become mojibake ("Â·")
        $m->isHTML(true);
        $m->Subject = $subject;
        $m->Body    = $htmlBody;
        $m->AltBody = $textBody !== '' ? $textBody : trim(strip_tags($htmlBody));

        $m->send();
        return [true, null];
    } catch (\Throwable $e) {
        return [false, $e->getMessage()];
    }
}
