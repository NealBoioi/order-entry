<?php
// Item / price lookup for new-order entry.
//  - Search on item number + description: EXACT match unless the term contains "%", which the user
//    controls as a wildcard ("3" => exactly 3; "%3" => ends-with; "3%" => starts-with; "%3%" =>
//    contains). Same rule everywhere — Order Search & Price Lookup (search_items) behave identically.
//  - Customers only ever see assemblies (WES-ETO); buy items (WES-PUR-RE) are excluded so
//    branches can't see or derive plant margin.
//  - Assembly price = admin-entered tier (highest min_qty <= qty). Buy items show sourcing
//    info only (MOQ, FLM, Supplier, SIM, Supplier Item), never a price.

// Returns matching item rows (assemblies only for customers).
// Exact match on part # / description, unless the term contains "%" (then it's a LIKE wildcard).
function lookup_items(string $term, string $role): array
{
    $term = trim($term);
    if ($term === '') return [];
    $op = (strpos($term, '%') !== false) ? 'LIKE' : '=';     // % => user-controlled wildcard, else exact
    $sql = "SELECT item_number, description, item_type, list_price, min_order_qty,
                   flm, supplier, sim_number, supplier_item
            FROM items
            WHERE (item_number $op ? OR description $op ?)";
    $params = [$term, $term];
    if ($role !== 'admin') {
        $sql .= " AND item_type = 'WES-ETO'";             // customers: assemblies only
    }
    $sql .= ' ORDER BY item_number LIMIT 100';            // new-order lookup: show up to the top 100
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

// Multi-field item search for Price Lookup: match by part # and/or description. Each field
// is an EXACT match unless it contains a "%", in which case it's used as a LIKE wildcard
// pattern (user-controlled — e.g. "%123%" = contains 123). Customers see assemblies only.
function search_items(string $partNo, string $desc, string $role): array
{
    $conds = []; $params = [];
    $add = function (string $col, string $val) use (&$conds, &$params) {
        $val = trim($val);
        if ($val === '') return;
        $conds[] = (strpos($val, '%') !== false) ? "$col LIKE ?" : "$col = ?";
        $params[] = $val;
    };
    $add('item_number', $partNo);
    $add('description', $desc);
    if (!$conds) return [];

    $sql = 'SELECT item_number, description, item_type, list_price, frozen_cost, primary_uom,
                   item_status, min_order_qty, flm, supplier, sim_number, supplier_item,
                   cumulative_lead_time
            FROM items WHERE ' . implode(' AND ', $conds);
    if ($role !== 'admin') $sql .= " AND item_type = 'WES-ETO'";   // customers: assemblies only
    $sql .= ' ORDER BY item_number LIMIT 50';
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

// --- Admin quote management (backs the Pricing page) -------------------------
// Each tier is a QUOTE: it carries a quote date (defaults to today) and an expire date
// (quotes last 3 months by default). Expired quotes still price orders (§8.2 two-source
// rule unchanged) — the Pricing page just flags them for re-quoting.

// Valid ISO date from a picker ('' allowed) — guards against hand-edited form posts.
function quote_date_ok(string $d): bool
{
    if ($d === '') return true;
    $p = DateTime::createFromFormat('!Y-m-d', $d);
    return $p !== false && $p->format('Y-m-d') === $d;
}

// Saved price quotes for the Pricing page, ordered for a grouped-by-item display, with
// item-master info (description, UOM, Oracle frozen cost) joined on. $partNo filters
// ("Search Quotes"): exact match unless it contains "%" (the app-wide wildcard rule).
// (Named list_price_quotes — list_quotes in src/quotes.php is the quote-WORKBOOK list.)
function list_price_quotes(string $partNo = ''): array
{
    $sql = 'SELECT p.id, p.item_number, p.min_qty, p.unit_price, p.quote_date, p.expire_date,
                   i.description, i.primary_uom, i.frozen_cost
            FROM assembly_pricing p
            LEFT JOIN (SELECT item_number, MIN(description) AS description,
                              MIN(primary_uom) AS primary_uom, MIN(frozen_cost) AS frozen_cost
                       FROM items GROUP BY item_number) i ON i.item_number = p.item_number';
    $params = [];
    $partNo = trim($partNo);
    if ($partNo !== '') {
        $sql .= (strpos($partNo, '%') !== false) ? ' WHERE p.item_number LIKE ?' : ' WHERE p.item_number = ?';
        $params[] = $partNo;
    }
    $sql .= ' ORDER BY p.item_number, p.min_qty';
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

// Item-master info (description, UOM, frozen cost) for one part — shown on the quote form.
function quote_item_info(string $itemNumber): ?array
{
    $st = db()->prepare(
        'SELECT MIN(description) AS description, MIN(primary_uom) AS primary_uom,
                MIN(frozen_cost) AS frozen_cost
         FROM items WHERE item_number = ? GROUP BY item_number'
    );
    $st->execute([trim($itemNumber)]);
    $row = $st->fetch();
    return $row ?: null;
}

// Resolve a posted unit price: blank -> the daily file's frozen cost (the automatic
// one-unit price); typed -> must be a non-negative number (an explicit override wins).
// Returns [price, null] or [null, error].
function resolve_unit_price(string $raw, ?array $itemInfo): array
{
    $raw = trim($raw);
    if ($raw === '') {
        $frozen = $itemInfo['frozen_cost'] ?? null;
        if ($frozen === null) {
            return [null, 'Unit price is blank and the daily file has no frozen cost for this item — type a price or import today\'s file.'];
        }
        return [(float) $frozen, null];
    }
    if (!is_numeric($raw) || (float) $raw < 0) return [null, 'Unit price must be a non-negative number.'];
    return [(float) $raw, null];
}

// Upsert a quote by (item_number, min_qty). Does NOT rely on a unique constraint, so it
// works on both fresh and legacy dev DBs. Returns [true, null] or [false, message].
// Unit price: blank -> grabbed automatically from the daily item file (frozen cost =
// Oracle's per-ONE-unit standard cost) so a re-save refreshes to the current daily file;
// a typed price overrides. Blank quote date -> today; blank expire date -> +3 months.
function save_tier(string $itemNumber, int $minQty, string $unitPrice = '',
                   string $quoteDate = '', string $expireDate = ''): array
{
    $itemNumber = trim($itemNumber);
    if ($itemNumber === '')          return [false, 'Item number is required.'];
    if ($minQty < 1)                 return [false, 'Min qty must be 1 or more.'];
    if (!quote_date_ok($quoteDate))  return [false, 'Quote date must be a valid date (YYYY-MM-DD).'];
    if (!quote_date_ok($expireDate)) return [false, 'Expire date must be a valid date (YYYY-MM-DD).'];

    [$price, $perr] = resolve_unit_price($unitPrice, quote_item_info($itemNumber));
    if ($perr) return [false, $perr];

    if ($quoteDate === '')  $quoteDate = date('Y-m-d');
    if ($expireDate === '') $expireDate = date('Y-m-d', strtotime($quoteDate . ' +3 months'));
    if ($expireDate < $quoteDate) return [false, 'Expire date can\'t be before the quote date.'];

    $st = db()->prepare('SELECT id FROM assembly_pricing WHERE item_number = ? AND min_qty = ?');
    $st->execute([$itemNumber, $minQty]);
    if ($row = $st->fetch()) {
        db()->prepare('UPDATE assembly_pricing SET unit_price = ? WHERE id = ?')
            ->execute([$price, $row['id']]);
    } else {
        db()->prepare('INSERT INTO assembly_pricing (item_number, min_qty, unit_price)
                       VALUES (?, ?, ?)')
            ->execute([$itemNumber, $minQty, $price]);
    }
    // ONE quote/expire date pair covers the item's ENTIRE tier set — quoting (or re-quoting)
    // any tier re-dates the whole quote.
    db()->prepare('UPDATE assembly_pricing SET quote_date = ?, expire_date = ? WHERE item_number = ?')
        ->execute([$quoteDate, $expireDate, $itemNumber]);
    return [true, null];
}

function delete_tier(int $id): void
{
    db()->prepare('DELETE FROM assembly_pricing WHERE id = ?')->execute([$id]);
}

// Save the FULL tier set for one item from the edit popup: per-tier qty + price (blank
// price -> the daily file's frozen cost), rows marked for removal, new tiers — plus ONE
// quote date + expire date pair that covers the item's ENTIRE tier set. All-or-nothing
// (one transaction). Returns [true, null] or [false, message].
function save_item_quotes(string $item, array $post): array
{
    $item = trim($item);
    if ($item === '') return [false, 'Item number is required.'];
    $info = quote_item_info($item);

    // The one quote/expire pair for the whole quote (blank -> today / +3 months).
    $qd = trim((string) ($post['quote_date'] ?? ''));
    $ed = trim((string) ($post['expire_date'] ?? ''));
    if (!quote_date_ok($qd) || !quote_date_ok($ed)) return [false, 'Dates must be valid (YYYY-MM-DD).'];
    if ($qd === '') $qd = date('Y-m-d');
    if ($ed === '') $ed = date('Y-m-d', strtotime($qd . ' +3 months'));
    if ($ed < $qd) return [false, 'Expire date can\'t be before the quote date.'];

    $st = db()->prepare('SELECT id FROM assembly_pricing WHERE item_number = ?');
    $st->execute([$item]);
    $existingIds = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));

    $deleted = array_map('intval', array_keys(array_filter($post['tier_delete'] ?? [])));
    $updates = [];   // id => [min, price]
    $inserts = [];   // [min, price]
    $mins    = [];   // min_qty uniqueness across the final set

    $n = 0;
    foreach (($post['tier'] ?? []) as $tid => $vals) {
        $tid = (int) $tid; $n++;
        if (!in_array($tid, $existingIds, true) || in_array($tid, $deleted, true)) continue;
        if (!is_array($vals)) continue;
        $min = (int) trim((string) ($vals['min_qty'] ?? ''));
        if ($min < 1) return [false, "Tier $n: min qty must be 1 or more."];
        [$price, $perr] = resolve_unit_price((string) ($vals['unit_price'] ?? ''), $info);
        if ($perr) return [false, "Tier $n: $perr"];
        if (in_array($min, $mins, true)) return [false, "Two tiers can't share the same min qty ($min)."];
        $mins[] = $min;
        $updates[$tid] = [$min, $price];
    }
    foreach (($post['new'] ?? []) as $vals) {
        if (!is_array($vals)) continue;
        $minRaw = trim((string) ($vals['min_qty'] ?? ''));
        $prRaw  = trim((string) ($vals['unit_price'] ?? ''));
        if ($minRaw === '' && $prRaw === '') continue;               // untouched blank row
        $min = (int) $minRaw;
        if ($min < 1) return [false, 'New tier: min qty must be 1 or more.'];
        [$price, $perr] = resolve_unit_price($prRaw, $info);
        if ($perr) return [false, "New tier: $perr"];
        if (in_array($min, $mins, true)) return [false, "Two tiers can't share the same min qty ($min)."];
        $mins[] = $min;
        $inserts[] = [$min, $price];
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ($deleted as $tid) {
            $pdo->prepare('DELETE FROM assembly_pricing WHERE id = ? AND item_number = ?')->execute([$tid, $item]);
        }
        $up = $pdo->prepare('UPDATE assembly_pricing SET min_qty = ?, unit_price = ? WHERE id = ? AND item_number = ?');
        foreach ($updates as $tid => [$min, $price]) $up->execute([$min, $price, $tid, $item]);
        $ins = $pdo->prepare('INSERT INTO assembly_pricing (item_number, min_qty, unit_price) VALUES (?, ?, ?)');
        foreach ($inserts as [$min, $price]) $ins->execute([$item, $min, $price]);
        // The single date pair applies to every remaining row of the item.
        $pdo->prepare('UPDATE assembly_pricing SET quote_date = ?, expire_date = ? WHERE item_number = ?')
            ->execute([$qd, $ed, $item]);
        $pdo->commit();
        return [true, null];
    } catch (\Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return [false, 'Save failed: ' . $e->getMessage()];
    }
}

// Assembly (WES-ETO) items in the master that have NO tier yet — a to-do list for the
// admin so orders don't hit "No tier price set".
function assemblies_missing_tiers(): array
{
    return db()->query(
        "SELECT i.item_number, i.description,
                MIN(i.primary_uom) AS primary_uom, MIN(i.frozen_cost) AS frozen_cost
         FROM items i
         LEFT JOIN assembly_pricing p ON p.item_number = i.item_number
         WHERE i.item_type = 'WES-ETO' AND p.id IS NULL
         GROUP BY i.item_number, i.description
         ORDER BY i.item_number"
    )->fetchAll();
}

// Assembly tiered price for a given qty; null if none set / not an assembly.
// LEGACY FALLBACK ONLY as of the Batch 2 pricing switch — see quote_transfer_price() below,
// which now resolves assembly prices from the Quoting module first. This resolver (and the
// assembly_pricing table + admin quote-management helpers above it) stay in place because
// (a) new-order pricing falls back to them for any assembly that has no quote yet, and
// (b) quote.php's BOM autofill (bom_autofill_from_item()) still uses them as one rung of its
// own cost-resolution ladder (frozen cost -> this tier price -> buy list price).
function assembly_price(string $itemNumber, int $qty): ?array
{
    $st = db()->prepare(
        'SELECT unit_price, min_qty FROM assembly_pricing
         WHERE item_number = ? AND min_qty <= ?
         ORDER BY min_qty DESC LIMIT 1'
    );
    $st->execute([$itemNumber, $qty]);
    $row = $st->fetch();
    return $row ?: null;
}

// --- Quoting-module transfer price (Batch 2 pricing switch) ------------------
// Assembly (WES-ETO) new-order pricing now resolves from the QUOTING module first: the most
// recently created quote for the part (highest id — quotes have no separate "quote date"
// header field, so id order is the recency signal) THAT has at least one Quote Summary tier
// (quote_summary_tiers — see src/quotes.php's save_quote_all()/compute_summary_tier()). Among
// that quote's tiers, pick the one with the largest build_qty <= the ordered qty; if the
// ordered qty is below every tier's build_qty, use the SMALLEST tier instead of returning
// nothing (a small order still gets priced off the smallest known build run). Returns
// ['unit_price' => float, 'quote_number' => string, 'build_qty' => int] or null if no quote
// with summary tiers exists for this part — callers should fall back to assembly_price().
function quote_transfer_price(string $itemNumber, int $qty): ?array
{
    $itemNumber = trim($itemNumber);
    if ($itemNumber === '') return null;

    $st = db()->prepare(
        "SELECT q.id, q.quote_number
         FROM quotes q
         WHERE q.part_number = ?
           AND EXISTS (SELECT 1 FROM quote_summary_tiers t WHERE t.quote_id = q.id)
         ORDER BY q.id DESC LIMIT 1"
    );
    $st->execute([$itemNumber]);
    $q = $st->fetch();
    if (!$q) return null;

    $st = db()->prepare('SELECT build_qty, transfer_price FROM quote_summary_tiers WHERE quote_id = ? ORDER BY build_qty');
    $st->execute([$q['id']]);
    $tiers = $st->fetchAll();
    if (!$tiers) return null;   // shouldn't happen given the EXISTS check above, but be defensive

    $best = null;
    foreach ($tiers as $t) {
        if ((int) $t['build_qty'] <= $qty && ($best === null || (int) $t['build_qty'] > (int) $best['build_qty'])) {
            $best = $t;
        }
    }
    if ($best === null) $best = $tiers[0];   // qty below the smallest tier -> use the smallest tier

    return [
        'unit_price'   => (float) $best['transfer_price'],   // DECIMAL(14,4) in quote_summary_tiers
        'quote_number' => (string) ($q['quote_number'] ?? ''),
        'build_qty'    => (int) $best['build_qty'],
    ];
}
