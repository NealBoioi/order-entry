<?php
/**
 * Shared geocoding helpers — no API key.
 *
 *   geocode_suggest($q)                          -> as-you-type suggestions (Photon / OSM)
 *   geocode_verify($addr1,$city,$state,$zip,...) -> is this a REAL address? (Census + Photon)
 *
 * Suggestions & Photon data © OpenStreetMap contributors. Verification also uses the free
 * US Census Bureau geocoder (authoritative for US street addresses). Provider-swappable:
 * replace the bodies below; callers only see the documented return shapes.
 */

/** GET a URL. Returns body string, or null if the service could not be reached. */
function geocode_http_get(string $url, int $timeout): ?string
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_USERAGENT      => 'WescoOrderEntry/1.0 (geocode)',
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $res  = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($res === false || $code >= 400) return null;
        return (string) $res;
    }
    $ctx = stream_context_create([
        'http' => ['timeout' => $timeout, 'user_agent' => 'WescoOrderEntry/1.0 (geocode)'],
        'ssl'  => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $res = @file_get_contents($url, false, $ctx);
    return $res === false ? null : $res;
}

/* ------------------------------------------------------- Suggestions (Photon) */

/**
 * Optional [lat, lon] used only to bias which CANDIDATES Photon returns (its retrieval quality is
 * poor without a hint — e.g. "south main" returns Chicago "State Street" with no bias). It does NOT
 * drive ranking: results are ordered purely by text similarity below. Config-driven; blank = off.
 */
function geocode_bias(): ?array
{
    static $bias = false;
    if ($bias !== false) return $bias;
    $g   = (require __DIR__ . '/../config/config.php')['geocode'] ?? [];
    $lat = $g['bias_lat'] ?? null;
    $lon = $g['bias_lon'] ?? null;
    return $bias = (is_numeric($lat) && is_numeric($lon)) ? [(float) $lat, (float) $lon] : null;
}

/**
 * Only these countries are offered as suggestions — they're the only ones the app's country/state
 * dropdowns support (US / Canada / Mexico). Photon has no country-filter query param, so we drop
 * everything else after fetch. Matches on ISO code first, with a country-name fallback.
 */
function geocode_allowed_country(string $cc, string $country): bool
{
    if (in_array($cc, ['US', 'CA', 'MX'], true)) return true;
    $c = strtolower(trim($country));
    return in_array($c, ['united states', 'united states of america', 'usa',
                         'canada', 'mexico', 'méxico'], true);
}

/**
 * Text-similarity of the typed query to a candidate address. Higher = more similar. This is the
 * ONLY ranking signal — so the address the user is typing surfaces as it becomes recognisable, and
 * (once they type a city) the right city rises. Geography is deliberately NOT a factor.
 *
 *   - big bonus if the address starts with exactly what was typed (the ideal typeahead case)
 *   - smaller bonus if it merely contains the whole typed string
 *   - per query word: exact word > word-prefix > substring, best match per word
 *   - a fine-grained similar_text() % as the last-resort tiebreak
 */
function geocode_match_score(string $q, string $text): float
{
    $q = strtolower(trim($q));
    $a = strtolower(trim($text));
    if ($q === '') return 0.0;

    $score = 0.0;
    if (str_starts_with($a, $q))      $score += 100;
    elseif (str_contains($a, $q))     $score += 60;

    $words = preg_split('/\s+/', $a, -1, PREG_SPLIT_NO_EMPTY);
    foreach (preg_split('/\s+/', $q, -1, PREG_SPLIT_NO_EMPTY) as $tok) {
        $best = 0;
        foreach ($words as $w) {
            if ($w === $tok)                     { $best = 10; break; }
            if (str_starts_with($w, $tok))       { $best = max($best, 8); }
            elseif (str_contains($w, $tok))      { $best = max($best, 3); }
        }
        $score += $best;
    }

    similar_text($q, $a, $pct);
    return $score + $pct / 10.0;
}

/**
 * Up to 6 normalized suggestions: [ { addr1, city, state, zip, country, countrycode, full } ],
 * ordered most-similar-first.
 *
 * Photon (the free, no-key OSM geocoder) is a weak typeahead engine, so we do the work ourselves:
 *  1. HOUSE NUMBER: when the query starts with a house number, Photon returns ONLY features that
 *     have that exact number, so a street whose numbers aren't individually mapped in OSM (common
 *     for warehouse/industrial roads) never appears, and partial typing degrades to odd global
 *     matches. We strip a leading house number before querying (when street text remains) and
 *     re-attach it to street matches.
 *  2. RANKING: Photon's own order favours global prominence, which buries the match the user is
 *     typing. We ignore it and rank purely by text similarity (geocode_match_score) against the
 *     full "street city state" line — so the most similar address wins regardless of geography.
 *     The plant-region bias (geocode_bias) is applied to the QUERY only, to improve which
 *     candidates Photon returns; it never affects the ordering.
 */
function geocode_suggest(string $q): array
{
    // Leading house number the user typed, if any ("657 midland" -> house "657", street "midland").
    $qHouse  = preg_match('/^\s*(\d+)\s+/', $q, $m) ? $m[1] : '';
    $qStreet = $qHouse !== '' ? trim(substr($q, strlen($m[0]))) : $q;

    // Strip the house number for the lookup when there's enough street text (>=3 chars); re-attach
    // it to street-only results afterward. Too short ("3601 W") -> search the query as typed.
    $stripped = ($qHouse !== '' && mb_strlen($qStreet) >= 3);
    $photonQ  = $stripped ? $qStreet : $q;

    $bias = geocode_bias();
    $url  = 'https://photon.komoot.io/api/?limit=25&lang=en&q=' . rawurlencode($photonQ);
    if ($bias) $url .= '&lat=' . $bias[0] . '&lon=' . $bias[1];
    $raw = geocode_http_get($url, 4);
    if ($raw === null) return [];

    $features = (json_decode($raw, true)['features'] ?? []);
    if (!is_array($features)) return [];

    $out = [];
    $seen = [];
    foreach ($features as $f) {
        $p = $f['properties'] ?? [];
        // Address points carry the road in 'street'; a road object itself (type "street") carries it
        // in 'name' with 'street' empty — fall back to that so unmapped-number streets are usable.
        $street = trim((string) ($p['street'] ?? ''));
        if ($street === '' && ($p['type'] ?? '') === 'street') $street = trim((string) ($p['name'] ?? ''));
        if ($street === '') continue;                       // no street name -> not a usable shipping address
        $house  = trim((string) ($p['housenumber'] ?? ''));
        if ($house === '' && $stripped) $house = $qHouse;   // re-attach the typed number to a street match
        $addr1  = trim($house . ' ' . $street);
        $country = trim((string) ($p['country'] ?? ''));
        $cc      = strtoupper(trim((string) ($p['countrycode'] ?? '')));
        if (!geocode_allowed_country($cc, $country)) continue;   // US / CA / MX only
        $city   = trim((string) ($p['city'] ?? $p['town'] ?? $p['village'] ?? $p['county'] ?? ''));
        $state  = trim((string) ($p['state'] ?? ''));
        $zip    = trim((string) ($p['postcode'] ?? ''));

        // Rank against the street+city+state line (no zip — users rarely type it) so that typing a
        // city lifts the right city.
        $rankText = trim($addr1 . ($city ? ' ' . $city : '') . ($state ? ' ' . $state : ''));

        $sug = [
            'addr1'       => $addr1,
            'city'        => $city,
            'state'       => $state,
            'zip'         => $zip,
            'country'     => $country,
            'countrycode' => $cc,
            '_ss'         => geocode_match_score($q, $rankText),
        ];
        $sug['full'] = trim($addr1 . ($city ? ', ' . $city : '')
                     . ($state ? ', ' . $state : '') . ($zip ? ' ' . $zip : ''));
        $key = strtolower($sug['addr1'] . '|' . $city . '|' . $state . '|' . $zip);
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $out[] = $sug;
    }

    // Most similar first. Stable sort (PHP 8) keeps Photon's order among identical-similarity ties.
    usort($out, fn($a, $b) => $b['_ss'] <=> $a['_ss']);
    $out = array_slice($out, 0, 6);
    foreach ($out as &$s) unset($s['_ss']);
    return $out;
}

/* ------------------------------------------------------- Verification */

/**
 * Lightweight address sanity check. Returns [bool $ok, ?string $normalized].
 *
 * DELIBERATELY PERMISSIVE (Matt, 2026-07-09): strict geocoder confirmation kept rejecting real
 * warehouse / industrial addresses whose exact point isn't individually mapped — e.g. a *suggested*
 * "West 69th Street, Little Rock" that Photon returns with no house number. Since the address book
 * and New Order autofill from the Photon suggestions, real addresses (residential AND warehouse)
 * flow through; we only block clearly-incomplete input:
 *   - a street line with no street name (e.g. "35" / "123")
 *   - a missing city / state / ZIP
 * Everything else is accepted. (To re-introduce geocoder-level verification later, restore the
 * Census/Photon confirm from git history — see Bible §33.)
 */
function geocode_verify(string $addr1, string $city, string $state, string $zip, string $country = ''): array
{
    $addr1 = trim($addr1);
    if ($addr1 === '' || trim($city) === '' || trim($state) === '' || trim($zip) === '') return [false, null];
    if (!preg_match('/[A-Za-z]{2,}/', $addr1)) return [false, null];   // no street name (e.g. "35" / "123")
    return [true, null];
}
