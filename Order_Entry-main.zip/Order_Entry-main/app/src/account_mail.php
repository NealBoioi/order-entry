<?php
// Onboarding / account emails (branded via email_theme.php). The set-password link that
// the admin previously had to copy-paste out of the Users page is now emailed to the user
// directly. Mirrors magic.php: pure send + audit log, never throws. The caller falls back
// to showing the link on-screen when mail is disabled or a send fails, so onboarding still
// works on a box without SMTP.
require_once __DIR__ . '/auth.php';          // db(), issue_password_token()
require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/email_theme.php';

// Build [subject, htmlBody, textBody] for the set-password email. $isNew distinguishes a
// freshly-approved account from an admin-issued password reset.
function account_build_password_email(string $link, bool $isNew): array
{
    $esc = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
    $subject = $isNew ? 'Set your Order Entry password' : 'Reset your Order Entry password';
    $heading = $isNew ? 'Welcome — set your password' : 'Set a new password';
    $lead = $isNew
        ? 'An administrator has approved your Order Entry account. Set a password to finish setting it up and sign in.'
        : 'A password link was issued for your Order Entry account. Click below to choose a new password.';
    $inner = '<p style="margin:0 0 16px;font-size:15px;line-height:1.55;color:#46586a;">' . $esc($lead) . '</p>'
           . email_button('Set your password', $link, '#12683a')
           . '<p style="margin:14px 0 0;font-size:13px;line-height:1.5;color:#8494a4;">'
           . 'Or paste this link into your browser:<br>'
           . '<a href="' . $esc($link) . '" style="color:#1e6fd0;word-break:break-all;">' . $esc($link) . '</a></p>'
           . '<p style="margin:18px 0 0;font-size:13px;color:#8494a4;">This link expires in 72 hours and can be used once. '
           . 'If you weren\'t expecting this, you can safely ignore this email.</p>';
    $preheader = $isNew ? 'Your account is approved — set your password' : 'Set a new Order Entry password';
    $html = email_wrap($heading, $inner, $preheader);
    $text = ($isNew ? "Your Order Entry account has been approved.\n\n" : "Set a new Order Entry password.\n\n")
          . "Open this link to set your password (expires in 72 hours, one-time):\n$link\n\n"
          . "If you weren't expecting this, ignore this email.\n";
    return [$subject, $html, $text];
}

// Email the set-password link. Returns [sent(bool), err(?string)]:
//   [true,  null]      → emailed
//   [false, null]      → mail disabled; caller should show the link on-screen instead
//   [false, 'error…']  → mail enabled but the send failed; caller shows link + the error
function email_password_link(string $email, string $link, bool $isNew): array
{
    if (!mail_enabled()) {
        account_mail_log($email, 'LOGGED ONLY: mail disabled (set-password link shown on-screen)');
        return [false, null];
    }
    [$subject, $html, $text] = account_build_password_email($link, $isNew);
    [$ok, $err] = send_email($email, $subject, $html, $text);
    account_mail_log($email, $ok ? 'SENT set-password link' : ('SEND FAILED: ' . $err));
    return [$ok, $ok ? null : $err];
}

// Self-service "forgot password": issue a fresh set-password token for an ACTIVE account
// and email the branded link. ALWAYS silent to the caller (no return the page can use to
// infer account existence) and never throws — mirrors magic-link's request flow. When mail
// is disabled the link is only logged server-side (never shown to the requester, since there
// is no admin in this flow to relay it).
function request_and_send_password_reset(string $email, string $baseUrl): void
{
    try {
        $email = trim(strtolower($email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return;      // silent: bad address

        $st = db()->prepare('SELECT id, status FROM users WHERE email = ?');
        $st->execute([$email]);
        $u = $st->fetch();
        // Only active accounts can reset. Pending (needs admin approval) / disabled get nothing,
        // and we never reveal which case it is.
        if (!$u || $u['status'] !== 'active') {
            account_mail_log($email, 'RESET: no active account (no link issued)');
            return;
        }
        $raw  = issue_password_token((int) $u['id']);                 // invalidates prior unused tokens
        $link = rtrim($baseUrl, '/') . '/set-password.php?token=' . urlencode($raw);
        email_password_link($email, $link, false);                   // false => "Reset your password" wording
    } catch (\Throwable $e) {
        account_mail_log($email ?? '(unknown)', 'RESET ERROR: ' . $e->getMessage());
    }
}

function account_mail_log(string $email, string $status): void
{
    $dir = __DIR__ . '/../storage';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    @file_put_contents($dir . '/notifications.log',
        sprintf("[%s] ACCOUNT-MAIL  email=%s  %s\n", date('c'), $email, $status), FILE_APPEND | LOCK_EX);
}
