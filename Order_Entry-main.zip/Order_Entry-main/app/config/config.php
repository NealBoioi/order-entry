<?php
// Local dev config (gitignored). Portable PHP + MariaDB stack per PROJECT_BIBLE §12.
return [
    'db' => [
        'host'   => '127.0.0.1',
        'port'   => 3306,
        'name'   => 'order_entry',
        'user'   => 'oe_app',
        'pass'   => 'oe_app_dev_pw',     // dev-only credential
    ],
    // Folder where Oracle drops its Excel/CSV exports on THIS machine (used by import.php).
    'import_dir' => 'C:\\Dev\\Exported data examples',

    // Address-suggest retrieval bias (see PROJECT_BIBLE §33) — biases which candidates Photon
    // returns for ambiguous partial queries (e.g. "south main" -> Little Rock, not Chicago).
    // Retrieval only, never ranking. Blank/absent = off. Was missing from this box's config.php
    // (present in config.example.php) — restored 2026-07-14 default (Little Rock, AR plant).
    'geocode' => [
        'bias_lat' => 34.7465,
        'bias_lon' => -92.2896,
    ],

    // Public site root for absolute links in emails (magic-link sign-in). Blank = derive
    // from the request (fine for local dev); set explicitly at go-live.
    'app' => [
        'base_url' => '',
    ],

    // Outbound email (PHPMailer) — sending straight through a personal GMAIL mailbox (no
    // provider). Only the App Password is missing; fill it and flip 'enabled' => true:
    //   password = a 16-char Gmail App Password (myaccount.google.com → Security →
    //              2-Step Verification → App passwords; 2-Step must be ON)
    // Sends AS the Gmail address below (Gmail forces From = the authenticated account).
    // Resting default stays OFF (notifications only log — app/storage/notifications.log).
    'mail' => [
        'enabled'    => false,                  // OFF on this Mac per CLAUDE.md — notifications only log. Set true only on the Windows box.
        'host'       => 'smtp.gmail.com',
        'port'       => 587,                     // STARTTLS
        'username'   => 'mattwesco3908@gmail.com',
        'password'   => 'xhryhxoagxlobnvq',                      // ← Gmail App Password (secret)
        'encryption' => 'tls',
        'from_email' => 'mattwesco3908@gmail.com',
        'from_name'  => 'Order Entry',
        'reply_to'   => '',
    ],
];
