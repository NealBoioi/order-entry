<?php
// Per-feed Oracle export SOURCE FOLDERS. Committed on purpose (like config.php) so every work
// machine gets them on `git pull` with NO local edit — the app reads these by default.
//
// These are the real UNC shares on the work network; they resolve on the Windows work computer
// (not on a Mac dev box). A machine that needs different folders can override any key via
// config.php 'import_sources' (that wins over these defaults).
//
// NOTE: in single-quoted PHP strings each backslash is doubled, and a UNC path starts with TWO
// backslashes — so '\\\\server\\share' produces the real \\server\share.
return [
    // item warehouse export:
    'items'  => '\\\\brwn-1931-fls-01\\B1931\\public01\\#Oracle\\Daily Exports\\A10\\item_warehouse_all',
    // RG (order status / shipping / tracking) report:
    'orders' => '\\\\brwn-1931-fls-01\\B1931\\public01\\#Oracle\\Daily Exports\\all-org RG\\A10',
    // Material Stats (per-plant component qty/value/availability), all orgs in one file:
    'material_stats' => '\\\\brwn-1931-fls-01\\B1931\\public01\\#Oracle\\Daily Exports\\All Orgs\\material_stats',
];
