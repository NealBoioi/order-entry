<?php
// Copy this file to `config.php` and fill in your local values.
// config.php is gitignored so secrets never reach GitHub.
return [
    'db' => [
        'host'   => '127.0.0.1',
        'port'   => 3306,
        'name'   => 'order_entry',
        'user'   => 'oe_app',
        'pass'   => 'CHANGE_ME',        // your local MariaDB/MySQL password
    ],
    // Single fallback folder Oracle drops its Excel/CSV exports into on THIS machine.
    'import_dir' => 'C:\\Dev\\Exported data examples',

    // Per-feed source folders (item warehouse vs RG report) are the COMMITTED defaults in
    // app/config/sources.php — no per-machine setup needed. Uncomment below ONLY to override a
    // feed's folder on this specific machine (doubled backslashes; UNC starts with '\\\\'):
    // 'import_sources' => [
    //     'items'  => '\\\\some-server\\share\\item_warehouse_all',
    //     'orders' => '\\\\some-server\\share\\rg',
    // ],

    // Public site root, used to build absolute links in emails (e.g. magic-link sign-in).
    // Leave blank to derive it from the incoming request (fine for local dev); set it
    // explicitly at go-live, e.g. 'https://orderentry.company.com'.
    'app' => [
        'base_url' => '',
    ],

    // Address autocomplete (Photon / OpenStreetMap, no key). Suggestions are biased toward this
    // point so local addresses (e.g. the primary plant region) outrank identically-named streets
    // elsewhere. Defaults to Little Rock, AR; change per primary plant, or blank to disable.
    'geocode' => [
        'bias_lat' => 34.7465,
        'bias_lon' => -92.2896,
    ],

    // Outbound email for new-order notifications (PHPMailer, vendored in app/lib).
    // When 'enabled' is false, notifications are only logged (app/storage/notifications.log)
    // and nothing is sent — safe default for a machine without SMTP.
    //   POC:  Mailtrap sandbox (host sandbox.smtp.mailtrap.io, port 2525, tls, your creds)
    //   Prod: the company SMTP relay / Brevo.
    'mail' => [
        'enabled'    => false,
        'host'       => 'sandbox.smtp.mailtrap.io',
        'port'       => 2525,
        'username'   => '',              // blank => no SMTP auth
        'password'   => '',
        'encryption' => 'tls',           // '', 'tls' (STARTTLS), or 'ssl'
        'from_email' => 'orders@orderentry.local',
        'from_name'  => 'Order Entry',
        'reply_to'   => '',              // optional
    ],
];
