/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.9-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: order_entry
-- ------------------------------------------------------
-- Server version	11.4.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `assembly_pricing`
--

DROP TABLE IF EXISTS `assembly_pricing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assembly_pricing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_number` varchar(60) NOT NULL,
  `min_qty` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(14,4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_item_qty` (`item_number`,`min_qty`),
  KEY `idx_item` (`item_number`,`min_qty`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assembly_pricing`
--

LOCK TABLES `assembly_pricing` WRITE;
/*!40000 ALTER TABLE `assembly_pricing` DISABLE KEYS */;
INSERT INTO `assembly_pricing` VALUES
(1,'VR-2-ET-G,00',1,80.0000),
(2,'VR-2-ET-G,00',100,75.0000),
(3,'VR-2-ET-G,00',240,70.0000),
(4,'320FP23,00',1,12.0000),
(5,'320FP23,00',50,10.0000);
/*!40000 ALTER TABLE `assembly_pricing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `branch` char(4) NOT NULL,
  `name` varchar(120) DEFAULT NULL,
  `default_org` varchar(10) DEFAULT NULL,
  `contact_name` varchar(120) DEFAULT NULL,
  `contact_email` varchar(160) DEFAULT NULL,
  `contact_phone` varchar(40) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`branch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_defaults`
--

DROP TABLE IF EXISTS `company_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_defaults` (
  `id` tinyint(4) NOT NULL DEFAULT 1,
  `bill_company` varchar(160) DEFAULT NULL,
  `bill_addr1` varchar(160) DEFAULT NULL,
  `bill_addr2` varchar(160) DEFAULT NULL,
  `bill_city` varchar(80) DEFAULT NULL,
  `bill_state` varchar(40) DEFAULT NULL,
  `bill_zip` varchar(20) DEFAULT NULL,
  `bill_country` varchar(60) NOT NULL DEFAULT 'USA',
  `ship_attn` varchar(120) DEFAULT NULL,
  `ship_addr1` varchar(160) DEFAULT NULL,
  `ship_addr2` varchar(160) DEFAULT NULL,
  `ship_city` varchar(80) DEFAULT NULL,
  `ship_state` varchar(40) DEFAULT NULL,
  `ship_zip` varchar(20) DEFAULT NULL,
  `ship_country` varchar(60) NOT NULL DEFAULT 'USA',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_defaults`
--

LOCK TABLES `company_defaults` WRITE;
/*!40000 ALTER TABLE `company_defaults` DISABLE KEYS */;
INSERT INTO `company_defaults` VALUES
(1,'WESCO Corporate AP','225 W Station Sq',NULL,'Pittsburgh','PA','15219','USA',NULL,'500 Plant Rd',NULL,'Little Rock','AR','72201','USA','2026-07-08 16:22:03');
/*!40000 ALTER TABLE `company_defaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_bill_addresses`
--

DROP TABLE IF EXISTS `customer_bill_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_bill_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `label` varchar(80) DEFAULT NULL,
  `company` varchar(160) DEFAULT NULL,
  `addr1` varchar(160) DEFAULT NULL,
  `addr2` varchar(160) DEFAULT NULL,
  `city` varchar(80) DEFAULT NULL,
  `state` varchar(40) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `country` varchar(60) NOT NULL DEFAULT 'USA',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cba_user` (`user_id`),
  CONSTRAINT `fk_cba_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_bill_addresses`
--

LOCK TABLES `customer_bill_addresses` WRITE;
/*!40000 ALTER TABLE `customer_bill_addresses` DISABLE KEYS */;
INSERT INTO `customer_bill_addresses` VALUES
(1,3,'Default','WESCO Corporate AP','225 W Station Sq',NULL,'Pittsburgh','PA','15219','USA','2026-07-08 18:07:40'),
(2,3,'Regional AP','WESCO West','10 West Blvd',NULL,'Reno','NV','89501','USA','2026-07-08 18:07:41'),
(3,7,'Default','WESCO Corporate AP','225 W Station Sq',NULL,'Pittsburgh','PA','15219','USA','2026-07-08 18:14:29');
/*!40000 ALTER TABLE `customer_bill_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_profiles`
--

DROP TABLE IF EXISTS `customer_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_profiles` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(120) DEFAULT NULL,
  `title` varchar(80) DEFAULT NULL,
  `default_ship_id` int(11) DEFAULT NULL,
  `default_bill_id` int(11) DEFAULT NULL,
  `default_method_id` int(11) DEFAULT NULL,
  `setup_complete` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_cp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_profiles`
--

LOCK TABLES `customer_profiles` WRITE;
/*!40000 ALTER TABLE `customer_profiles` DISABLE KEYS */;
INSERT INTO `customer_profiles` VALUES
(1,NULL,NULL,NULL,NULL,NULL,0,'2026-07-08 18:08:47','2026-07-08 18:08:47'),
(3,'Edited By Admin','Lead Buyer',4,2,3,1,'2026-07-08 18:07:40','2026-07-08 19:20:33'),
(7,'Matt Harvey','Program Manager',5,3,4,1,'2026-07-08 18:14:29','2026-07-08 18:26:32');
/*!40000 ALTER TABLE `customer_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_ship_addresses`
--

DROP TABLE IF EXISTS `customer_ship_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_ship_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `label` varchar(80) DEFAULT NULL,
  `attn` varchar(120) DEFAULT NULL,
  `addr1` varchar(160) DEFAULT NULL,
  `addr2` varchar(160) DEFAULT NULL,
  `city` varchar(80) DEFAULT NULL,
  `state` varchar(40) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `country` varchar(60) NOT NULL DEFAULT 'USA',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_csa_user` (`user_id`),
  CONSTRAINT `fk_csa_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_ship_addresses`
--

LOCK TABLES `customer_ship_addresses` WRITE;
/*!40000 ALTER TABLE `customer_ship_addresses` DISABLE KEYS */;
INSERT INTO `customer_ship_addresses` VALUES
(4,3,'Default',NULL,'500 Plant Rd',NULL,'Little Rock','AR','72201','USA','2026-07-08 18:07:40'),
(5,7,'Default',NULL,'500 Plant Rd',NULL,'Little Rock','AR','72201','USA','2026-07-08 18:14:29'),
(8,3,'Admin Added',NULL,'42 Admin Way',NULL,'Austin','TX','78701','USA','2026-07-08 19:20:33');
/*!40000 ALTER TABLE `customer_ship_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_ship_methods`
--

DROP TABLE IF EXISTS `customer_ship_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_ship_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `label` varchar(80) DEFAULT NULL,
  `terms` varchar(80) DEFAULT NULL,
  `method` varchar(120) DEFAULT NULL,
  `carrier_acct` varchar(80) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_csm_user` (`user_id`),
  CONSTRAINT `fk_csm_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_ship_methods`
--

LOCK TABLES `customer_ship_methods` WRITE;
/*!40000 ALTER TABLE `customer_ship_methods` DISABLE KEYS */;
INSERT INTO `customer_ship_methods` VALUES
(3,3,'Default','Prepaid & Add','UPS Ground','ABC123','2026-07-08 18:07:40'),
(4,7,'Default','Collect','UPS','1234','2026-07-08 18:14:29');
/*!40000 ALTER TABLE `customer_ship_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organization` varchar(80) DEFAULT NULL,
  `item_number` varchar(60) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `primary_uom` varchar(20) DEFAULT NULL,
  `item_status` varchar(30) DEFAULT NULL,
  `item_type` varchar(30) DEFAULT NULL,
  `list_price` decimal(14,4) DEFAULT NULL,
  `min_order_qty` int(11) DEFAULT NULL,
  `flm` varchar(20) DEFAULT NULL,
  `supplier` varchar(160) DEFAULT NULL,
  `sim_number` varchar(60) DEFAULT NULL,
  `supplier_item` varchar(120) DEFAULT NULL,
  `fixed_lead_time` int(11) DEFAULT NULL,
  `cumulative_lead_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_item` (`organization`,`item_number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES
(1,'A10 - Little Rock Assembly (MFG)','320FP23,00','Face plate assembly 320','EA','Active','WES-ETO',NULL,1,'F12',NULL,NULL,NULL,5,10),
(2,'A10 - Little Rock Assembly (MFG)','VR-2-ET-G,00','Valve regulator VR-2 (green)','EA','Active','WES-ETO',NULL,1,'F08',NULL,NULL,NULL,7,14),
(3,'A10 - Little Rock Assembly (MFG)','PDGXAC','Purchased connector PDGXAC','EA','Active','WES-PUR-RE',10.0000,5,'F03','Acme Supply Co','SIM-771','ACME-PDGXAC',3,6);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_lines`
--

DROP TABLE IF EXISTS `order_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_lines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(30) DEFAULT NULL,
  `customer_po_number` varchar(80) DEFAULT NULL,
  `branch` char(4) DEFAULT NULL,
  `line_number` varchar(20) DEFAULT NULL,
  `order_date` varchar(20) DEFAULT NULL,
  `order_status` varchar(30) DEFAULT NULL,
  `line_status` varchar(40) DEFAULT NULL,
  `ship_line_status` varchar(40) DEFAULT NULL,
  `ordered_item` varchar(60) DEFAULT NULL,
  `item_description` varchar(255) DEFAULT NULL,
  `ordered_qty` decimal(14,2) DEFAULT NULL,
  `shipped_qty` decimal(14,2) DEFAULT NULL,
  `unit_price` decimal(14,4) DEFAULT NULL,
  `extended_price` decimal(14,4) DEFAULT NULL,
  `unit_cost` decimal(14,4) DEFAULT NULL,
  `tracking_number` varchar(60) DEFAULT NULL,
  `actual_ship_date` varchar(20) DEFAULT NULL,
  `scheduled_ship_date` varchar(20) DEFAULT NULL,
  `promise_date` varchar(20) DEFAULT NULL,
  `request_date` varchar(20) DEFAULT NULL,
  `invoice_number` varchar(30) DEFAULT NULL,
  `invoice_date` varchar(20) DEFAULT NULL,
  `inventory_org` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_branch` (`branch`),
  KEY `idx_po` (`customer_po_number`),
  KEY `idx_item` (`ordered_item`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_lines`
--

LOCK TABLES `order_lines` WRITE;
/*!40000 ALTER TABLE `order_lines` DISABLE KEYS */;
INSERT INTO `order_lines` VALUES
(1,'SO50001','1932-100001','1932','1.1','2026-06-10','Booked','Awaiting Shipping','Not Shipped','320FP23,00','Face plate assembly 320',100.00,0.00,12.0000,1200.0000,7.5000,NULL,NULL,'2026-07-15','2026-07-14','2026-07-01',NULL,NULL,'A10'),
(2,'SO50001','1932-100001','1932','2.1','2026-06-10','Booked','Shipped','Shipped','PDGXAC','Purchased connector PDGXAC',40.00,40.00,10.0000,400.0000,6.2000,'1Z9992X0341','2026-06-20','2026-06-18','2026-06-19','2026-06-10','INV88123','2026-06-21','A10'),
(3,'SO50077','1918-200002','1918','1.1','2026-06-22','Booked','Shipped','Shipped','VR-2-ET-G,00','Valve regulator VR-2 (green)',240.00,240.00,70.0000,16800.0000,44.0000,'1Z9992X0999','2026-06-30','2026-06-28','2026-06-29','2026-06-22','INV88170','2026-07-01','A10');
/*!40000 ALTER TABLE `order_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orgs`
--

DROP TABLE IF EXISTS `orgs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orgs` (
  `inventory_org` varchar(10) NOT NULL,
  `plant_code` varchar(10) DEFAULT NULL,
  `name` varchar(80) DEFAULT NULL,
  `contact_email` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`inventory_org`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orgs`
--

LOCK TABLES `orgs` WRITE;
/*!40000 ALTER TABLE `orgs` DISABLE KEYS */;
INSERT INTO `orgs` VALUES
('A10','3908','Little Rock Assembly','littlerock-orders@example.com'),
('AA1','1931','Austin Assembly','austin-orders@example.com');
/*!40000 ALTER TABLE `orgs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plant_contacts`
--

DROP TABLE IF EXISTS `plant_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plant_contacts` (
  `inventory_org` varchar(10) NOT NULL,
  `contact_name` varchar(120) DEFAULT NULL,
  `contact_email` varchar(160) DEFAULT NULL,
  `contact_phone` varchar(40) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`inventory_org`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plant_contacts`
--

LOCK TABLES `plant_contacts` WRITE;
/*!40000 ALTER TABLE `plant_contacts` DISABLE KEYS */;
INSERT INTO `plant_contacts` VALUES
('A10','Little Rock Orders Desk','maharvey@wescodist.com',NULL,'2026-07-07 19:25:12'),
('AA1','Austin Orders Desk','austin-orders@example.com',NULL,'2026-07-06 15:22:34');
/*!40000 ALTER TABLE `plant_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_assignments`
--

DROP TABLE IF EXISTS `program_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `program_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer` varchar(160) NOT NULL,
  `pm` varchar(120) DEFAULT NULL,
  `plant_order_inbox` varchar(160) DEFAULT NULL,
  `plant_site` varchar(120) DEFAULT NULL,
  `sales_contact` varchar(160) DEFAULT NULL,
  `sales_branch` varchar(20) DEFAULT NULL,
  `bdm` varchar(120) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_pa_customer` (`customer`),
  KEY `idx_pa_branch` (`sales_branch`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_assignments`
--

LOCK TABLES `program_assignments` WRITE;
/*!40000 ALTER TABLE `program_assignments` DISABLE KEYS */;
INSERT INTO `program_assignments` VALUES
(1,'ABB Automation','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Frank Buerger','1930','Russell Davis',1),
(2,'ACS','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Joe McDonald','5114','Don Wilson/Pat Ryan',2),
(3,'Advanced Marine','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Matt Braswell and Vicky Walker','1909','Don Wilson/Pat Ryan',3),
(4,'AGCO','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Jeff Nelson','1917','Russell Davis',4),
(5,'Ajax-Tocco','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Kevin Brinn','1913','Don Wilson/Pat Ryan',5),
(6,'ALTEC','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Cathy Myers','1917','Russell Davis',6),
(7,'Amazon','Juanita Gatlin','3908orders@wescodist.com','Little Rock (3908)','Matt Epstein, Kim Moline, Karla Lopez',NULL,'Russell Davis',7),
(8,'American Access','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','AJ Herrera','1917','Russell Davis',8),
(9,'American Gaming','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','BONNIE WHITE','1920','Don Wilson/Pat Ryan',9),
(10,'APSCO','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Vicki Walker','1930','Don Wilson/Pat Ryan',10),
(11,'ATLAS MATERIAL TESTING','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Antionette Hodgson','1905','Don Wilson/Pat Ryan',11),
(12,'Boeing','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Brandon Lozano','1917','Don Wilson/Pat Ryan',12),
(13,'Bomag','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Brenna Hunter','1922','Don Wilson/Pat Ryan',13),
(14,'Bowie-Cass Elect Coop','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bonnie White','1920','Russell Davis',14),
(15,'Braun Corporation','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Drew Davenport','1913','Don Wilson/Pat Ryan',15),
(16,'CamSpray','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','AJ Herrera','1917','Russell Davis',16),
(17,'Caterpillar','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bryan Colwell','1934','Russell Davis',17),
(18,'Charles Machine','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bonnie White','1917','Russell Davis',18),
(19,'Charles Machine(Amer Augers)','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bonnie White','1920','Russell Davis',19),
(20,'Chromalox','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Ryan Leach','1915','Don Wilson/Pat Ryan',20),
(21,'Columbus Mckinnon','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Greg Anderson','1915','Don Wilson/Pat Ryan',21),
(22,'Command Alkon','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Alice Fugate','1913','Don Wilson/Pat Ryan',22),
(23,'De Jong Duke','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Susan Berninger','3915','Don Wilson/Pat Ryan',23),
(24,'Despatch Industries','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Kelli Teale','1924','Don Wilson/Pat Ryan',24),
(25,'Diagraph','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Cathy Myers','1927','Russell Davis',25),
(26,'Diagraph','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Cathy Myers and Mark Herrin','1917','Russell Davis',26),
(27,'Ditch Witch','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bonnie White','1920','Don Wilson/Pat Ryan',27),
(28,'Eaton Cooper','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Terrell Knox','3605','Don Wilson/Pat Ryan',28),
(29,'Elliot Company','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Josh Neal','1913','Don Wilson/Pat Ryan',29),
(30,'EMERSON/PENTAIR','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','SAM SMOTHERS','1921','Don Wilson/Pat Ryan',30),
(31,'Englewood Electric (EESCO) Wynright','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Kaitlyn Fowler/Colin Hickey','7630','Don Wilson/Pat Ryan',31),
(32,'Enovation Controls','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Vicki Walker','1930','Don Wilson/Pat Ryan',32),
(33,'Epiroc','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Chelsea Coutou or Monique Kousoulis','1932','Russell Davis',33),
(34,'EQUIPMENT TECHNOLOGY','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','BONNIE WHITE','1920','Don Wilson/Pat Ryan',34),
(35,'Erhardt and Leimer','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Tim Magowen','1922','Don Wilson/Pat Ryan',35),
(36,'ESAB','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Carmen Sealy','1932','Russell Davis',36),
(37,'ETI','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bonnie White','1920','Don Wilson/Pat Ryan',37),
(38,'Givenhansco','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Alice Fugate','1913','Don Wilson/Pat Ryan',38),
(39,'Halliburton','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Matthew Lackey','1920','Don Wilson/Pat Ryan',39),
(40,'Harsco Rail','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Lisa Morris','1922','Don Wilson/Pat Ryan',40),
(41,'Hog Slat','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Brenna Vargas','1922','Don Wilson/Pat Ryan',41),
(42,'Honeywell','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Drew Davenport','1913','Don Wilson/Pat Ryan',42),
(43,'Husqvarna','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Cathy Myers','1917','Russell Davis',43),
(44,'IC Bus','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Pete Boshears and Paul Garnier','1930','Don Wilson/Pat Ryan',44),
(45,'INGERSOLL','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','ADAM ZANGARIS','6662','Don Wilson/Pat Ryan',45),
(46,'INTRALOT','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Kevin Brinn','1913','Don Wilson/Pat Ryan',46),
(47,'ITW','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','KELLI TEALE','1924','Don Wilson/Pat Ryan',47),
(48,'ITW/Dynatec','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Mike Watson','1915','Don Wilson/Pat Ryan',48),
(49,'J-Kem','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bill Wright','1927','Don Wilson/Pat Ryan',49),
(50,'Kawasaki','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Jody Peterson','1917','Russell Davis',50),
(51,'Komatsu','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Jay Klug & Cherie Gibes','3905','Don Wilson',51),
(52,'Kone','Alice Kauppinen','3908orders@wescodist.com','Little Rock (3908)','Bryan Guitierez & Deborah Taylor','1932','Russell Davis',52),
(53,'Kuhn Krause','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Matthew Marshall','1917','Russell Davis',53),
(54,'Leeboy','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Lane Bumgardner','1922','Don Wilson/Pat Ryan',54),
(55,'Lincoln Industrial Corp','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Dave Clifton','1927','Don Wilson/Pat Ryan',55),
(56,'Lufkin','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bryan Colwell','1934','Russell Davis',56),
(57,'Mark Andy','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bill Wright','1927','Don Wilson/Pat Ryan',57),
(58,'Marlo Coil','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bill Wright','1927','Don Wilson/Pat Ryan',58),
(59,'McElroy','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Pete Boshears and Paul Garnier','1930','Don Wilson/Pat Ryan',59),
(60,'MCFA Inc','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Chelsea Coutou','1934','Russell Davis',60),
(61,'Megatron','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Silvia Ortiz','1929','Don Wilson/Pat Ryan',61),
(62,'MIDMARK','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Kevin Brinn','1913','Don Wilson/Pat Ryan',62),
(63,'Miller Industries','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Greg Anderson','1915','Don Wilson/Pat Ryan',63),
(64,'National Oilwell','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bryan Colwell','1934','Russell Davis',64),
(65,'Navistar(IC CORP)','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Pete Boshears and Paul Garnier','1930','Russell Davis',65),
(66,'NILFISK','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bonnie White','1909','Don Wilson/Pat Ryan',66),
(67,'Nokia','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Vicky Williams','1911','Don Wilson/Pat Ryan',67),
(68,'Rampmaster','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Tracy Czajkowski','1916','Don Wilson/Pat Ryan',68),
(69,'Relay Associates','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Tracy Czajkowski','1916','Don Wilson/Pat Ryan',69),
(70,'Saf T Cab','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Maria Herrin and Adam Noggle','1932','Russell Davis',70),
(71,'Siemens Medical','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Tim Magowan','1922','Don Wilson/Pat Ryan',71),
(72,'Sigmanetics','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Tracy Czajkowski','1916','Don Wilson/Pat Ryan',72),
(73,'Skymark','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Cathy Myers','1917','Russell Davis',73),
(74,'SMP','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Inta Jensen','1917','Russell Davis',74),
(75,'Snorkel','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Inta Jensen','1917','Russell Davis',75),
(76,'Southbend','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Tim Magowen','1922','Don Wilson/Pat Ryan',76),
(77,'Southern States','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Abby Williams','1918','Don Wilson',77),
(78,'Southern States','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Zoya Shorsteyn','1901','Don Wilson/Pat Ryan',78),
(79,'Springfield Sign & Graphics','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Cory Rogers','1924','Russell Davis',79),
(80,'Star Mfg','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Justin Little','1915','Don Wilson/Pat Ryan',80),
(81,'STEWART AND STEVENSON','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bonnie White','1920','Don Wilson/Pat Ryan',81),
(82,'Stuart C Irby','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Silvia Ortiz','1929','Don Wilson/Pat Ryan',82),
(83,'Sunnen','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Dave Clifton','1927','Don Wilson/Pat Ryan',83),
(84,'Teledyne','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Brandon Lozano','1917','Don Wilson/Pat Ryan',84),
(85,'Textron','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Jean Radtke','1901','Don Wilson/Pat Ryan',85),
(86,'TKE','Chase Woodruff','3908orders@wescodist.com','Little Rock (3908)','Lisa Bolden','1918','Don Wilson',86),
(87,'TRANE','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Patricia Williams','6662','Don Wilson/Pat Ryan',87),
(88,'TVH','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Cathy Myers','1917','Russell Davis',88),
(89,'TYMCO International','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Carmen Sealey','1934','Russell Davis',89),
(90,'UE Manufacturing','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bonnie White and Kelly Ryan','1920','Don Wilson/Pat Ryan',90),
(91,'Vanderlande Industries','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Zoya Shorsteyn','1901','Don Wilson/Pat Ryan',91),
(92,'VC999 Packaging Systems','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Shelly Delaney','1917','Russell Davis',92),
(93,'VideoJet','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Jensen and Garvey','1927','Don Wilson/Pat Ryan',93),
(94,'West Bay Fleet Service','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bonnie White','1920','Russell Davis',94),
(95,'Wynright','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Meagan Webb & Colin Hickey','7630','Don Wilson/Pat Ryan',95),
(96,'X1901','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bridget Bartasius','1901','Don Wilson/Pat Ryan',96),
(97,'x1915','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Greg Anderson','1915','Don Wilson/Pat Ryan',97),
(98,'X1917','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bridget Bartasius','1917','Russell Davis',98),
(99,'X1922','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Lisa Morris','1922','Don Wilson/Pat Ryan',99),
(100,'X1924','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Bridget Bartasius','1924','Russell Davis',100),
(101,'X1932','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Carmen Sealy','1932','Russell Davis',101),
(102,'X1938','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)',NULL,'1938',NULL,102),
(103,'X5114','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Michele Newman','5114','Don Wilson/Pat Ryan',103),
(104,'X7635','Yancey Royal','3908orders@wescodist.com','Little Rock (3908)','Allen Pollock','7635','Don Wilson/Pat Ryan',104),
(105,'Rampmaster','Chase Woodruff','3908orders@wescodist.com','Little Rock (3908)','Jim Crognale and Trace Czajkowski','1916','Don Wilson/Pat Ryan',105);
/*!40000 ALTER TABLE `program_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_bom_lines`
--

DROP TABLE IF EXISTS `quote_bom_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quote_bom_lines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `level` tinyint(4) DEFAULT NULL,
  `customer_pn` varchar(60) DEFAULT NULL,
  `mfg_item` varchar(120) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `uom` varchar(10) DEFAULT NULL,
  `qty_per` decimal(14,5) NOT NULL DEFAULT 1.00000,
  `line_type` varchar(30) DEFAULT NULL,
  `moq` int(11) DEFAULT NULL,
  `flm` int(11) DEFAULT NULL,
  `lead_time_weeks` int(11) DEFAULT NULL,
  `manufacturer` varchar(120) DEFAULT NULL,
  `project_supplier` varchar(120) DEFAULT NULL,
  `sim_supplier_item` varchar(120) DEFAULT NULL,
  `quote_number` varchar(60) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `crossed_items` varchar(120) DEFAULT NULL,
  `standard_cost` decimal(14,4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qbl_quote` (`quote_id`),
  CONSTRAINT `fk_qbl_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_bom_lines`
--

LOCK TABLES `quote_bom_lines` WRITE;
/*!40000 ALTER TABLE `quote_bom_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_bom_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_cost_tiers`
--

DROP TABLE IF EXISTS `quote_cost_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quote_cost_tiers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `label` varchar(60) DEFAULT NULL,
  `build_qty` int(11) NOT NULL DEFAULT 1,
  `labor_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `labor_hours` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `burden` decimal(6,4) NOT NULL DEFAULT 0.0000,
  `osp_labor` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `margin` decimal(6,4) NOT NULL DEFAULT 0.0000,
  PRIMARY KEY (`id`),
  KEY `idx_qct_quote` (`quote_id`),
  CONSTRAINT `fk_qct_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_cost_tiers`
--

LOCK TABLES `quote_cost_tiers` WRITE;
/*!40000 ALTER TABLE `quote_cost_tiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_cost_tiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_revisions`
--

DROP TABLE IF EXISTS `quote_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quote_revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `rev_no` varchar(10) DEFAULT NULL,
  `rev_date` date DEFAULT NULL,
  `approved_by` varchar(120) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_qr_quote` (`quote_id`),
  CONSTRAINT `fk_qr_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_revisions`
--

LOCK TABLES `quote_revisions` WRITE;
/*!40000 ALTER TABLE `quote_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotes`
--

DROP TABLE IF EXISTS `quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` varchar(40) DEFAULT NULL,
  `tsg_number` varchar(40) DEFAULT NULL,
  `kit_sim` varchar(40) DEFAULT NULL,
  `customer` varchar(120) DEFAULT NULL,
  `part_number` varchar(60) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `revision` varchar(10) DEFAULT NULL,
  `branch` char(4) DEFAULT NULL,
  `inventory_org` varchar(10) DEFAULT NULL,
  `outside_sales` varchar(120) DEFAULT NULL,
  `inside_sales` varchar(120) DEFAULT NULL,
  `bdm` varchar(120) DEFAULT NULL,
  `eau` int(11) DEFAULT NULL,
  `release_qty` int(11) DEFAULT NULL,
  `ncnr_signed` varchar(60) DEFAULT NULL,
  `quote_requested_date` date DEFAULT NULL,
  `first_build_date` date DEFAULT NULL,
  `production_date` date DEFAULT NULL,
  `pre_bid_meeting_date` date DEFAULT NULL,
  `customer_drawings` varchar(60) DEFAULT NULL,
  `customer_bom` varchar(60) DEFAULT NULL,
  `crossed_material` varchar(60) DEFAULT NULL,
  `engineering_required` varchar(60) DEFAULT NULL,
  `fai_required` varchar(60) DEFAULT NULL,
  `coc_required` varchar(60) DEFAULT NULL,
  `ul_label` varchar(60) DEFAULT NULL,
  `certifications` varchar(255) DEFAULT NULL,
  `testing_details` varchar(255) DEFAULT NULL,
  `packaging_reqs` varchar(255) DEFAULT NULL,
  `target_pricing` varchar(120) DEFAULT NULL,
  `build_status` varchar(120) DEFAULT NULL,
  `nda_signed` varchar(60) DEFAULT NULL,
  `cbc_part` varchar(60) DEFAULT NULL,
  `customer_web` varchar(160) DEFAULT NULL,
  `current_sales` varchar(60) DEFAULT NULL,
  `global_account` varchar(20) DEFAULT NULL,
  `as_customer` varchar(20) DEFAULT NULL,
  `facility_supplier` varchar(160) DEFAULT NULL,
  `additional_notes` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Draft',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_customer` (`customer`),
  KEY `idx_part` (`part_number`),
  KEY `idx_status` (`status`),
  KEY `idx_creator` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotes`
--

LOCK TABLES `quotes` WRITE;
/*!40000 ALTER TABLE `quotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_order_lines`
--

DROP TABLE IF EXISTS `site_order_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_order_lines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `item_number` varchar(60) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `item_type` varchar(30) DEFAULT NULL,
  `quantity` decimal(14,2) NOT NULL DEFAULT 1.00,
  `unit_price` decimal(14,4) DEFAULT NULL,
  `price_source` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sol_order` (`order_id`),
  CONSTRAINT `fk_sol_order` FOREIGN KEY (`order_id`) REFERENCES `site_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_order_lines`
--

LOCK TABLES `site_order_lines` WRITE;
/*!40000 ALTER TABLE `site_order_lines` DISABLE KEYS */;
INSERT INTO `site_order_lines` VALUES
(1,1,'320FP23,00','Face plate assembly 320','WES-ETO',100.00,10.0000,'assembly-tier'),
(2,2,'320FP23,00','Face plate assembly 320','WES-ETO',250.00,10.0000,'assembly-tier'),
(3,3,'320FP23,00','Face plate assembly 320','WES-ETO',35.00,12.0000,'assembly-tier'),
(4,4,'320FP23,00','Face plate assembly 320','WES-ETO',500.00,10.0000,'assembly-tier'),
(5,5,'320FP23,00','Face plate assembly 320','WES-ETO',10.00,12.0000,'assembly-tier'),
(6,6,'320FP23,00','Face plate assembly 320','WES-ETO',1.00,12.0000,'assembly-tier');
/*!40000 ALTER TABLE `site_order_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_orders`
--

DROP TABLE IF EXISTS `site_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_number` varchar(80) NOT NULL,
  `branch` char(4) NOT NULL,
  `inventory_org` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Submitted',
  `notes` varchar(500) DEFAULT NULL,
  `ship_to` text DEFAULT NULL,
  `bill_to` text DEFAULT NULL,
  `ship_method` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_branch` (`branch`),
  KEY `idx_po` (`po_number`),
  KEY `idx_org` (`inventory_org`),
  KEY `idx_creator` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_orders`
--

LOCK TABLES `site_orders` WRITE;
/*!40000 ALTER TABLE `site_orders` DISABLE KEYS */;
INSERT INTO `site_orders` VALUES
(1,'1932-500123','1932','A10','Submitted','Smoke test order',NULL,NULL,NULL,3,'2026-07-06 15:26:37'),
(2,'1932-500999','1932','A10','Submitted','HTTP email path test',NULL,NULL,NULL,3,'2026-07-06 15:40:56'),
(3,'1918-1012345','1918','A10','Submitted',NULL,NULL,NULL,NULL,7,'2026-07-07 19:08:07'),
(4,'1938-1012345','1938','A10','Submitted',NULL,NULL,NULL,NULL,1,'2026-07-07 19:10:42'),
(5,'1918-1012345','1918','A10','Submitted',NULL,NULL,NULL,NULL,7,'2026-07-07 19:12:30'),
(6,'1918-10112345','1918','A10','Submitted',NULL,NULL,NULL,NULL,7,'2026-07-07 19:26:10');
/*!40000 ALTER TABLE `site_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(160) NOT NULL,
  `branch` char(4) DEFAULT NULL,
  `role` enum('customer','admin') NOT NULL DEFAULT 'customer',
  `status` enum('pending','active','disabled') NOT NULL DEFAULT 'pending',
  `password_hash` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin@example.com',NULL,'admin','active','$2y$10$ErffJ3/XMZpw7sgVDm5gHuSKawzk1MNuG7CYGLzwcXIlCJStNVx3S','2026-07-06 15:22:34','2026-07-06 15:22:34'),
(3,'cust@example.com','1932','customer','active','$2y$10$ugJelNhMxdKKBEIpTLcUvupwexXx0grXlbaHlWKRhZkYr/LSA86Je','2026-07-06 15:26:37','2026-07-06 15:26:37'),
(6,'neal6606@gmail.com','1938','customer','disabled','$2y$10$.sb57C5flZGR9Ob7q/up..qmGadMa3b/0eKGCckqrb/S0Yl9GJvWG','2026-07-07 18:06:01','2026-07-07 18:06:11'),
(7,'mattwesco3908@gmail.com','1918','customer','active',NULL,'2026-07-07 18:15:31','2026-07-07 18:15:31');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed
