-- Order Entry — Quoting Presets schema (overhaul item 4a, §35/§36 of the Project Bible).
-- DURABLE (CREATE TABLE IF NOT EXISTS, never touched by the data re-import scripts).
-- One row per assembly plant (orgs.inventory_org, e.g. A10, AA1) holding the four
-- quoting defaults that will auto-fill new quote cost tiers (Batch 2 wiring, later
-- worker): engineering/production labor rates and the plant's two burden factors.
--
-- Convention (MATCHES quote_cost_tiers exactly — see app/sql/quotes.sql +
-- app/src/quotes.php::cost_rollup()): burden columns are stored as a DECIMAL FRACTION
-- 0-1 (e.g. 0.1500 = 15%), same type/precision as quote_cost_tiers.burden/margin
-- (DECIMAL(6,4)), so a later worker can drop these straight into a cost-tier row with
-- no unit conversion. The Quoting Presets PAGE presents these two fields as a
-- percentage (e.g. an admin types "15" for 15%) and converts /100 on save, *100 on
-- load — friendlier data entry for plant admins than typing "0.15" — see
-- app/src/presets.php (save_quoting_preset / get_quoting_preset) for the conversion.
--
-- inventory_org is NOT a hard FK to orgs: orgs (app/sql/schema.sql) is a DROP/RECREATE
-- data-import table (rebuilt from the item-master feed), so a real FK would break on
-- every re-import. quotes.inventory_org follows the same no-FK convention.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS quoting_presets (
    -- COLLATE matches orgs.inventory_org / quotes.inventory_org (utf8mb4_general_ci) so
    -- this joins against orgs cleanly — the DB's server default collation is
    -- utf8mb4_unicode_ci, which would otherwise throw "Illegal mix of collations" on the
    -- LEFT JOIN in list_quoting_presets().
    inventory_org           VARCHAR(10) COLLATE utf8mb4_general_ci NOT NULL PRIMARY KEY,  -- orgs.inventory_org (A10, AA1, ...)
    engineering_labor_rate  DECIMAL(10,2) NOT NULL DEFAULT 0,    -- $/hr
    production_labor_rate   DECIMAL(10,2) NOT NULL DEFAULT 0,    -- $/hr
    plant_burden_materials  DECIMAL(6,4)  NOT NULL DEFAULT 0,    -- fraction, e.g. 0.15 = 15% (see convention note above)
    plant_burden_labor      DECIMAL(6,4)  NOT NULL DEFAULT 0,    -- fraction, e.g. 0.20 = 20%
    updated_at              TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
