-- Order Entry — auth / onboarding schema.
-- DURABLE: uses IF NOT EXISTS and is NOT dropped by data re-imports, so accounts
-- survive `php app/bin/import.php` (which only truncates items/order_lines).
SET NAMES utf8mb4;

-- Application users. Onboarding flow:
--   request-access  -> status 'pending' (email + branch, no password yet)
--   admin approval  -> role assigned, branch confirmed, status 'active',
--                      a one-time set-password token is issued
--   set-password    -> password_hash set; user can now log in
-- 'disabled' locks an account out without deleting its history.
CREATE TABLE IF NOT EXISTS users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    email         VARCHAR(160) NOT NULL,
    branch        CHAR(4) NULL,                              -- 4-digit branch (customers); NULL for plant admins
    role          ENUM('customer','admin') NOT NULL DEFAULT 'customer',
    status        ENUM('pending','active','disabled') NOT NULL DEFAULT 'pending',
    password_hash VARCHAR(255) NULL,                         -- NULL until the user sets one via token
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    approved_at   TIMESTAMP NULL,
    UNIQUE KEY uq_email (email)
) ENGINE=InnoDB;

-- One-time tokens for setting / resetting a password. Only the SHA-256 hash of the
-- raw token is stored; the raw token lives only in the set-password link.
CREATE TABLE IF NOT EXISTS password_tokens (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    token_hash CHAR(64) NOT NULL,                            -- sha256(raw token), hex
    expires_at DATETIME NOT NULL,
    used_at    DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_user (user_id),
    KEY idx_token (token_hash),
    CONSTRAINT fk_pwtok_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- One-time, short-lived tokens for PASSWORDLESS (magic-link) sign-in. Same storage
-- pattern as password_tokens (sha256-only, single-use, expiring), but a distinct table
-- so a login link can never be mistaken for a set-password link, and vice-versa.
-- Issued by request_and_send_magic_link(); consumed by login_with_token().
CREATE TABLE IF NOT EXISTS login_tokens (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    token_hash CHAR(64) NOT NULL,                            -- sha256(raw token), hex
    expires_at DATETIME NOT NULL,                            -- typically NOW() + 20 min
    used_at    DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_lt_user (user_id),
    KEY idx_lt_token (token_hash),
    CONSTRAINT fk_lgtok_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Fixed-window rate limiter for auth endpoints (login attempts + link/reset/request-access
-- sends). One self-resetting row per bucket = sha256(action | key), where key is a client IP
-- or a typed email. See auth.php::rate_limit_hit().
CREATE TABLE IF NOT EXISTS auth_rate_limits (
    bucket   CHAR(64) NOT NULL PRIMARY KEY,                  -- sha256(action|key), hex
    hits     INT NOT NULL DEFAULT 0,
    reset_at DATETIME NOT NULL,                              -- window end; row resets once passed
    KEY idx_reset (reset_at)
) ENGINE=InnoDB;
