-- Order Entry — Material Stats (per-plant component pricing/availability), DURABLE reference
-- data imported daily from the "material_stats" Oracle export feed (§34 Daily Import architecture).
-- One row per (item_number, org) — backs the Components page's per-plant availability grid.
-- IF NOT EXISTS so migrate.php can apply this safely on every run; the importer itself does an
-- atomic DELETE+reload of the CONTENTS (not the table) on each import (see import_material_stats()
-- in app/src/import.php), same pattern as `items`/`order_lines`.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS material_stats (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    item_number      VARCHAR(60) NOT NULL,          -- 'Item'
    description      VARCHAR(255) NULL,             -- 'Description'
    qty              DECIMAL(14,2) NULL,            -- 'qty' — on-hand qty at this org
    value            DECIMAL(14,4) NULL,            -- 'value' — on-hand $ value
    uom              VARCHAR(20) NULL,               -- 'uom'
    org              VARCHAR(10) NOT NULL,           -- 'ORG' (A10, AA1, ...)
    months_inactive  DECIMAL(10,2) NULL,             -- 'months_inactive'
    aged             DECIMAL(14,2) NULL,             -- 'aged'
    demand           DECIMAL(14,2) NULL,             -- 'demand'
    excess           DECIMAL(14,2) NULL,             -- 'excess'
    excess_value     DECIMAL(14,4) NULL,             -- 'excess value'
    allocated_value  DECIMAL(14,4) NULL,             -- 'allocated_value'
    toxic_value      DECIMAL(14,4) NULL,             -- 'toxic_value'
    address_value    DECIMAL(14,4) NULL,             -- 'address_value'
    UNIQUE KEY uq_item_org (item_number, org),        -- one row per item per org; also indexes item_number alone
    KEY idx_org (org)
) ENGINE=InnoDB;
