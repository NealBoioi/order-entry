-- Order Entry — customer account setup + account settings (post-approval).
-- DURABLE (IF NOT EXISTS). After approval a customer completes an "Amazon-style" profile that
-- autopopulates their orders. Admin-set COMPANY DEFAULTS (bill-to + ship-to) pre-fill every new
-- account. Customers keep an address book (multiple ship-tos) and multiple ship methods, and
-- pick from a dropdown per order.
SET NAMES utf8mb4;

-- Admin-managed global defaults that seed every new account's bill-to + ship-to (single row id=1).
CREATE TABLE IF NOT EXISTS company_defaults (
    id           TINYINT PRIMARY KEY DEFAULT 1,
    bill_company VARCHAR(160) NULL,
    bill_addr1   VARCHAR(160) NULL,
    bill_addr2   VARCHAR(160) NULL,
    bill_city    VARCHAR(80)  NULL,
    bill_state   VARCHAR(40)  NULL,
    bill_zip     VARCHAR(20)  NULL,
    bill_country VARCHAR(60)  NOT NULL DEFAULT 'USA',
    ship_attn    VARCHAR(120) NULL,
    ship_addr1   VARCHAR(160) NULL,
    ship_addr2   VARCHAR(160) NULL,
    ship_city    VARCHAR(80)  NULL,
    ship_state   VARCHAR(40)  NULL,
    ship_zip     VARCHAR(20)  NULL,
    ship_country VARCHAR(60)  NOT NULL DEFAULT 'USA',
    updated_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Per-user profile: contact (name + title) and the selected default ship-to / bill-to /
-- ship-method. Branch comes from users.branch (set at account request) — not stored here.
-- Ship-to AND bill-to are both address books (below), each with a default pointer here.
CREATE TABLE IF NOT EXISTS customer_profiles (
    user_id           INT PRIMARY KEY,
    full_name         VARCHAR(120) NULL,
    title             VARCHAR(80)  NULL,          -- free text (Buyer / Inside Sales Rep / ...)
    default_ship_id   INT NULL,                   -- -> customer_ship_addresses.id
    default_bill_id   INT NULL,                   -- -> customer_bill_addresses.id
    default_method_id INT NULL,                   -- -> customer_ship_methods.id
    setup_complete    TINYINT      NOT NULL DEFAULT 0,
    created_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_cp_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Bill-to address book: a customer's saved billing addresses (pick a default).
CREATE TABLE IF NOT EXISTS customer_bill_addresses (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    label      VARCHAR(80)  NULL,                 -- e.g. "Corporate AP", "Regional"
    company    VARCHAR(160) NULL,
    addr1      VARCHAR(160) NULL,
    addr2      VARCHAR(160) NULL,
    city       VARCHAR(80)  NULL,
    state      VARCHAR(40)  NULL,
    zip        VARCHAR(20)  NULL,
    country    VARCHAR(60)  NOT NULL DEFAULT 'USA',
    created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_cba_user (user_id),
    CONSTRAINT fk_cba_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Address book: a customer's saved ship-to locations (pick one per order).
CREATE TABLE IF NOT EXISTS customer_ship_addresses (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    label      VARCHAR(80)  NULL,                 -- e.g. "Main dock", "West warehouse"
    attn       VARCHAR(120) NULL,
    addr1      VARCHAR(160) NULL,
    addr2      VARCHAR(160) NULL,
    city       VARCHAR(80)  NULL,
    state      VARCHAR(40)  NULL,
    zip        VARCHAR(20)  NULL,
    country    VARCHAR(60)  NOT NULL DEFAULT 'USA',
    created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_csa_user (user_id),
    CONSTRAINT fk_csa_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- A customer's saved ship methods (terms + carrier + account #), pick one per order.
CREATE TABLE IF NOT EXISTS customer_ship_methods (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    label        VARCHAR(80)  NULL,               -- e.g. "Standard", "Rush"
    terms        VARCHAR(80)  NULL,               -- shipping terms (Prepaid & Add, Collect, ...)
    method       VARCHAR(120) NULL,               -- UPS Ground, R&L Freight, ...
    carrier_acct VARCHAR(80)  NULL,               -- carrier account #
    created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_csm_user (user_id),
    CONSTRAINT fk_csm_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB;
