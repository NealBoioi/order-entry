-- Order Entry — site-entered orders schema.
-- DURABLE (IF NOT EXISTS, never truncated by data re-imports). These are the orders
-- CAPTURED BY THIS SITE — a separate dataset from the imported Oracle `order_lines`
-- (the "Open Order" export). The two reconcile on PO# per §8.1: the plant keys a site
-- order into Oracle, and it later reappears in the rg import carrying status/tracking.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS site_orders (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    po_number     VARCHAR(80) NOT NULL,                      -- <branch>-<lot>, globally unique via branch prefix
    branch        CHAR(4) NOT NULL,                          -- first 4 chars of the PO (the customer's branch)
    inventory_org VARCHAR(10) NOT NULL,                      -- selected plant/org (orgs.inventory_org), e.g. A10
    status        VARCHAR(20) NOT NULL DEFAULT 'Submitted',  -- site-side status until Oracle takes over
    notes         VARCHAR(500) NULL,
    ship_to       TEXT NULL,                                 -- snapshot of the customer's ship-to at order time
    bill_to       TEXT NULL,                                 -- snapshot of the bill-to at order time
    ship_method   TEXT NULL,                                 -- snapshot of the chosen ship method at order time
    requested_delivery_date DATE NULL,                       -- customer's requested delivery date (optional)
    urgent        TINYINT(1) NOT NULL DEFAULT 0,             -- 1 = flagged URGENT at entry (highlighted in the plant email)
    shipment_ref  VARCHAR(120) NULL,                         -- optional customer shipment reference # (shown in the plant email)
    created_by    INT NOT NULL,                              -- users.id of the entering account
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_branch (branch),
    KEY idx_po (po_number),
    KEY idx_org (inventory_org),
    KEY idx_creator (created_by)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS site_order_lines (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    order_id     INT NOT NULL,
    item_number  VARCHAR(60) NOT NULL,
    description  VARCHAR(255) NULL,                           -- snapshot of the item description
    item_type    VARCHAR(30) NULL,                           -- WES-ETO / WES-PUR-RE at time of entry
    uom          VARCHAR(20) NULL,                            -- unit of measure snapshot (items.primary_uom), e.g. EA
    quantity     DECIMAL(14,2) NOT NULL DEFAULT 1,
    unit_price   DECIMAL(14,4) NULL,                          -- price SNAPSHOT at entry (null if none available)
    price_source VARCHAR(20) NULL,                            -- 'assembly-tier' | 'oracle-list' | 'none'
    CONSTRAINT fk_sol_order FOREIGN KEY (order_id) REFERENCES site_orders (id) ON DELETE CASCADE
) ENGINE=InnoDB;
