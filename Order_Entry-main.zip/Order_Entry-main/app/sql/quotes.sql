-- Order Entry — Quoting module schema (Phase 2 · §8/§11 of the Project Bible).
-- DURABLE (IF NOT EXISTS, never truncated by data re-imports). Models the plant's
-- quoting workbook ("Example Quote template.xlsx"), whose four sheets map to:
--   Bid Prep (Pre-Bid Proposal) -> quotes                (header / must-have info)
--   Costed BOM                  -> quote_bom_lines        (costed bill of materials)
--   Cost page                   -> quote_cost_tiers       (cost roll-up per build qty)
--   Quote Rev                   -> quote_revisions        (project-pack revision log)
-- Admin/quoting-side only — every table here carries cost/margin data that the
-- customer-visibility rules (§8.2) forbid exposing to branches.
SET NAMES utf8mb4;

-- ── Bid Prep / Pre-Bid Proposal header ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS quotes (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    quote_id              VARCHAR(40)  NULL,               -- internal Quote ID #
    tsg_number            VARCHAR(40)  NULL,               -- generated quote / TSG #
    kit_sim               VARCHAR(40)  NULL,               -- Kit SIM #
    customer              VARCHAR(120) NULL,
    part_number           VARCHAR(60)  NULL,               -- the top-level part being quoted
    description           VARCHAR(255) NULL,
    revision              VARCHAR(10)  NULL,
    branch                CHAR(4)      NULL,               -- 4-digit branch (customer), if known
    inventory_org         VARCHAR(10)  NULL,               -- quoting plant/org (orgs.inventory_org)
    outside_sales         VARCHAR(120) NULL,
    inside_sales          VARCHAR(120) NULL,
    bdm                   VARCHAR(120) NULL,               -- Business Development Manager
    eau                   INT          NULL,               -- Estimated Annual Usage
    release_qty           INT          NULL,               -- Release Quantities
    ncnr_signed           VARCHAR(60)  NULL,               -- NCNR / Mfg. Contract Signed
    quote_requested_date  DATE         NULL,
    first_build_date      DATE         NULL,
    production_date       DATE         NULL,
    pre_bid_meeting_date  DATE         NULL,
    -- Must-have qualifiers (Yes/No/N/A or short note)
    customer_drawings     VARCHAR(60)  NULL,
    customer_bom          VARCHAR(60)  NULL,               -- Customer BOM w/ mfr part #s
    crossed_material      VARCHAR(60)  NULL,               -- Crossed material approved?
    engineering_required  VARCHAR(60)  NULL,
    -- Additional information
    fai_required          VARCHAR(60)  NULL,
    coc_required          VARCHAR(60)  NULL,               -- Certificate of Conformity
    ul_label              VARCHAR(60)  NULL,
    certifications        VARCHAR(255) NULL,               -- CSA, CE, ATEX, IECEx, etc.
    testing_details       VARCHAR(255) NULL,
    packaging_reqs        VARCHAR(255) NULL,
    target_pricing        VARCHAR(120) NULL,
    build_status          VARCHAR(120) NULL,               -- new build vs. currently manufactured
    nda_signed            VARCHAR(60)  NULL,
    cbc_part              VARCHAR(60)  NULL,               -- CBC Part #
    customer_web          VARCHAR(160) NULL,
    current_sales         VARCHAR(60)  NULL,               -- Customer current sales $ to CBC
    global_account        VARCHAR(20)  NULL,               -- Yes / No
    as_customer           VARCHAR(20)  NULL,               -- Currently AS customer Yes / No
    facility_supplier     VARCHAR(160) NULL,               -- what facility or outside supplier
    additional_notes      TEXT         NULL,
    status                VARCHAR(20)  NOT NULL DEFAULT 'Draft',   -- Draft/Quoting/Submitted/Won/Lost
    created_by            INT          NOT NULL,
    created_at            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_customer (customer),
    KEY idx_part (part_number),
    KEY idx_status (status),
    KEY idx_creator (created_by)
) ENGINE=InnoDB;

-- ── Costed BOM lines ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS quote_bom_lines (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    quote_id           INT NOT NULL,
    sort_order         INT NOT NULL DEFAULT 0,
    level              TINYINT      NULL,                  -- BOM level (1 top, 2 sub-assembly, ...)
    customer_pn        VARCHAR(60)  NULL,                  -- Customer P/N
    mfg_item           VARCHAR(120) NULL,                  -- MFG item
    description        VARCHAR(255) NULL,
    uom                VARCHAR(10)  NULL,
    qty_per            DECIMAL(14,5) NOT NULL DEFAULT 1,   -- Qty per finished good
    line_type          VARCHAR(30)  NULL,                  -- Sub Assembly / Purchase Item
    moq                INT          NULL,                  -- Minimum order qty
    flm                INT          NULL,                  -- Pack size
    lead_time_weeks    INT          NULL,                  -- Total lead time (weeks)
    manufacturer       VARCHAR(120) NULL,
    project_supplier   VARCHAR(120) NULL,
    sim_supplier_item  VARCHAR(120) NULL,                  -- SIM / Supplier Item
    quote_number       VARCHAR(60)  NULL,
    notes              VARCHAR(255) NULL,
    crossed_items      VARCHAR(120) NULL,
    standard_cost      DECIMAL(14,4) NULL,                 -- unit standard cost
    CONSTRAINT fk_qbl_quote FOREIGN KEY (quote_id) REFERENCES quotes (id) ON DELETE CASCADE,
    KEY idx_qbl_quote (quote_id)
) ENGINE=InnoDB;

-- ── Cost roll-up per build quantity (the Cost page) ─────────────────────────
-- Material cost is derived from the BOM (Σ standard_cost × qty_per); labor, burden,
-- OSP and margin are entered per build qty. Burdened figures & resale are COMPUTED in
-- app code (see quotes.php::cost_rollup) so the math is transparent and never stale.
CREATE TABLE IF NOT EXISTS quote_cost_tiers (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    quote_id     INT NOT NULL,
    sort_order   INT NOT NULL DEFAULT 0,
    label        VARCHAR(60)  NULL,                        -- e.g. "Production Quantity 25"
    build_qty    INT NOT NULL DEFAULT 1,
    labor_rate   DECIMAL(10,2) NOT NULL DEFAULT 0,         -- per hour
    labor_hours  DECIMAL(10,4) NOT NULL DEFAULT 0,         -- per unit
    burden       DECIMAL(6,4)  NOT NULL DEFAULT 0,         -- fraction, e.g. 0.15
    osp_labor    DECIMAL(12,4) NOT NULL DEFAULT 0,         -- outside-service labor, no burden
    margin       DECIMAL(6,4)  NOT NULL DEFAULT 0,         -- resale margin fraction, e.g. 0.25
    CONSTRAINT fk_qct_quote FOREIGN KEY (quote_id) REFERENCES quotes (id) ON DELETE CASCADE,
    KEY idx_qct_quote (quote_id)
) ENGINE=InnoDB;

-- ── Project-pack revision log (Quote Rev) ───────────────────────────────────
CREATE TABLE IF NOT EXISTS quote_revisions (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    quote_id    INT NOT NULL,
    rev_no      VARCHAR(10)  NULL,
    rev_date    DATE         NULL,
    approved_by VARCHAR(120) NULL,
    description VARCHAR(255) NULL,
    changes     TEXT         NULL,     -- auto change log: everything the save changed, one per line
    created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_qr_quote FOREIGN KEY (quote_id) REFERENCES quotes (id) ON DELETE CASCADE,
    KEY idx_qr_quote (quote_id)
) ENGINE=InnoDB;
