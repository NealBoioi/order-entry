-- Order Entry — Contact directory (DURABLE, admin-editable).
-- Backs both the Contact page and email routing (§8.2). Kept as FRESH tables rather
-- than columns on `orgs`, so setup is a plain CREATE IF NOT EXISTS on either MariaDB
-- (dev) or MySQL (prod) — no engine-specific ALTER needed.
SET NAMES utf8mb4;

-- Editable contact for each manufacturing plant/org. Ties to orgs.inventory_org.
-- This is what new-order notifications route to (the order's selected plant).
CREATE TABLE IF NOT EXISTS plant_contacts (
    inventory_org VARCHAR(10) PRIMARY KEY,       -- A10, AA1 (matches orgs.inventory_org)
    contact_name  VARCHAR(120) NULL,
    contact_email VARCHAR(160) NULL,
    contact_phone VARCHAR(40)  NULL,
    updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Branch directory: friendly name + the customer-side contact for a branch, and the
-- plant that branch usually orders from. Branch = 4-digit code (first 4 chars of a PO).
-- (Legacy: still read by notify.php email routing; the admin UI moved to Program Assignments.)
CREATE TABLE IF NOT EXISTS branches (
    branch        CHAR(4) PRIMARY KEY,
    name          VARCHAR(120) NULL,
    default_org   VARCHAR(10)  NULL,             -- default plant (orgs.inventory_org)
    contact_name  VARCHAR(120) NULL,
    contact_email VARCHAR(160) NULL,
    contact_phone VARCHAR(40)  NULL,
    updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Program Assignments — the plant's customer contact list (models Examples/Contact_list.xlsx).
-- This is the NEW "Contacts" page: admin-editable, sales/customers read-only. The
-- `plant_order_inbox` column is ADMIN-ONLY (the template's lone "Admin View" column); every
-- other column is visible to all roles. Seeded from seed_program_assignments.sql when empty.
CREATE TABLE IF NOT EXISTS program_assignments (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    customer          VARCHAR(160) NOT NULL,
    pm                VARCHAR(120) NULL,          -- Program Manager
    plant_order_inbox VARCHAR(160) NULL,          -- ADMIN-ONLY: plant order-inbox email
    plant_site        VARCHAR(120) NULL,
    sales_contact     VARCHAR(160) NULL,
    sales_branch      VARCHAR(20)  NULL,
    bdm               VARCHAR(120) NULL,          -- Business Development Manager
    sort_order        INT NOT NULL DEFAULT 0,
    KEY idx_pa_customer (customer),
    KEY idx_pa_branch (sales_branch)
) ENGINE=InnoDB;
