-- Order Entry MVP — thin-slice schema. Safe to re-run (drops + recreates).
SET NAMES utf8mb4;

DROP TABLE IF EXISTS order_lines;
DROP TABLE IF EXISTS items;
DROP TABLE IF EXISTS orgs;
-- NOTE: `assembly_pricing` is intentionally NOT dropped here — it holds ADMIN-ENTERED
-- data (assembly tiers set on the admin Pricing page) and lives in the DURABLE schema
-- `app/sql/pricing.sql` (applied by `php app/bin/migrate.php`). Dropping it here would
-- erase real pricing on every data reset.

-- Manufacturing plant / inventory org reference (keyed off rg `Inventory Org`).
CREATE TABLE orgs (
    inventory_org VARCHAR(10) PRIMARY KEY,   -- A10, AA1
    plant_code    VARCHAR(10),               -- 3908, 1931
    name          VARCHAR(80),
    contact_email VARCHAR(120)
) ENGINE=InnoDB;

-- Item master (from lr_item_warehouse_all_<date>.xlsx).
CREATE TABLE items (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    organization          VARCHAR(80),
    item_number           VARCHAR(60),
    description           VARCHAR(255),
    primary_uom           VARCHAR(20),
    item_status           VARCHAR(30),
    item_type             VARCHAR(30),            -- WES-PUR-RE (buy) / WES-ETO (assembly)
    list_price            DECIMAL(14,4) NULL,     -- buy items only; ADMIN-only, never shown to customers
    frozen_cost           DECIMAL(14,4) NULL,     -- Oracle standard cost; ADMIN-only, never shown to customers
    min_order_qty         INT NULL,               -- MOQ
    flm                   VARCHAR(20) NULL,       -- FLM
    supplier              VARCHAR(160) NULL,      -- sourcing rule (source_rule_name)
    sim_number            VARCHAR(60) NULL,       -- SIM
    supplier_item         VARCHAR(120) NULL,      -- line_supplier_item
    fixed_lead_time       INT NULL,
    cumulative_lead_time  INT NULL,
    UNIQUE KEY uq_item (organization, item_number)
) ENGINE=InnoDB;

-- (assembly_pricing moved to the durable schema — see app/sql/pricing.sql.)

-- Sales order lines (from <ORG>_daily_rg_<date>.csv). Imports admin-only cost/price
-- columns too; the app gates them by role.
CREATE TABLE order_lines (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    order_number        VARCHAR(30),               -- Oracle SO number
    customer_po_number  VARCHAR(80),
    branch              CHAR(4),                   -- first 4 chars of the PO
    line_number         VARCHAR(20),
    order_date          VARCHAR(20),
    order_status        VARCHAR(30),
    line_status         VARCHAR(40),
    ship_line_status    VARCHAR(40),
    ordered_item        VARCHAR(60),
    item_description     VARCHAR(255),
    ordered_qty         DECIMAL(14,2),
    shipped_qty         DECIMAL(14,2),
    on_hand_qty         DECIMAL(14,2),             -- plant on-hand for the item (RG 'On Hand Qty'); drives stock allocation
    unit_price          DECIMAL(14,4),             -- ADMIN ONLY
    extended_price      DECIMAL(14,4),             -- ADMIN ONLY
    unit_cost           DECIMAL(14,4),             -- ADMIN ONLY
    tracking_number     VARCHAR(60),
    actual_ship_date    VARCHAR(20),
    scheduled_ship_date VARCHAR(20),               -- ADMIN ONLY (hidden from customer)
    promise_date        VARCHAR(20),
    request_date        VARCHAR(20),
    invoice_number      VARCHAR(30),
    invoice_date        VARCHAR(20),
    inventory_org       VARCHAR(10),               -- plant (rg last column)
    KEY idx_branch (branch),
    KEY idx_po (customer_po_number),
    KEY idx_item (ordered_item)
) ENGINE=InnoDB;

-- Reference / demo seed data ------------------------------------------------
INSERT INTO orgs (inventory_org, plant_code, name, contact_email) VALUES
    ('A10', '3908', 'Little Rock Assembly', 'littlerock-orders@example.com'),
    ('AA1', '1931', 'Austin Assembly',      'austin-orders@example.com');

-- (Demo assembly tiers now seeded idempotently in app/sql/pricing.sql so they survive
--  data resets and can be edited on the admin Pricing page.)
