-- Order Entry — admin-entered assembly tiered pricing (DURABLE).
-- WES-ETO assemblies are NOT priced in Oracle (§8.2); an Admin sets tiers here on the
-- Pricing page, and new-order entry resolves the price by QTY (highest min_qty <= qty).
-- IF NOT EXISTS + never dropped, so real pricing survives data re-imports/resets.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS assembly_pricing (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    item_number VARCHAR(60) NOT NULL,
    min_qty     INT NOT NULL DEFAULT 1,               -- price applies at this qty and up
    unit_price  DECIMAL(14,4) NOT NULL,
    quote_date  DATE NULL,                            -- when this price was quoted (defaults to today at save)
    expire_date DATE NULL,                            -- quotes last 3 months by default; editable at save
    UNIQUE KEY uq_item_qty (item_number, min_qty),    -- one price per (item, tier)
    KEY idx_item (item_number, min_qty)
) ENGINE=InnoDB;

-- (Demo tiers are seeded ONLY when the table is empty — see app/bin/migrate.php — so a
--  fresh DB gets sample data while existing admin-entered pricing is never touched.)
