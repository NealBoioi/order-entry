-- Order Entry — Quote workspace revamp v2 (overhaul item 4b, §21/§35 of the Project Bible).
-- DURABLE (CREATE TABLE IF NOT EXISTS), applied by app/bin/migrate.php. New columns on the
-- existing quotes/quote_cost_tiers tables are added there via add_column_if_missing() —
-- this file only holds brand-new tables.
SET NAMES utf8mb4;

-- Per-BOM-line volume price breaks (Costed BOM "tiered pricing" — Batch 2 addition; the
-- 2026-07-13 note in §21 said components did NOT get tiered pricing — superseded now per
-- Matt's spec). When a line has rows here, its Std Cost auto-resolves from the line's MOQ
-- against these breaks (largest min_qty <= MOQ) instead of a manually typed standard_cost.
CREATE TABLE IF NOT EXISTS quote_bom_price_breaks (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    bom_line_id INT NOT NULL,
    min_qty     INT NOT NULL DEFAULT 1,
    unit_price  DECIMAL(14,4) NOT NULL,
    CONSTRAINT fk_qbpb_line FOREIGN KEY (bom_line_id) REFERENCES quote_bom_lines (id) ON DELETE CASCADE,
    UNIQUE KEY uq_qbpb_line_qty (bom_line_id, min_qty),
    KEY idx_qbpb_line (bom_line_id)
) ENGINE=InnoDB;

-- Quote Summary — tiered breakdown per Build qty (the qtys come from the Labor Breakdown
-- rows). Component/labor cost and the computed transfer/sale prices are recomputed
-- authoritatively on every save (see quotes.php::compute_summary_tier()); persisted here so
-- a later worker (New Order pricing) can resolve a transfer price by part# + qty without
-- redoing the roll-up math.
CREATE TABLE IF NOT EXISTS quote_summary_tiers (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    quote_id          INT NOT NULL,
    build_qty         INT NOT NULL,
    margin            DECIMAL(6,4)  NULL,             -- blank = compute at the 25% default
    component_cost    DECIMAL(14,4) NOT NULL DEFAULT 0,
    labor_cost        DECIMAL(14,4) NOT NULL DEFAULT 0,
    burden_materials  DECIMAL(6,4)  NOT NULL DEFAULT 0,
    burden_labor      DECIMAL(6,4)  NOT NULL DEFAULT 0,
    transfer_price    DECIMAL(14,4) NOT NULL DEFAULT 0,
    sale_price        DECIMAL(14,4) NOT NULL DEFAULT 0,
    CONSTRAINT fk_qst_quote FOREIGN KEY (quote_id) REFERENCES quotes (id) ON DELETE CASCADE,
    UNIQUE KEY uq_qst_quote_qty (quote_id, build_qty),
    KEY idx_qst_quote (quote_id)
) ENGINE=InnoDB;
