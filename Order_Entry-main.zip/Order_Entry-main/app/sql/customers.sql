-- Order Entry — canonical Customers list (§26 follow-up: duplicate-proof customer names).
-- DURABLE (IF NOT EXISTS). Backs the Customer field on the Contact List / Program
-- Assignments add-edit form: a wildcard-searchable picklist so "TKE" / "ThyssenKrupp" /
-- "TkE" don't all end up as separate rows. `program_assignments.customer` stays a plain
-- VARCHAR (no FK — the 105 seeded rows aren't migrated to an id reference); the UI is
-- responsible for always writing a name that exists in this table. Default table
-- collation (utf8mb4_general_ci, from db charset) makes the UNIQUE key case-insensitive,
-- so "tke" and "TKE" collide instead of creating two rows.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(160) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY idx_customers_name (name)
) ENGINE=InnoDB;
