<?php
/**
 * Address-suggestion proxy (JSON).  GET ?q=<partial address> -> matching addresses.
 *   { "suggestions": [ { addr1, city, state, zip, country, countrycode, full }, ... ] }
 * Logic lives in app/src/geocode.php (provider-swappable). Auth-gated so it can't be an open proxy.
 */
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/geocode.php';
auth_boot();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, max-age=60');

if (!current_user()) {
    http_response_code(401);
    echo json_encode(['error' => 'auth', 'suggestions' => []]);
    exit;
}

$q = trim((string) ($_GET['q'] ?? ''));
if (mb_strlen($q) < 3) {          // typeahead: start suggesting after a few characters
    echo json_encode(['suggestions' => []]);
    exit;
}

echo json_encode(['suggestions' => geocode_suggest($q)], JSON_UNESCAPED_SLASHES);
