<?php
require __DIR__ . '/../src/magic.php';
auth_boot();

$token = trim($_GET['token'] ?? '');
$err = null; $sent = false;

// 1) Arriving via an emailed link (?token=...) — consume it and sign in.
if ($token !== '') {
    [$ok, $err] = login_with_token($token);
    if ($ok) redirect('index.php');
    // else fall through and show the error + a "request a new link" form.
} elseif (current_user()) {
    redirect('index.php');                       // already signed in, nothing to do
}

// 2) Requesting a link.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = trim($_POST['email'] ?? '');
    [$ipOk] = rate_limit_hit('magic_ip', client_ip(), 8, 900);     // 8 / 15 min per IP
    [$emOk] = rate_limit_hit('magic_email', $email, 4, 900);       // 4 / 15 min per email
    if (!$ipOk || !$emOk) {
        // Neutral message — applies to the typed email regardless of whether an account exists.
        $err = 'You\'ve requested several sign-in links recently. Please wait a few minutes and try again.';
    } else {
        request_and_send_magic_link($email, app_base_url());
        $sent = true;                            // uniform confirmation (no account leak)
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign-in link — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="authwrap">
  <div class="brandbig"><svg class="wmark" viewBox="217 219 943 441" xmlns="http://www.w3.org/2000/svg"><path fill="#00AA13" d="M938.2,652.9l221.1-415.8c4.1-7.8-1.5-17.2-10.3-17.2H934.2c-6.2,0-11.8,3.4-14.7,8.9L804.8,444.3l110.9,208.6c2.2,4.2,6.5,6.8,11.2,6.8h0C931.7,659.6,936,657,938.2,652.9z"/><path fill="#00AA13" d="M221.3,237.1l211.1,397.1l115.3-216.9L447.5,228.7c-2.9-5.4-8.6-8.9-14.7-8.9H231.6C222.8,219.9,217.2,229.3,221.3,237.1z"/><path fill="#00AA13" d="M446,659.6h234.3c6.2,0,11.8-3.4,14.7-8.9l109.8-206.5L693.9,235.7c-2.2-4.1-6.5-6.8-11.2-6.8l0,0c-4.7,0-9,2.6-11.2,6.8L446,659.6z"/></svg><span class="brand-text"><b>ASSEMBLIES</b><i>Order Entry</i></span></div>
  <div class="authcard">
    <h1>Email me a sign-in link</h1>
    <?php if ($sent): ?>
      <div class="msg ok">If that email has an active account, a sign-in link is on its way.
        It works once and expires in 20 minutes.</div>
      <p class="alt"><a href="login.php">Back to sign in</a></p>
    <?php else: ?>
      <?php if ($err): ?><div class="msg err"><?= h($err) ?></div><?php endif; ?>
      <p class="lead">No password needed — we'll email you a one-time link to sign in.</p>
      <form method="post" action="magic-login.php">
        <?= csrf_field() ?>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= h($_POST['email'] ?? '') ?>" autofocus required>
        <button type="submit">Send sign-in link</button>
      </form>
      <p class="alt">Prefer a password? <a href="login.php">Sign in normally</a></p>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
