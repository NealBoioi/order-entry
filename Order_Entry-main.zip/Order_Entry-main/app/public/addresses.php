<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/profile.php';
auth_boot();

$me  = require_login();
$uid = (int) $me['id'];
ensure_profile($uid);

// One page serves both address books, switched by ?type=ship|bill.
$isBill = (($_GET['type'] ?? $_POST['type'] ?? 'ship') === 'bill');
$type   = $isBill ? 'bill' : 'ship';
$cfg = $isBill
    ? ['title' => 'Bill-To Addresses', 'noun' => 'bill-to', 'list' => 'list_bill_addresses',
       'get' => 'get_bill_address', 'save' => 'save_bill_address', 'del' => 'delete_bill_address',
       'setdef' => 'set_default_bill', 'fmt' => 'format_bill_address', 'defcol' => 'default_bill_id']
    : ['title' => 'Ship-To Addresses', 'noun' => 'ship-to', 'list' => 'list_ship_addresses',
       'get' => 'get_ship_address', 'save' => 'save_ship_address', 'del' => 'delete_ship_address',
       'setdef' => 'set_default_ship', 'fmt' => 'format_ship_address', 'defcol' => 'default_ship_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    switch ($_POST['action'] ?? '') {
        case 'save':
            [$ok, $res] = $cfg['save']($uid, (int) ($_POST['id'] ?? 0) ?: null, $_POST);
            if ($ok && empty(get_profile($uid)[$cfg['defcol']]) && count($cfg['list']($uid)) === 1) $cfg['setdef']($uid, (int) $res);
            $_SESSION['flash'] = $ok ? ['ok', ucfirst($cfg['noun']) . ' address saved.'] : ['err', $res];
            break;
        case 'delete':
            $cfg['del']($uid, (int) ($_POST['id'] ?? 0));
            $_SESSION['flash'] = ['info', 'Address removed.'];
            break;
        case 'default':
            $cfg['setdef']($uid, (int) ($_POST['id'] ?? 0));
            $_SESSION['flash'] = ['ok', 'Default updated.'];
            break;
    }
    redirect('addresses.php?type=' . $type);
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$rows  = $cfg['list']($uid);
$def   = (int) (get_profile($uid)[$cfg['defcol']] ?? 0);
$edit  = isset($_GET['edit']) ? $cfg['get']((int) $_GET['edit']) : null;
if ($edit && (int) $edit['user_id'] !== $uid) $edit = null;
$e = fn($f) => h($edit[$f] ?? '');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($cfg['title']) ?> — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('settings'); ?>
<main>
  <p class="note"><a href="settings.php">← Settings</a></p>
  <h1><?= h($cfg['title']) ?> <span class="sub">the one marked Default auto-populates on new orders</span></h1>
  <?php if ($flash): ?><div class="msg <?= h($flash[0]) ?>"><?= h($flash[1]) ?></div><?php endif; ?>

  <?php if ($rows): ?>
    <?php foreach ($rows as $r): $isDefault = ((int) $r['id'] === $def); ?>
      <div class="addrcard <?= $isDefault ? 'isdefault' : '' ?>">
        <div class="ac-head">
          <span class="ac-label"><?= h($r['label'] ?: ($isBill ? ($r['company'] ?? 'Bill-to') : 'Ship-to')) ?></span>
          <?php if ($isDefault): ?><span class="statuspill active">★ Default</span><?php endif; ?>
        </div>
        <div class="ac-body"><?= h($cfg['fmt']($r)) ?></div>
        <div class="ac-actions">
          <?php if (!$isDefault): ?>
            <form class="inline" method="post" action="addresses.php">
              <?= csrf_field() ?><input type="hidden" name="type" value="<?= h($type) ?>"><input type="hidden" name="action" value="default"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
              <button class="btn-sm primary" type="submit">Set To Default</button>
            </form>
          <?php endif; ?>
          <a class="btn-sm" href="addresses.php?type=<?= h($type) ?>&edit=<?= (int) $r['id'] ?>#form">Edit</a>
          <form class="inline" method="post" action="addresses.php" data-confirm="Remove this address?">
            <?= csrf_field() ?><input type="hidden" name="type" value="<?= h($type) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
            <button class="btn-sm danger" type="submit">Delete</button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <p class="empty">No <?= h($cfg['noun']) ?> addresses yet — add one below.</p>
  <?php endif; ?>

  <div class="qsection" id="form" style="margin-top:18px;">
    <h2 class="h2"><?= $edit ? 'Edit address' : 'Add a new ' . h($cfg['noun']) . ' address' ?></h2>
    <form method="post" action="addresses.php" class="<?= $edit ? 'editing' : '' ?>">
      <?= csrf_field() ?><input type="hidden" name="type" value="<?= h($type) ?>"><input type="hidden" name="action" value="save">
      <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>
      <div class="qgrid">
        <label>Label<input type="text" name="label" value="<?= $e('label') ?>" placeholder="<?= $isBill ? 'e.g. Corporate AP' : 'e.g. Main dock' ?>"></label>
        <?php if ($isBill): ?>
          <label class="wide">Company / bill-to name<input type="text" name="company" value="<?= $e('company') ?>"></label>
        <?php else: ?>
          <label>Attention / recipient<input type="text" name="attn" value="<?= $e('attn') ?>"></label>
        <?php endif; ?>
        <label class="wide">Street address *<input type="text" name="addr1" value="<?= $e('addr1') ?>" required></label>
        <label class="wide">Address line 2<input type="text" name="addr2" value="<?= $e('addr2') ?>"></label>
        <label>City *<input type="text" name="city" value="<?= $e('city') ?>" required></label>
        <label>State *<input type="text" name="state" value="<?= $e('state') ?>" required></label>
        <label>ZIP *<input type="text" name="zip" value="<?= $e('zip') ?>" required></label>
        <label>Country<input type="text" name="country" value="<?= $edit ? $e('country') : 'USA' ?>"></label>
      </div>
      <div class="saverow"><button type="submit" class="btn-save"><?= $edit ? 'Update address' : 'Add address' ?></button>
        <?php if ($edit): ?><a class="btn-sm" href="addresses.php?type=<?= h($type) ?>">Cancel</a><?php endif; ?></div>
    </form>
  </div>
</main>
<footer>Account · <?= h($cfg['title']) ?> · PHP <?= PHP_VERSION ?></footer>
<script src="address-autocomplete.js?v=3"></script>
</body>
</html>
