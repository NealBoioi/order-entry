<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/orders.php';
auth_boot();

$me    = require_login();
$role  = $me['role'];
$isAdmin = $role === 'admin';

// Customers see only their branch's submissions; admins see every branch.
$orders = list_site_orders($isAdmin ? null : (string) $me['branch'], 200);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pending Orders — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('pending'); ?>
<main>
  <h1>Pending Orders
    <span class="sub"><?= $isAdmin ? 'all portal orders across branches' : 'orders your branch entered on the portal' ?> · newest first</span>
  </h1>
  <p class="note">These are orders entered here on the portal, awaiting keying into Oracle.
    Once in Oracle they also appear under <a href="index.php">Order Status</a> with shipping/tracking.</p>

  <?php if (!$orders): ?>
    <p class="empty">No pending orders yet. <a href="new-order.php">Enter one</a>.</p>
  <?php else: ?>
    <div class="order-results">
    <?php foreach ($orders as $o): ?>
      <div class="order-card">
        <div class="oc-head">
          <div class="oc-id">
            <span class="oc-po"><?= h($o['po_number']) ?></span>
            <span class="oc-sub"><?= h($o['plant_name'] ? $o['plant_name'].' ('.$o['inventory_org'].')' : $o['inventory_org']) ?><?php if ($isAdmin): ?> · Branch <?= h($o['branch']) ?><?php endif; ?></span>
          </div>
          <span class="ocs ocs-blue"><?= h($o['status']) ?></span>
        </div>
        <div class="oc-grid">
          <div class="oc-cell"><span class="oc-lbl">Lines</span><span class="oc-val"><?= h($o['line_count']) ?></span></div>
          <div class="oc-cell"><span class="oc-lbl">Total</span><span class="oc-val">$<?= number_format((float) $o['total'], 2) ?></span></div>
          <div class="oc-cell"><span class="oc-lbl">Submitted</span><span class="oc-val"><?= h($o['created_at']) ?></span></div>
          <?php if ($isAdmin): ?><div class="oc-cell"><span class="oc-lbl">Branch</span><span class="oc-val"><?= h($o['branch']) ?></span></div><?php endif; ?>
        </div>
        <div class="oc-foot">
          <a class="btn-sm primary" href="order.php?id=<?= (int) $o['id'] ?>" data-order-modal data-order-id="<?= (int) $o['id'] ?>">View order</a>
        </div>
      </div>
    <?php endforeach; ?>
    </div>
  <?php endif; ?>
</main>
<footer>Thin MVP slice · submitted-order history · PHP <?= PHP_VERSION ?></footer>
<script src="order-modal.js?v=1"></script>
</body>
</html>
