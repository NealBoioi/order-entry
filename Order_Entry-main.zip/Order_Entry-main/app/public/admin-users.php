<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/account_mail.php';
auth_boot();
$me = require_admin();

// Absolute base URL for building set-password links (emailed to the user; shown on-screen
// as a fallback when mail is disabled or a send fails).
function base_url(): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? '127.0.0.1:8000';
    $dir    = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return $scheme . '://' . $host . $dir;
}

// --- Actions (POST, then redirect so a refresh doesn't resubmit) ------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $uid    = (int) ($_POST['user_id'] ?? 0);

    if ($action === 'approve') {
        [$ok, $res] = approve_user($uid, $_POST['role'] ?? 'customer', $_POST['branch'] ?? null);
        if ($ok) {
            $email = user_email_by_id($uid);
            $link  = base_url() . '/set-password.php?token=' . $res;
            [$sent, $err] = $email ? email_password_link($email, $link, true) : [false, 'no email on file'];
            if ($sent) {
                $_SESSION['flash'] = ['ok', "Account approved. A set-password link was emailed to $email."];
            } elseif ($err === null) {
                $_SESSION['flash'] = ['ok', 'Account approved. Email is off — send this one-time link:', $link];
            } else {
                $_SESSION['flash'] = ['info', "Account approved, but the email didn't send ($err). Send this link manually:", $link];
            }
        } else {
            $_SESSION['flash'] = ['err', $res];
        }
    } elseif ($action === 'reset') {
        $raw   = issue_password_token($uid);
        $email = user_email_by_id($uid);
        $link  = base_url() . '/set-password.php?token=' . $raw;
        [$sent, $err] = $email ? email_password_link($email, $link, false) : [false, 'no email on file'];
        if ($sent) {
            $_SESSION['flash'] = ['ok', "A new password link was emailed to $email (previous links are now void)."];
        } elseif ($err === null) {
            $_SESSION['flash'] = ['ok', 'New password link (previous links are now void):', $link];
        } else {
            $_SESSION['flash'] = ['info', "New link created, but the email didn't send ($err). Send it manually:", $link];
        }
    } elseif ($action === 'deny') {
        $email = user_email_by_id($uid);
        $_SESSION['flash'] = deny_user($uid)
            ? ['info', 'Access request denied' . ($email ? " for $email" : '') . ' — the request was removed.']
            : ['err', 'Could not deny that request (only pending requests can be denied).'];
    } elseif ($action === 'delete') {
        if ($uid === (int) $me['id']) {
            $_SESSION['flash'] = ['err', "You can't delete your own account."];
        } else {
            $email = user_email_by_id($uid);
            $_SESSION['flash'] = delete_user($uid)
                ? ['info', 'Account deleted' . ($email ? " ($email)" : '') . ' — profile, addresses and ship methods removed.']
                : ['err', 'Could not delete that account.'];
        }
    } elseif ($action === 'disable') {
        set_user_status($uid, 'disabled');
        $_SESSION['flash'] = ['info', 'Account disabled.'];
    } elseif ($action === 'enable') {
        set_user_status($uid, 'active');
        $_SESSION['flash'] = ['info', 'Account re-enabled.'];
    }
    redirect('admin-users.php');
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
$users = list_users();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Users — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('users'); ?>
<main>
  <h1>Users <span class="sub">approve requests · assign role &amp; branch · issue password links</span></h1>

  <?php if ($flash): ?>
    <div class="msg <?= h($flash[0]) ?>">
      <?= h($flash[1]) ?>
      <?php if (!empty($flash[2])): ?><span class="token"><?= h($flash[2]) ?></span><?php endif; ?>
    </div>
  <?php endif; ?>

  <div class="tablewrap"><table>
    <thead><tr>
      <th>Email</th><th>Branch</th><th>Role</th><th>Status</th><th>Requested</th><th>Actions</th>
    </tr></thead>
    <tbody>
    <?php foreach ($users as $u): ?>
      <tr>
        <td><?= h($u['email']) ?></td>
        <td><?= h($u['branch'] ?: '—') ?></td>
        <td><?= h($u['role']) ?></td>
        <td><span class="statuspill <?= h($u['status']) ?>"><?= h($u['status']) ?></span></td>
        <td><?= h($u['created_at']) ?></td>
        <td>
          <div class="row-actions">
          <a class="btn-sm" href="admin-user-account.php?id=<?= (int) $u['id'] ?>">View Account</a>
          <?php if ($u['status'] === 'pending'): ?>
            <form class="inline" method="post" action="admin-users.php">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="approve">
              <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
              <select name="role" class="ctl">
                <option value="customer">Customer</option>
                <option value="admin">Admin</option>
              </select>
              <input type="text" name="branch" class="ctl" value="<?= h($u['branch']) ?>" size="5"
                     inputmode="numeric" pattern="\d{4}" maxlength="4" placeholder="Branch #" aria-label="Branch #">
              <button class="btn-sm primary" type="submit">Approve</button>
            </form>
            <form class="inline" method="post" action="admin-users.php"
                  data-confirm="Deny and remove this pending access request?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="deny">
              <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
              <button class="btn-sm danger" type="submit">Deny</button>
            </form>
          <?php else: ?>
            <form class="inline" method="post" action="admin-users.php">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="reset">
              <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
              <button class="btn-sm" type="submit">Password link</button>
            </form>
            <?php if ($u['status'] === 'active' && (int) $u['id'] !== (int) $me['id']): ?>
              <form class="inline" method="post" action="admin-users.php">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="disable">
                <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                <button class="btn-sm danger" type="submit">Disable</button>
              </form>
            <?php elseif ($u['status'] === 'disabled'): ?>
              <form class="inline" method="post" action="admin-users.php">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="enable">
                <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                <button class="btn-sm ok" type="submit">Enable</button>
              </form>
            <?php endif; ?>
            <?php if ((int) $u['id'] !== (int) $me['id']): ?>
              <form class="inline" method="post" action="admin-users.php"
                    data-confirm="Permanently delete <?= h($u['email']) ?> and all their saved data (profile, addresses, ship methods)? This can't be undone.">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                <button class="btn-sm danger" type="submit">Delete</button>
              </form>
            <?php endif; ?>
          <?php endif; ?>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$users): ?><tr><td colspan="6" class="empty">No users yet.</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</main>
<footer>Thin MVP slice · auth &amp; onboarding · PHP <?= PHP_VERSION ?></footer>
</body>
</html>
