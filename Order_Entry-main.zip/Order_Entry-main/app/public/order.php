<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/orders.php';
auth_boot();

$me   = require_login();
$role = $me['role'];
$id   = (int) ($_GET['id'] ?? 0);
$isNew = isset($_GET['new']);

$data = $id ? get_site_order($id) : null;
if (!$data) { http_response_code(404); exit('404 — order not found.'); }

$order = $data['order'];
// Customers may only view their own branch's site orders.
if ($role !== 'admin' && $order['branch'] !== $me['branch']) {
    http_response_code(403);
    exit('403 — this order belongs to another branch.');
}

$total = 0.0;
foreach ($data['lines'] as $l) { if ($l['unit_price'] !== null) $total += $l['unit_price'] * $l['quantity']; }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Order <?= h($order['po_number']) ?> — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header(''); ?>
<main>
  <?php if ($isNew): ?><div class="msg ok">Order submitted. The plant has been notified.</div><?php endif; ?>
  <h1>Order <?= h($order['po_number']) ?> <span class="statuspill active"><?= h($order['status']) ?></span>
    <?php if (!empty($order['urgent'])): ?><span class="statuspill urgent">URGENT</span><?php endif; ?></h1>

  <dl class="ordermeta">
    <dt>PO #</dt><dd><?= h($order['po_number']) ?></dd>
    <dt>Branch</dt><dd><?= h($order['branch']) ?></dd>
    <dt>Plant</dt><dd><?= h($order['plant_name']) ?> (<?= h($order['inventory_org']) ?>)</dd>
    <dt>Entered by</dt><dd><?= h($order['created_by_email']) ?></dd>
    <dt>Created</dt><dd><?= h($order['created_at']) ?></dd>
    <?php if (!empty($order['shipment_ref'])): ?><dt>Shipment Reference #</dt><dd><?= h($order['shipment_ref']) ?></dd><?php endif; ?>
    <?php if (!empty($order['requested_delivery_date'])): ?><dt>Requested delivery</dt><dd><?= h($order['requested_delivery_date']) ?></dd><?php endif; ?>
    <?php if ($order['notes']): ?><dt>Notes</dt><dd><?= h($order['notes']) ?></dd><?php endif; ?>
    <?php if (!empty($order['ship_to'])): ?><dt>Ship to</dt><dd style="white-space:pre-line;"><?= h($order['ship_to']) ?></dd><?php endif; ?>
    <?php if (!empty($order['ship_method'])): ?><dt>Ship method</dt><dd><?= h($order['ship_method']) ?></dd><?php endif; ?>
    <?php if (!empty($order['bill_to'])): ?><dt>Bill to</dt><dd style="white-space:pre-line;"><?= h($order['bill_to']) ?></dd><?php endif; ?>
  </dl>

  <div class="tablewrap"><table>
    <thead><tr><th>Item</th><th>Description</th><th>Qty</th><th>UOM</th><th>Unit</th><th>Ext</th></tr></thead>
    <tbody>
    <?php foreach ($data['lines'] as $l): ?>
      <tr>
        <td><?= h($l['item_number']) ?></td>
        <td><?= h($l['description']) ?></td>
        <td><?= h($l['quantity']) ?></td>
        <td><?= ($l['uom'] ?? '') !== '' ? h($l['uom']) : '<span class="muted">—</span>' ?></td>
        <td><?= $l['unit_price']!==null ? '$'.number_format($l['unit_price'],4) : '<span class="muted">—</span>' ?></td>
        <td><?= $l['unit_price']!==null ? '$'.number_format($l['unit_price']*$l['quantity'],2) : '<span class="muted">no price</span>' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot><tr><th colspan="5" class="right">Total</th><th>$<?= number_format($total,2) ?></th></tr></tfoot>
  </table></div>

  <p class="note"><a href="new-order.php">← Enter another order</a></p>
</main>
<footer>Thin MVP slice · order entry · PHP <?= PHP_VERSION ?></footer>
</body>
</html>
