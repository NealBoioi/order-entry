<?php
// Quoting Presets — per-assembly-plant quoting defaults (overhaul item 4a, §35/§36).
// Admin-only: same cost-data visibility rule as the rest of the quoting module (§8.2,
// §21) — labor rates and burden factors never reach customer accounts.
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/presets.php';
auth_boot();
$me = require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $org = trim($_POST['inventory_org'] ?? '');
    [$ok, $err] = save_quoting_preset($org, $_POST);
    $_SESSION['flash'] = $ok ? ['ok', "Quoting preset saved for $org."] : ['err', $err];
    redirect('quoting-presets.php');
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$plants = list_quoting_presets();

// Percent cell: blank preset -> empty input (not "0"), so an unsaved plant reads as blank.
$pctVal = function (?float $v): string {
    if ($v === null) return '';
    return rtrim(rtrim(number_format($v, 2, '.', ''), '0'), '.');
};
$rateVal = function ($v): string {
    if ($v === null) return '';
    return rtrim(rtrim(number_format((float) $v, 2, '.', ''), '0'), '.');
};
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quoting Presets — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('quoting-presets'); ?>
<main>
  <h1>Quoting Presets <span class="sub">per-plant labor rates &amp; burden factors that auto-fill new quote cost tiers</span></h1>

  <?php if ($flash): ?><div class="msg <?= h($flash[0]) ?>"><?= h($flash[1]) ?></div><?php endif; ?>

  <?php if (!$plants): ?>
    <p class="empty">No assembly plants found (orgs table is empty).</p>
  <?php endif; ?>

  <?php foreach ($plants as $p): $org = $p['inventory_org']; ?>
    <div class="card">
      <div class="card-head">
        <div class="itemno"><?= h($org) ?> <span class="desc" style="font-weight:400;"><?= h($p['name'] ?? '') ?></span></div>
        <?php if ($p['updated_at']): ?><span class="note">last saved <?= h(date('M j, Y g:ia', strtotime($p['updated_at']))) ?></span><?php endif; ?>
      </div>
      <form method="post" action="quoting-presets.php" class="submitform" style="margin-top:12px;box-shadow:none;padding:0;border:none;">
        <?= csrf_field() ?>
        <input type="hidden" name="inventory_org" value="<?= h($org) ?>">
        <div class="qgrid">
          <label>Engineering labor rate ($/hr)
            <input type="text" name="engineering_labor_rate" value="<?= h($rateVal($p['engineering_labor_rate'])) ?>" inputmode="decimal" placeholder="e.g. 85">
          </label>
          <label>Production labor rate ($/hr)
            <input type="text" name="production_labor_rate" value="<?= h($rateVal($p['production_labor_rate'])) ?>" inputmode="decimal" placeholder="e.g. 45">
          </label>
          <label>Plant burden — materials (%)
            <input type="text" name="plant_burden_materials" value="<?= h($pctVal($p['plant_burden_materials_pct'])) ?>" inputmode="decimal" placeholder="e.g. 15">
          </label>
          <label>Plant burden — labor (%)
            <input type="text" name="plant_burden_labor" value="<?= h($pctVal($p['plant_burden_labor_pct'])) ?>" inputmode="decimal" placeholder="e.g. 20">
          </label>
        </div>
        <button type="submit" class="btn-sm primary" style="margin-top:8px;">Save <?= h($org) ?></button>
      </form>
    </div>
  <?php endforeach; ?>

  <p class="note">Burden is entered here as a percent (e.g. 15 = 15%); it's stored as a
    fraction internally — the same convention the quote Cost roll-up uses for burden/margin
    (§21). Leaving a field blank saves it as 0. A plant with no preset saved yet shows blank
    fields; saving creates its row.</p>
</main>
<footer>Order Entry · Quoting Presets · PHP <?= PHP_VERSION ?></footer>
</body>
</html>
