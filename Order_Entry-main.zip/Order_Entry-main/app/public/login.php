<?php
require __DIR__ . '/../src/auth.php';
auth_boot();

if (current_user()) redirect('index.php');   // already signed in

$err = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    [$allowed, $retry] = rate_limit_hit('login', client_ip(), 10, 600);   // 10 / 10 min per IP
    if (!$allowed) {
        $err = 'Too many sign-in attempts. Please wait ' . (int) ceil($retry / 60) . ' minute(s) and try again.';
    } else {
        [$ok, $err] = attempt_login($_POST['email'] ?? '', $_POST['password'] ?? '');
        if ($ok) redirect('index.php');
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="authwrap">
  <div class="brandbig"><svg class="wmark" viewBox="217 219 943 441" xmlns="http://www.w3.org/2000/svg"><path fill="#00AA13" d="M938.2,652.9l221.1-415.8c4.1-7.8-1.5-17.2-10.3-17.2H934.2c-6.2,0-11.8,3.4-14.7,8.9L804.8,444.3l110.9,208.6c2.2,4.2,6.5,6.8,11.2,6.8h0C931.7,659.6,936,657,938.2,652.9z"/><path fill="#00AA13" d="M221.3,237.1l211.1,397.1l115.3-216.9L447.5,228.7c-2.9-5.4-8.6-8.9-14.7-8.9H231.6C222.8,219.9,217.2,229.3,221.3,237.1z"/><path fill="#00AA13" d="M446,659.6h234.3c6.2,0,11.8-3.4,14.7-8.9l109.8-206.5L693.9,235.7c-2.2-4.1-6.5-6.8-11.2-6.8l0,0c-4.7,0-9,2.6-11.2,6.8L446,659.6z"/></svg><span class="brand-text"><b>ASSEMBLIES</b><i>Order Entry</i></span></div>
  <div class="authcard">
    <h1>Sign in</h1>
    <p class="lead">Plant &amp; branch accounts.</p>
    <?php if ($err): ?><div class="msg err"><?= h($err) ?></div><?php endif; ?>
    <form method="post" action="login.php">
      <?= csrf_field() ?>
      <label for="email">Email</label>
      <input type="email" id="email" name="email" value="<?= h($_POST['email'] ?? '') ?>" autofocus required>
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>
      <button type="submit">Sign in</button>
    </form>
    <p class="alt"><a href="magic-login.php">Email me a sign-in link instead</a></p>
    <p class="alt"><a href="forgot-password.php">Forgot your password?</a></p>
    <p class="alt">No account yet? <a href="request-access.php">Request access</a></p>
  </div>
</div>
</body>
</html>
