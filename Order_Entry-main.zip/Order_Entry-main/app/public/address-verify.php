<?php
/**
 * Address verification (JSON).  GET/POST addr1, city, state, zip, country
 *   -> { "valid": bool, "normalized": string|null }
 * Client-side convenience so the user gets immediate feedback; the authoritative gate is
 * server-side in save_ship_address()/save_bill_address() (app/src/profile.php).
 */
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/geocode.php';
auth_boot();

header('Content-Type: application/json; charset=utf-8');

if (!current_user()) {
    http_response_code(401);
    echo json_encode(['error' => 'auth', 'valid' => false]);
    exit;
}

$g = fn(string $k) => trim((string) ($_POST[$k] ?? $_GET[$k] ?? ''));

[$ok, $normalized] = geocode_verify($g('addr1'), $g('city'), $g('state'), $g('zip'), $g('country'));

echo json_encode(['valid' => $ok, 'normalized' => $normalized], JSON_UNESCAPED_SLASHES);
