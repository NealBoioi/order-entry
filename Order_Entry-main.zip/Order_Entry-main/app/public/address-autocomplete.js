/* Address form enhancements — no dependencies. Works for plain fields (addr1, city, …)
 * and prefixed ones (ship_addr1 / bill_addr1 …), so it covers the address book pages,
 * the admin edit-user page, and the multi-address account-setup page.
 *
 *  1. STREET AUTOCOMPLETE + AUTOFILL — typing in a street field suggests real addresses
 *     (address-suggest.php); picking one fills that field group's city/state/zip/country.
 *  2. COUNTRY + DEPENDENT STATE DROPDOWNS — the country/state text inputs become <select>s;
 *     state options depend on the chosen country. (Progressive enhancement — degrade to inputs.)
 *  3. VERIFY-BEFORE-SUBMIT — a form won't submit until every entered street address resolves
 *     to a REAL address (address-verify.php). Picked suggestions are pre-trusted. The
 *     authoritative gate is still server-side; this is immediate feedback that preserves input.
 */
(function () {
  'use strict';
  var SUGGEST = 'address-suggest.php', VERIFY = 'address-verify.php';
  var MIN_CHARS = 4, DEBOUNCE = 260;

  var COUNTRIES = [
    { code: 'USA', name: 'United States' },
    { code: 'Canada', name: 'Canada' },
    { code: 'Mexico', name: 'Mexico' }
  ];
  var SUBDIV = {
    USA: [['AL','Alabama'],['AK','Alaska'],['AZ','Arizona'],['AR','Arkansas'],['CA','California'],
      ['CO','Colorado'],['CT','Connecticut'],['DE','Delaware'],['DC','District of Columbia'],
      ['FL','Florida'],['GA','Georgia'],['HI','Hawaii'],['ID','Idaho'],['IL','Illinois'],
      ['IN','Indiana'],['IA','Iowa'],['KS','Kansas'],['KY','Kentucky'],['LA','Louisiana'],
      ['ME','Maine'],['MD','Maryland'],['MA','Massachusetts'],['MI','Michigan'],['MN','Minnesota'],
      ['MS','Mississippi'],['MO','Missouri'],['MT','Montana'],['NE','Nebraska'],['NV','Nevada'],
      ['NH','New Hampshire'],['NJ','New Jersey'],['NM','New Mexico'],['NY','New York'],
      ['NC','North Carolina'],['ND','North Dakota'],['OH','Ohio'],['OK','Oklahoma'],['OR','Oregon'],
      ['PA','Pennsylvania'],['RI','Rhode Island'],['SC','South Carolina'],['SD','South Dakota'],
      ['TN','Tennessee'],['TX','Texas'],['UT','Utah'],['VT','Vermont'],['VA','Virginia'],
      ['WA','Washington'],['WV','West Virginia'],['WI','Wisconsin'],['WY','Wyoming'],
      ['PR','Puerto Rico'],['GU','Guam'],['VI','U.S. Virgin Islands'],['AS','American Samoa'],
      ['MP','Northern Mariana Islands']],
    Canada: [['AB','Alberta'],['BC','British Columbia'],['MB','Manitoba'],['NB','New Brunswick'],
      ['NL','Newfoundland and Labrador'],['NS','Nova Scotia'],['NT','Northwest Territories'],
      ['NU','Nunavut'],['ON','Ontario'],['PE','Prince Edward Island'],['QC','Quebec'],
      ['SK','Saskatchewan'],['YT','Yukon']],
    Mexico: [['AGU','Aguascalientes'],['BCN','Baja California'],['BCS','Baja California Sur'],
      ['CAM','Campeche'],['CHP','Chiapas'],['CHH','Chihuahua'],['CMX','Ciudad de México'],
      ['COA','Coahuila'],['COL','Colima'],['DUR','Durango'],['GUA','Guanajuato'],['GRO','Guerrero'],
      ['HID','Hidalgo'],['JAL','Jalisco'],['MEX','México'],['MIC','Michoacán'],['MOR','Morelos'],
      ['NAY','Nayarit'],['NLE','Nuevo León'],['OAX','Oaxaca'],['PUE','Puebla'],['QUE','Querétaro'],
      ['ROO','Quintana Roo'],['SLP','San Luis Potosí'],['SIN','Sinaloa'],['SON','Sonora'],
      ['TAB','Tabasco'],['TAM','Tamaulipas'],['TLA','Tlaxcala'],['VER','Veracruz'],
      ['YUC','Yucatán'],['ZAC','Zacatecas']]
  };
  var CC_TO_COUNTRY = { US: 'USA', CA: 'Canada', MX: 'Mexico' };

  var fields = [];   // { input, prefix, form, verified } for each street field

  ready(function () {
    var c = document.querySelectorAll('[name="country"], [name$="_country"]');
    for (var i = 0; i < c.length; i++) enhanceCountryState(c[i]);
    var a = document.querySelectorAll('input[name="addr1"], input[name$="_addr1"]');
    for (var j = 0; j < a.length; j++) attachAutocomplete(a[j]);
    var forms = [];
    fields.forEach(function (f) { if (forms.indexOf(f.form) < 0) forms.push(f.form); });
    forms.forEach(addSubmitGate);
  });

  function ready(fn) {
    if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn);
  }
  function prefixOf(name, suffix) { return name.slice(0, name.length - suffix.length); }

  /* ------------------------------------------- country + dependent state selects */

  function enhanceCountryState(countryEl) {
    var form = countryEl.form || document;
    var prefix = prefixOf(countryEl.name, 'country');
    var stateEl = form.querySelector('[name="' + prefix + 'state"]');

    var countrySel = countryEl.tagName === 'INPUT' ? toSelect(countryEl) : countryEl;
    var stateSel = (stateEl && stateEl.tagName === 'INPUT') ? toSelect(stateEl) : stateEl;

    fillCountry(countrySel, countrySel.getAttribute('data-val'));
    if (stateSel) {
      fillState(stateSel, countrySel.value, stateSel.getAttribute('data-val'));
      countrySel.addEventListener('change', function () { fillState(stateSel, countrySel.value, ''); });
    }
  }

  function toSelect(input) {
    var sel = document.createElement('select');
    sel.name = input.name;
    if (input.className) sel.className = input.className;
    if (input.required) sel.required = true;
    if (input.id) sel.id = input.id;
    sel.setAttribute('data-val', input.value || '');
    input.parentNode.replaceChild(sel, input);
    return sel;
  }
  function fillCountry(sel, current) {
    sel.innerHTML = '';
    COUNTRIES.forEach(function (c) { addOpt(sel, c.code, c.name); });
    if (!selectMatch(sel, current)) { if (current) { addOpt(sel, current, current); selectMatch(sel, current); } else selectMatch(sel, 'USA'); }
  }
  function fillState(sel, countryCode, current) {
    if (current === undefined || current === null) current = sel.value;
    sel.innerHTML = '';
    addOpt(sel, '', '— Select —');
    (SUBDIV[countryCode] || []).forEach(function (s) { addOpt(sel, s[0], s[1]); });
    if (!selectMatch(sel, current) && current) { addOpt(sel, current, current); selectMatch(sel, current); }
  }
  function addOpt(sel, value, text) { var o = document.createElement('option'); o.value = value; o.textContent = text; sel.appendChild(o); }
  function selectMatch(sel, wanted) {
    if (wanted === undefined || wanted === null || wanted === '') return false;
    var w = String(wanted).trim().toLowerCase();
    for (var i = 0; i < sel.options.length; i++) {
      if (sel.options[i].value.toLowerCase() === w || sel.options[i].textContent.trim().toLowerCase() === w) { sel.selectedIndex = i; return true; }
    }
    return false;
  }

  /* -------------------------------------------------- street autocomplete + fill */

  function attachAutocomplete(input) {
    var form = input.closest('form') || document;
    var prefix = prefixOf(input.name, 'addr1');
    var self = { input: input, prefix: prefix, form: form, verified: '' };
    fields.push(self);

    var label = input.parentElement;
    label.classList.add('addr-field');
    input.setAttribute('autocomplete', 'off');
    input.setAttribute('aria-autocomplete', 'list');

    var box = document.createElement('div');
    box.className = 'addr-suggest'; box.setAttribute('role', 'listbox'); box.hidden = true;
    label.appendChild(box);

    var items = [], active = -1, timer = null, reqId = 0;

    input.addEventListener('input', function () {
      clearFieldError(self);
      var q = input.value.trim();
      clearTimeout(timer);
      if (q.length < MIN_CHARS) { closeBox(); return; }
      timer = setTimeout(function () { runQuery(q); }, DEBOUNCE);
    });
    input.addEventListener('keydown', onKeydown);
    input.addEventListener('blur', function () { setTimeout(closeBox, 150); });
    document.addEventListener('click', function (e) { if (!label.contains(e.target)) closeBox(); });

    function runQuery(q) {
      var myId = ++reqId;
      showMessage('Searching addresses…');
      fetch(SUGGEST + '?q=' + encodeURIComponent(q), { headers: { Accept: 'application/json' } })
        .then(function (r) { return r.ok ? r.json() : { suggestions: [] }; })
        .then(function (data) {
          if (myId !== reqId || input.value.trim() !== q) return;
          items = (data && data.suggestions) ? data.suggestions.slice(0, 6) : [];
          if (items.length) renderItems(); else showMessage('No match — keep typing, or pick from the list once it appears');
        })
        .catch(function () { closeBox(); });
    }
    function renderItems() {
      box.innerHTML = ''; active = -1;
      items.forEach(function (s, idx) {
        var el = document.createElement('div');
        el.className = 'as-item'; el.setAttribute('role', 'option');
        var street = document.createElement('span'); street.className = 'as-street'; street.textContent = s.addr1 || '';
        var rest = document.createElement('span'); rest.className = 'as-rest';
        rest.textContent = [s.city, s.state, s.zip].filter(Boolean).join(', ');
        el.appendChild(street); el.appendChild(rest);
        el.addEventListener('mousedown', function (ev) { ev.preventDefault(); choose(s); });
        el.addEventListener('mouseenter', function () { setActive(idx); });
        box.appendChild(el);
      });
      box.hidden = false;
    }
    function showMessage(text) {
      box.innerHTML = ''; active = -1;
      var el = document.createElement('div'); el.className = 'as-item as-msg'; el.textContent = text;
      box.appendChild(el); box.hidden = false;
    }
    function setActive(idx) {
      var nodes = box.querySelectorAll('.as-item[role="option"]');
      for (var i = 0; i < nodes.length; i++) nodes[i].classList.toggle('active', i === idx);
      active = idx;
    }
    function onKeydown(e) {
      if (box.hidden || !items.length) return;
      if (e.key === 'ArrowDown') { e.preventDefault(); setActive((active + 1) % items.length); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((active - 1 + items.length) % items.length); }
      else if (e.key === 'Enter') { if (active >= 0) { e.preventDefault(); choose(items[active]); } }
      else if (e.key === 'Escape') { closeBox(); }
    }
    function choose(s) {
      if (s.addr1) input.value = s.addr1;
      setText(prefix + 'city', s.city);
      setText(prefix + 'zip', s.zip);
      var cSel = form.querySelector('select[name="' + prefix + 'country"]');
      if (cSel) {
        var wc = CC_TO_COUNTRY[s.countrycode] || s.country;
        if (selectMatch(cSel, wc) || selectMatch(cSel, s.country)) cSel.dispatchEvent(new Event('change', { bubbles: true }));
      }
      var stSel = form.querySelector('select[name="' + prefix + 'state"]');
      if (stSel && s.state) { if (!selectMatch(stSel, s.state)) { addOpt(stSel, s.state, s.state); selectMatch(stSel, s.state); } }
      clearFieldError(self);
      self.verified = compose(self);   // picked from the geocoder → trusted, no re-check on submit
      closeBox();
      var next = form.querySelector('[name="' + prefix + 'addr2"]');
      if (next) next.focus();
    }
    function setText(name, val) {
      if (val === undefined || val === null || val === '') return;
      var f = form.querySelector('input[name="' + name + '"]');
      if (f) { f.value = val; f.dispatchEvent(new Event('input', { bubbles: true })); }
    }
    function closeBox() { box.hidden = true; active = -1; }
  }

  /* -------------------------------------------------- verify-before-submit gate */

  function compose(f) {
    function v(name) { var el = f.form.querySelector('[name="' + name + '"]'); return el ? el.value.trim() : ''; }
    return [v(f.prefix + 'addr1'), v(f.prefix + 'city'), v(f.prefix + 'state'), v(f.prefix + 'zip'), v(f.prefix + 'country')]
      .join('|').toLowerCase();
  }

  function addSubmitGate(form) {
    form.addEventListener('submit', function (e) {
      if (form.__addrOK) { form.__addrOK = false; return; }        // our own re-submit
      var mine = fields.filter(function (f) { return f.form === form && f.input.value.trim() !== ''; });
      var toCheck = mine.filter(function (f) { return compose(f) !== f.verified; });
      if (!toCheck.length) return;                                  // nothing new to verify

      e.preventDefault();
      setBusy(form, true);
      Promise.all(toCheck.map(verifyField)).then(function (results) {
        setBusy(form, false);
        var bad = results.filter(function (r) { return !r.ok; });
        if (bad.length) { bad.forEach(function (r) { showFieldError(r.field); }); bad[0].field.input.focus(); }
        else { toCheck.forEach(function (f) { f.verified = compose(f); }); form.__addrOK = true; form.requestSubmit ? form.requestSubmit() : form.submit(); }
      }).catch(function () {                                        // verifier unreachable → let the server backstop
        setBusy(form, false); form.__addrOK = true; form.requestSubmit ? form.requestSubmit() : form.submit();
      });
    });
  }

  function verifyField(f) {
    function v(name) { var el = f.form.querySelector('[name="' + name + '"]'); return el ? el.value.trim() : ''; }
    var qs = 'addr1=' + encodeURIComponent(v(f.prefix + 'addr1')) +
             '&city=' + encodeURIComponent(v(f.prefix + 'city')) +
             '&state=' + encodeURIComponent(v(f.prefix + 'state')) +
             '&zip=' + encodeURIComponent(v(f.prefix + 'zip')) +
             '&country=' + encodeURIComponent(v(f.prefix + 'country'));
    return fetch(VERIFY + '?' + qs, { headers: { Accept: 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (d) { return { field: f, ok: !!(d && d.valid) }; });
  }

  function showFieldError(f) {
    var label = f.input.parentElement;
    var err = label.querySelector('.addr-error');
    if (!err) { err = document.createElement('div'); err.className = 'addr-error'; label.appendChild(err); }
    err.textContent = 'Enter a real, verified street address — pick one from the suggestions as you type.';
  }
  function clearFieldError(f) {
    var err = f.input.parentElement.querySelector('.addr-error');
    if (err) err.remove();
  }

  function setBusy(form, busy) {
    var btns = form.querySelectorAll('button[type="submit"], .saverow button, .btn-save, .submitbtn');
    for (var i = 0; i < btns.length; i++) {
      var b = btns[i];
      if (busy) {
        if (!b.hasAttribute('data-label')) b.setAttribute('data-label', b.textContent);
        b.disabled = true; b.textContent = 'Verifying address…';
      } else if (b.hasAttribute('data-label')) {
        b.disabled = false; b.textContent = b.getAttribute('data-label'); b.removeAttribute('data-label');
      }
    }
  }
})();
