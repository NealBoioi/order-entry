<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/quotes.php';
require __DIR__ . '/../src/contacts.php';   // list_customers() — canonical customer dropdown
auth_boot();
$me = require_admin();          // quoting is plant-side; cost/margin never shown to customers

$id = (int) ($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $id     = (int) ($_POST['id'] ?? $id);
    if (!get_quote($id)) { http_response_code(404); exit('404 — quote not found.'); }

    switch ($action) {
        case 'save_all':
            // ONE save for the whole workspace: header + every BOM line/price-break + labor
            // lines + Quote Summary margins. Anything that changed is applied atomically and
            // logged as a new revision.
            [$ok, $err, $n, $warnings] = save_quote_all($id, $_POST, $me['email']);
            if (!$ok) {
                $_SESSION['flash'] = ['err', $err];
            } elseif ($n === 0) {
                $_SESSION['flash'] = ['info', 'No changes to save.'];
            } else {
                $msg = "Saved — $n change" . ($n === 1 ? '' : 's') . ' logged as revision ' .
                       'in the project pack.';
                if ($warnings) $msg .= ' ' . implode(' ', $warnings);
                $_SESSION['flash'] = [$warnings ? 'info' : 'ok', $msg];
            }
            break;
        case 'delete_rev':
            delete_revision((int) ($_POST['rev_id'] ?? 0));
            $_SESSION['flash'] = ['info', 'Revision removed.'];
            break;
    }
    redirect('quote.php?id=' . $id . '#' . ($_POST['anchor'] ?? ''));
}

$quote = get_quote($id);
if (!$quote) { http_response_code(404); exit('404 — quote not found.'); }

$flash  = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$lines  = list_bom_lines($id);
$tiers  = list_cost_tiers($id);
$revs   = list_revisions($id);
$matPer = quote_material_per_unit($id);

$breaksByLine = [];
foreach ($lines as $l) $breaksByLine[(int) $l['id']] = list_bom_price_breaks((int) $l['id']);

$buildQtys    = list_cost_tier_build_qtys($id);
$summaryTiers = list_summary_tiers($id);   // keyed by build_qty

// Plant/customer options for the new header block.
$orgs      = db()->query('SELECT inventory_org, name, plant_code FROM orgs ORDER BY name')->fetchAll();
$customers = list_customers();

// Client-side data: Program Manager index (customer|org -> pm), labor rates + burdens per
// plant — powers the auto-fill / live Quote Summary math without extra round-trips.
$pmIndexJs = [];
foreach (pm_lookup_index() as $k => $pm) $pmIndexJs[$k] = $pm;
$rateMap = []; $burdenMap = [];
foreach (list_quoting_presets() as $p) {
    $rateMap[$p['inventory_org']] = [
        'Production'  => $p['production_labor_rate']  !== null ? (float) $p['production_labor_rate']  : null,
        'Engineering' => $p['engineering_labor_rate']  !== null ? (float) $p['engineering_labor_rate'] : null,
    ];
    $burdenMap[$p['inventory_org']] = [
        'materials' => $p['plant_burden_materials'] !== null ? (float) $p['plant_burden_materials'] : 0,
        'labor'     => $p['plant_burden_labor']      !== null ? (float) $p['plant_burden_labor']     : 0,
    ];
}

// Field-render helpers.
$v = fn($k) => h($quote[$k] ?? '');
$num = fn($x, $dec = 5) => $x === null ? '' : rtrim(rtrim(number_format((float) $x, $dec, '.', ''), '0'), '.');
$title = $quote['quote_number'] ?: ($quote['quote_id'] ?: ($quote['part_number'] ?: ('Quote #' . $id)));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quote <?= h($title) ?> — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('quotes'); ?>
<main>
  <p class="note"><a href="quotes.php">← All quotes</a></p>
  <h1>Quote: <?= h($title) ?>
    <span class="statuspill <?= h(strtolower($quote['status'])) ?>"><?= h($quote['status']) ?></span>
    <span class="sub"><?= h($quote['customer']) ?><?= $quote['customer'] && $quote['part_number'] ? ' · ' : '' ?><?= h($quote['part_number']) ?></span>
  </h1>

  <?php if ($flash): ?><div class="msg <?= h($flash[0]) ?>"><?= h($flash[1]) ?></div><?php endif; ?>

  <!-- ONE form for the whole workspace — the Save bar at the bottom applies everything
       at once and auto-logs a revision listing every change. -->
  <form method="post" action="quote.php" id="qform">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save_all">
    <input type="hidden" name="id" value="<?= $id ?>">
    <input type="hidden" name="anchor" value="">

    <!-- ══ Quote header — Customer / Assembly Plant / Part Number / Quote Number ══════ -->
    <div class="qsection" id="qheader">
      <h2 class="h2">Quote <span class="subnote">Rev <?= h($quote['revision'] ?: '—') ?> · updated <?= h($quote['updated_at']) ?></span></h2>
      <div class="qgrid">
        <label>Customer
          <select name="customer" id="f_customer">
            <option value="">— Select customer —</option>
            <?php foreach ($customers as $c): ?>
              <option value="<?= h($c) ?>" <?= $quote['customer'] === $c ? 'selected' : '' ?>><?= h($c) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>Assembly Plant
          <select name="inventory_org" id="f_plant">
            <option value="">—</option>
            <?php foreach ($orgs as $o): ?>
              <option value="<?= h($o['inventory_org']) ?>" <?= $quote['inventory_org'] === $o['inventory_org'] ? 'selected' : '' ?>>
                <?= h($o['name']) ?> (<?= h($o['inventory_org']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>Part Number<input type="text" name="part_number" id="f_partnum" value="<?= $v('part_number') ?>"></label>
        <label>Quote Number
          <input type="text" value="<?= h($quote['quote_number'] ?: 'assigned on first save') ?>" disabled class="readonly">
        </label>
      </div>
    </div>

    <!-- ══ Bid Prep / Pre-Bid Proposal ════════════════════════════════════ -->
    <div class="qsection" id="bidprep">
      <h2 class="h2">Pre-Bid Proposal <span class="subnote">the "must-have" information for this quote</span></h2>

      <div class="grouplabel">Must-have information</div>
      <div class="qgrid">
        <label>Quote ID #<input type="text" name="quote_id" value="<?= $v('quote_id') ?>"></label>
        <label>Kit SIM #<input type="text" name="kit_sim" value="<?= $v('kit_sim') ?>"></label>
        <label>Revision<input type="text" name="revision" value="<?= $v('revision') ?>"></label>
        <label class="wide">Description<input type="text" name="description" value="<?= $v('description') ?>"></label>
        <label>Branch<input type="text" name="branch" value="<?= $v('branch') ?>" maxlength="4" inputmode="numeric" placeholder="4-digit"></label>
        <label>Status
          <select name="status">
            <?php foreach (QUOTE_STATUSES as $s): ?>
              <option value="<?= h($s) ?>" <?= $quote['status'] === $s ? 'selected' : '' ?>><?= h($s) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>Outside Sales Person<input type="text" name="outside_sales" value="<?= $v('outside_sales') ?>"></label>
        <label>Inside Sales Person<input type="text" name="inside_sales" value="<?= $v('inside_sales') ?>"></label>
        <label>Business Development Mgr<input type="text" name="bdm" value="<?= $v('bdm') ?>"></label>
        <label>Program Manager <span class="subnote">auto-fills from Customer + Plant</span>
          <input type="text" name="program_manager" id="f_pm" value="<?= $v('program_manager') ?>">
        </label>
        <label>EAU (est. annual usage)<input type="text" name="eau" value="<?= $v('eau') ?>" inputmode="numeric"></label>
        <label>Release Quantities<input type="text" name="release_qty" value="<?= $v('release_qty') ?>" inputmode="numeric"></label>
        <label>NCNR / Mfg. Contract Signed<input type="text" name="ncnr_signed" value="<?= $v('ncnr_signed') ?>"></label>
        <label>Quote Requested Date<input type="date" name="quote_requested_date" value="<?= $v('quote_requested_date') ?>"></label>
        <label>First Build Requested Date<input type="date" name="first_build_date" value="<?= $v('first_build_date') ?>"></label>
        <label>Production Requested Date<input type="date" name="production_date" value="<?= $v('production_date') ?>"></label>
        <label>Pre-Bid Meeting Date<input type="date" name="pre_bid_meeting_date" value="<?= $v('pre_bid_meeting_date') ?>"></label>
        <label>Customer Drawings?<input type="text" name="customer_drawings" value="<?= $v('customer_drawings') ?>"></label>
        <label>Customer BOM w/ mfr part #s<input type="text" name="customer_bom" value="<?= $v('customer_bom') ?>"></label>
        <label>Crossed Material approved?<input type="text" name="crossed_material" value="<?= $v('crossed_material') ?>"></label>
        <label>Engineering Required?<input type="text" name="engineering_required" value="<?= $v('engineering_required') ?>"></label>
      </div>

      <div class="grouplabel">Additional information</div>
      <div class="qgrid">
        <label class="wide">Certifications needed (CSA, CE, ATEX, IECEx, etc.)<input type="text" name="certifications" value="<?= $v('certifications') ?>"></label>
        <label class="wide">Testing details (if required)<input type="text" name="testing_details" value="<?= $v('testing_details') ?>"></label>
        <label class="wide">Customer-specified packaging requirements<input type="text" name="packaging_reqs" value="<?= $v('packaging_reqs') ?>"></label>
        <label class="wide">Customer Quality requirements
          <textarea name="customer_quality_reqs" placeholder="FAI, Certificate of Conformity (C of C), PPAP, Physical sample, …"><?= $v('customer_quality_reqs') ?></textarea>
        </label>
        <label>Target pricing?<input type="text" name="target_pricing" value="<?= $v('target_pricing') ?>"></label>
        <label>NDA Signed?<input type="text" name="nda_signed" value="<?= $v('nda_signed') ?>"></label>
        <label>CBC Part #<input type="text" name="cbc_part" value="<?= $v('cbc_part') ?>"></label>
        <label>Customer Web Address<input type="text" name="customer_web" value="<?= $v('customer_web') ?>"></label>
        <label>Customer Current Sales $ to CBC<input type="text" name="current_sales" value="<?= $v('current_sales') ?>"></label>
        <label>Global Account (Yes/No)<input type="text" name="global_account" value="<?= $v('global_account') ?>"></label>
        <label>Currently AS Customer (Yes/No)<input type="text" name="as_customer" value="<?= $v('as_customer') ?>"></label>
        <label class="wide">Additional notes<textarea name="additional_notes"><?= $v('additional_notes') ?></textarea></label>
      </div>
    </div>

    <!-- ══ Costed BOM — every field always visible; price breaks fully visible under a line ══ -->
    <div class="qsection" id="bom">
      <h2 class="h2">Costed BOM <span class="subnote">type an MFG Item or Description to search the item warehouse; everything saves together at the bottom</span></h2>

      <div class="tablewrap"><table class="bomtable bomedit bomwide">
        <thead><tr>
          <th>Lvl</th><th>Type</th><th>Customer P/N</th><th>MFG item</th><th>Description</th><th>UOM</th>
          <th class="num">Qty/unit</th><th class="num">MOQ</th><th class="num">FLM</th><th class="num">Lead (wk)</th>
          <th>Manufacturer</th><th>Supplier</th><th>Supplier Item</th><th>Quote number</th><th>Crossed Items</th>
          <th>Notes</th><th class="num">Std cost</th><th class="num">Ext cost</th><th></th>
        </tr></thead>
        <tbody id="bom-body">
        <?php foreach ($lines as $l):
          $lid = (int) $l['id'];
          $ln  = fn($f) => 'line[' . $lid . '][' . $f . ']';
          $lv  = fn($f) => h($l[$f] ?? '');
          $breaks = $breaksByLine[$lid] ?? [];
          $typeNorm = bom_line_type_normalize($l['line_type']);
          $isSub = ($typeNorm === 'Sub-assembly');
          $hasBreaks = (bool) $breaks;
          $ext = ($l['standard_cost'] !== null) ? (float) $l['standard_cost'] * (float) $l['qty_per'] : null; ?>
          <tr class="bomrow<?= $isSub ? ' subassembly' : '' ?>" data-line-key="<?= $lid ?>">
            <td class="w-xs"><input type="text" name="<?= $ln('level') ?>" value="<?= $lv('level') ?>" inputmode="numeric"></td>
            <td class="w-sm f-type-cell"><select name="<?= $ln('line_type') ?>" class="f-type">
                <?php foreach (BOM_LINE_TYPES as $t): ?>
                  <option value="<?= h($t) ?>" <?= $typeNorm === $t ? 'selected' : '' ?>><?= h($t) ?></option>
                <?php endforeach; ?>
              </select></td>
            <td class="w-md"><input type="text" name="<?= $ln('customer_pn') ?>" value="<?= $lv('customer_pn') ?>" class="f-custpn"></td>
            <td class="w-md addr-field"><input type="text" name="<?= $ln('mfg_item') ?>" value="<?= $lv('mfg_item') ?>" class="f-mfgitem suggest-src" autocomplete="off"></td>
            <td class="w-lg addr-field"><input type="text" name="<?= $ln('description') ?>" value="<?= $lv('description') ?>" class="f-desc suggest-src" autocomplete="off"></td>
            <td class="w-xs"><input type="text" name="<?= $ln('uom') ?>" value="<?= $lv('uom') ?>" class="f-uom"></td>
            <td class="w-sm"><input type="text" name="<?= $ln('qty_per') ?>" value="<?= h($num($l['qty_per'])) ?>" inputmode="decimal" class="f-qtyper"></td>
            <td class="w-sm"><input type="text" name="<?= $ln('moq') ?>" value="<?= $lv('moq') ?>" inputmode="numeric" class="f-moq lockable" <?= $isSub ? 'disabled' : '' ?>></td>
            <td class="w-xs"><input type="text" name="<?= $ln('flm') ?>" value="<?= $lv('flm') ?>" inputmode="numeric" class="lockable" <?= $isSub ? 'disabled' : '' ?>></td>
            <td class="w-xs"><input type="text" name="<?= $ln('lead_time_weeks') ?>" value="<?= $lv('lead_time_weeks') ?>" inputmode="numeric"></td>
            <td class="w-md"><input type="text" name="<?= $ln('manufacturer') ?>" value="<?= $lv('manufacturer') ?>" class="lockable" <?= $isSub ? 'disabled' : '' ?>></td>
            <td class="w-md"><input type="text" name="<?= $ln('project_supplier') ?>" value="<?= $lv('project_supplier') ?>" class="f-supplier lockable" <?= $isSub ? 'disabled' : '' ?>></td>
            <td class="w-md"><input type="text" name="<?= $ln('sim_supplier_item') ?>" value="<?= $lv('sim_supplier_item') ?>" class="f-supplieritem lockable" <?= $isSub ? 'disabled' : '' ?>></td>
            <td class="w-sm"><input type="text" name="<?= $ln('quote_number') ?>" value="<?= $lv('quote_number') ?>" class="lockable" <?= $isSub ? 'disabled' : '' ?>></td>
            <td class="w-sm"><input type="text" name="<?= $ln('crossed_items') ?>" value="<?= $lv('crossed_items') ?>" class="lockable" <?= $isSub ? 'disabled' : '' ?>></td>
            <td class="w-lg"><input type="text" name="<?= $ln('notes') ?>" value="<?= $lv('notes') ?>"></td>
            <td class="w-sm"><input type="text" name="<?= $ln('standard_cost') ?>" value="<?= $l['standard_cost'] !== null ? h($num($l['standard_cost'], 4)) : '' ?>" inputmode="decimal" class="f-stdcost lockable" <?= ($isSub || $hasBreaks) ? 'disabled' : '' ?>></td>
            <td class="num computed f-extcost"><?= $ext !== null ? '$' . number_format($ext, 2) : '—' ?></td>
            <td class="right nowrap">
              <label class="removebox" title="Remove this line on Save">
                <input type="checkbox" name="line_delete[<?= $lid ?>]" value="1">✕
              </label>
            </td>
          </tr>
          <tr class="breakrow" data-break-new-prefix="break_new[<?= $lid ?>]" data-break-n="0">
            <td colspan="19">
              <div class="breakwrap">
                <span class="breaklabel">Price breaks<?= $isSub ? ' (n/a for a sub-assembly)' : '' ?></span>
                <table class="breaktable"><thead><tr><th>Min qty</th><th>Unit price</th><th></th></tr></thead>
                  <tbody class="breaklist">
                  <?php foreach ($breaks as $b): $bid = (int) $b['id']; ?>
                    <tr>
                      <td><input type="text" name="break[<?= $lid ?>][<?= $bid ?>][min_qty]" value="<?= (int) $b['min_qty'] ?>" inputmode="numeric" class="f-brk-min"></td>
                      <td><input type="text" name="break[<?= $lid ?>][<?= $bid ?>][unit_price]" value="<?= h($num($b['unit_price'], 4)) ?>" inputmode="decimal" class="f-brk-price"></td>
                      <td><label class="removebox" title="Remove this price break on Save"><input type="checkbox" name="break_delete[<?= $lid ?>][<?= $bid ?>]" value="1">✕</label></td>
                    </tr>
                  <?php endforeach; ?>
                  </tbody>
                </table>
                <button type="button" class="btn-sm add-break">+ Price break</button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot><tr>
          <th colspan="16" class="right">Unburdened material cost / unit</th>
          <th class="num computed" id="bom-mat-total">$<?= number_format($matPer, 2) ?></th>
          <th></th>
        </tr></tfoot>
      </table></div>
      <div class="addlinebar"><button type="button" class="btn-sm primary" id="add-bom-row">+ New Line</button></div>
    </div>

    <!-- ══ Labor Breakdown ═════════════════════════════════════════════════ -->
    <div class="qsection" id="labor">
      <h2 class="h2">Labor Breakdown <span class="subnote">rate auto-fills from Labor Type + Assembly Plant; build qtys here drive the Quote Summary tiers below</span></h2>

      <div class="tablewrap"><table class="bomedit">
        <thead><tr>
          <th>Labor Type</th><th class="num">Build qty</th><th class="num">Labor rate</th><th class="num">Hours</th><th></th>
        </tr></thead>
        <tbody id="labor-body">
        <?php foreach ($tiers as $t): $tid = (int) $t['id'];
          $tn = fn($f) => 'tier[' . $tid . '][' . $f . ']'; ?>
          <tr class="tierrow" data-tier-key="<?= $tid ?>">
            <td class="w-md"><select name="<?= $tn('labor_type') ?>" class="f-labortype">
                <option value="Production"  <?= $t['labor_type'] === 'Production'  ? 'selected' : '' ?>>Production</option>
                <option value="Engineering" <?= $t['labor_type'] === 'Engineering' ? 'selected' : '' ?>>Engineering</option>
              </select></td>
            <td class="w-sm"><input type="text" name="<?= $tn('build_qty') ?>" value="<?= (int) $t['build_qty'] ?>" inputmode="numeric" class="f-buildqty"></td>
            <td class="w-sm"><input type="text" name="<?= $tn('labor_rate') ?>" value="<?= h($num($t['labor_rate'], 2)) ?>" inputmode="decimal" class="f-laborrate"></td>
            <td class="w-sm"><input type="text" name="<?= $tn('labor_hours') ?>" value="<?= h($num($t['labor_hours'], 4)) ?>" inputmode="decimal" class="f-laborhours"></td>
            <td class="right">
              <label class="removebox" title="Remove this line on Save">
                <input type="checkbox" name="tier_delete[<?= $tid ?>]" value="1">✕
              </label>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <div class="addlinebar"><button type="button" class="btn-sm primary" id="add-tier-row">+ New Line</button></div>
    </div>

    <!-- ══ Quote Summary ═══════════════════════════════════════════════════ -->
    <div class="qsection" id="summary">
      <h2 class="h2">Quote Summary <span class="subnote">Transfer = material/(1−plant burden mat'l) + labor/(1−plant burden labor) · Sale = Transfer/(1−margin)</span></h2>

      <?php if (!$buildQtys): ?>
        <p class="empty">Add Labor Breakdown rows above — each distinct Build qty becomes a Quote Summary tier.</p>
      <?php endif; ?>
      <div class="tablewrap" id="summary-wrap" <?= $buildQtys ? '' : 'hidden' ?>>
      <table class="bomedit summarytable">
        <thead><tr>
          <th class="num">Build qty</th><th class="num">Component cost</th><th class="num">Labor cost</th>
          <th>Burden (mat'l / labor)</th><th class="num">Margin %</th>
          <th class="num">Transfer Price</th><th class="num resalecol">Sale Price</th>
        </tr></thead>
        <tbody id="summary-body">
        <?php foreach ($buildQtys as $bq):
          $srow = $summaryTiers[$bq] ?? null;
          $marginPct = ($srow && $srow['margin'] !== null) ? rtrim(rtrim(number_format((float) $srow['margin'] * 100, 2), '0'), '.') : '';
          $bMat = $srow ? number_format((float) $srow['burden_materials'] * 100, 1) : number_format(($burdenMap[$quote['inventory_org']]['materials'] ?? 0) * 100, 1);
          $bLab = $srow ? number_format((float) $srow['burden_labor']     * 100, 1) : number_format(($burdenMap[$quote['inventory_org']]['labor']     ?? 0) * 100, 1);
        ?>
          <tr data-summary-qty="<?= $bq ?>">
            <td class="num"><?= $bq ?></td>
            <td class="num computed f-sum-component">$<?= number_format($srow ? (float) $srow['component_cost'] : $matPer, 2) ?></td>
            <td class="num computed f-sum-labor">$<?= number_format($srow ? (float) $srow['labor_cost'] : 0, 2) ?></td>
            <td class="f-sum-burden"><?= $bMat ?>% / <?= $bLab ?>%</td>
            <td class="w-sm"><input type="text" name="summary[<?= $bq ?>][margin]" value="<?= h($marginPct) ?>" inputmode="decimal" placeholder="25" class="f-margin"></td>
            <td class="num computed f-sum-transfer">$<?= number_format($srow ? (float) $srow['transfer_price'] : 0, 2) ?></td>
            <td class="num computed resalecol f-sum-sale">$<?= number_format($srow ? (float) $srow['sale_price'] : 0, 2) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>

    <!-- ══ The one Save — sticky, lights up when anything changed ═══════════ -->
    <div class="savebar" id="savebar">
      <button type="submit" class="btn-save">Save quote</button>
      <span class="dirtymsg" id="dirtymsg" hidden>Unsaved changes — saving logs a new revision with everything that changed.</span>
      <span class="savedtag">Last updated <?= h($quote['updated_at']) ?><?= $quote['created_by_email'] ? ' · created by ' . h($quote['created_by_email']) : '' ?></span>
    </div>
  </form>

  <!-- ══ Revision log (Quote Rev) — auto-written on every save ═════════════ -->
  <div class="qsection" id="revs">
    <h2 class="h2">Project pack revisions <span class="subnote">auto-logged on every save — everything that changed, per revision</span></h2>

    <?php if ($revs): ?>
      <div class="tablewrap"><table>
        <thead><tr><th>Rev #</th><th>Date</th><th>Saved / approved by</th><th>Changes</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($revs as $rv): ?>
          <tr>
            <td><?= h($rv['rev_no']) ?></td>
            <td><?= h($rv['rev_date']) ?></td>
            <td><?= h($rv['approved_by']) ?></td>
            <td style="white-space:normal;">
              <?php if ($rv['description']): ?><div class="muted"><?= h($rv['description']) ?></div><?php endif; ?>
              <?php if (!empty($rv['changes'])): ?><pre class="changelog"><?= h($rv['changes']) ?></pre><?php endif; ?>
            </td>
            <td class="right">
              <form class="inline" method="post" action="quote.php"
                    data-confirm="Remove revision <?= h($rv['rev_no']) ?> from the log? The changes it recorded stay applied.">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete_rev">
                <input type="hidden" name="id" value="<?= $id ?>">
                <input type="hidden" name="rev_id" value="<?= (int) $rv['id'] ?>">
                <input type="hidden" name="anchor" value="revs">
                <button class="btn-sm danger" type="submit">✕</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php else: ?>
      <p class="empty">No revisions yet — the first Save that changes anything writes revision 01 automatically.</p>
    <?php endif; ?>
  </div>
</main>

<!-- Row templates for JS-added lines (never submitted directly — only clones of these are). -->
<template id="tmpl-bom-row">
<tr class="bomrow newrow" data-line-key="__KEY__">
  <td class="w-xs"><input type="text" name="newline[__KEY__][level]" inputmode="numeric"></td>
  <td class="w-sm f-type-cell"><select name="newline[__KEY__][line_type]" class="f-type">
      <option value="Buy item">Buy item</option>
      <option value="Sub-assembly">Sub-assembly</option>
      <option value="OSP">OSP</option>
    </select></td>
  <td class="w-md"><input type="text" name="newline[__KEY__][customer_pn]" class="f-custpn"></td>
  <td class="w-md addr-field"><input type="text" name="newline[__KEY__][mfg_item]" class="f-mfgitem suggest-src" autocomplete="off"></td>
  <td class="w-lg addr-field"><input type="text" name="newline[__KEY__][description]" class="f-desc suggest-src" autocomplete="off"></td>
  <td class="w-xs"><input type="text" name="newline[__KEY__][uom]" class="f-uom"></td>
  <td class="w-sm"><input type="text" name="newline[__KEY__][qty_per]" inputmode="decimal" class="f-qtyper" placeholder="1"></td>
  <td class="w-sm"><input type="text" name="newline[__KEY__][moq]" inputmode="numeric" class="f-moq lockable"></td>
  <td class="w-xs"><input type="text" name="newline[__KEY__][flm]" inputmode="numeric" class="lockable"></td>
  <td class="w-xs"><input type="text" name="newline[__KEY__][lead_time_weeks]" inputmode="numeric"></td>
  <td class="w-md"><input type="text" name="newline[__KEY__][manufacturer]" class="lockable"></td>
  <td class="w-md"><input type="text" name="newline[__KEY__][project_supplier]" class="f-supplier lockable"></td>
  <td class="w-md"><input type="text" name="newline[__KEY__][sim_supplier_item]" class="f-supplieritem lockable"></td>
  <td class="w-sm"><input type="text" name="newline[__KEY__][quote_number]" class="lockable"></td>
  <td class="w-sm"><input type="text" name="newline[__KEY__][crossed_items]" class="lockable"></td>
  <td class="w-lg"><input type="text" name="newline[__KEY__][notes]"></td>
  <td class="w-sm"><input type="text" name="newline[__KEY__][standard_cost]" inputmode="decimal" class="f-stdcost lockable"></td>
  <td class="num computed f-extcost">—</td>
  <td class="right nowrap"><button type="button" class="btn-sm danger remove-new-row">✕</button></td>
</tr>
<tr class="breakrow" data-break-new-prefix="newline_break[__KEY__]" data-break-n="0">
  <td colspan="19">
    <div class="breakwrap">
      <span class="breaklabel">Price breaks</span>
      <table class="breaktable"><thead><tr><th>Min qty</th><th>Unit price</th><th></th></tr></thead>
        <tbody class="breaklist"></tbody>
      </table>
      <button type="button" class="btn-sm add-break">+ Price break</button>
    </div>
  </td>
</tr>
</template>

<template id="tmpl-break-row">
<tr>
  <td><input type="text" name="__PREFIX__[__N__][min_qty]" inputmode="numeric" class="f-brk-min"></td>
  <td><input type="text" name="__PREFIX__[__N__][unit_price]" inputmode="decimal" class="f-brk-price"></td>
  <td><button type="button" class="btn-sm danger remove-break-row">✕</button></td>
</tr>
</template>

<template id="tmpl-tier-row">
<tr class="tierrow" data-tier-key="__KEY__">
  <td class="w-md"><select name="newtier[__KEY__][labor_type]" class="f-labortype">
      <option value="Production">Production</option>
      <option value="Engineering">Engineering</option>
    </select></td>
  <td class="w-sm"><input type="text" name="newtier[__KEY__][build_qty]" inputmode="numeric" class="f-buildqty" placeholder="25"></td>
  <td class="w-sm"><input type="text" name="newtier[__KEY__][labor_rate]" inputmode="decimal" class="f-laborrate"></td>
  <td class="w-sm"><input type="text" name="newtier[__KEY__][labor_hours]" inputmode="decimal" class="f-laborhours" placeholder="1.5"></td>
  <td class="right"><button type="button" class="btn-sm danger remove-new-row">✕</button></td>
</tr>
</template>

<template id="tmpl-summary-row">
<tr data-summary-qty="__QTY__">
  <td class="num">__QTY__</td>
  <td class="num computed f-sum-component">$0.00</td>
  <td class="num computed f-sum-labor">$0.00</td>
  <td class="f-sum-burden">—</td>
  <td class="w-sm"><input type="text" name="summary[__QTY__][margin]" inputmode="decimal" placeholder="25" class="f-margin"></td>
  <td class="num computed f-sum-transfer">$0.00</td>
  <td class="num computed resalecol f-sum-sale">$0.00</td>
</tr>
</template>

<footer>Quoting module (Phase 2) · Bid Prep · Costed BOM · Labor Breakdown · Quote Summary · Revisions · PHP <?= PHP_VERSION ?></footer>
<script>
(function () {
  'use strict';
  var form = document.getElementById('qform');
  if (!form) return;

  // Server-provided data for client-side auto-fill + live math (no extra round-trips).
  var PM_INDEX   = <?= json_encode($pmIndexJs, JSON_UNESCAPED_SLASHES) ?>;
  var RATE_MAP   = <?= json_encode($rateMap, JSON_UNESCAPED_SLASHES) ?>;
  var BURDEN_MAP = <?= json_encode($burdenMap, JSON_UNESCAPED_SLASHES) ?>;

  // ---------------------------------------------------------------- Dirty tracking / save bar
  var dirtyMsg = document.getElementById('dirtymsg');
  var savebar  = document.getElementById('savebar');
  var dirty = false;
  function markDirty() {
    if (dirty) return;
    dirty = true;
    if (dirtyMsg) dirtyMsg.hidden = false;
    if (savebar) savebar.classList.add('dirty');
  }
  form.addEventListener('input', markDirty);
  form.addEventListener('change', markDirty);
  form.addEventListener('submit', function () { dirty = false; });
  window.addEventListener('beforeunload', function (e) {
    if (dirty) { e.preventDefault(); e.returnValue = ''; }
  });

  // "✕" checkboxes gray an existing (already-saved) row out until Save applies the removal.
  form.addEventListener('change', function (e) {
    if (e.target.matches('input[type=checkbox][name^=line_delete], input[type=checkbox][name^=tier_delete]')) {
      var tr = e.target.closest('tr');
      if (tr) tr.classList.toggle('removedrow', e.target.checked);
    }
  });

  // ------------------------------------------------------------------------- Numeric helpers
  function num(v) { var n = parseFloat(v); return isFinite(n) ? n : null; }

  // ------------------------------------------------------------------ BOM row: type grey-out
  function applyRowLock(row) {
    var typeSel = row.querySelector('.f-type');
    var isSub = !!typeSel && typeSel.value === 'Sub-assembly';
    row.classList.toggle('subassembly', isSub);
    row.querySelectorAll('.lockable').forEach(function (inp) {
      if (!inp.classList.contains('f-stdcost')) inp.disabled = isSub;
    });
    var stdCost = row.querySelector('.f-stdcost');
    var breakRow = row.nextElementSibling;
    var hasBreaks = !!(breakRow && breakRow.classList.contains('breakrow') && breakRow.querySelectorAll('.breaklist tr').length > 0);
    if (stdCost) stdCost.disabled = isSub || hasBreaks;
    return { isSub: isSub, hasBreaks: hasBreaks };
  }

  function recomputeExtCost(row) {
    var stdCost = row.querySelector('.f-stdcost');
    var qtyPer  = row.querySelector('.f-qtyper');
    var extCell = row.querySelector('.f-extcost');
    if (!stdCost || !qtyPer || !extCell) return;
    var c = num(stdCost.value), q = num(qtyPer.value);
    extCell.textContent = (c !== null && q !== null) ? ('$' + (c * q).toFixed(2)) : '—';
  }

  // Std Cost auto-resolve: largest min_qty <= MOQ, from this row's break sub-rows.
  function resolveStdCostFromBreaks(row) {
    var breakRow = row.nextElementSibling;
    if (!breakRow || !breakRow.classList.contains('breakrow')) return;
    var rows = breakRow.querySelectorAll('.breaklist tr');
    var stdCost = row.querySelector('.f-stdcost');
    var moqInp = row.querySelector('.f-moq');
    if (!stdCost) return;
    if (!rows.length) { applyRowLock(row); recomputeExtCost(row); return; }
    var moq = moqInp ? num(moqInp.value) : null;
    var best = null;
    rows.forEach(function (r) {
      var min = num(r.querySelector('.f-brk-min').value);
      var price = num(r.querySelector('.f-brk-price').value);
      if (min === null || price === null) return;
      if (moq !== null && min <= moq && (best === null || min > best.min)) best = { min: min, price: price };
    });
    if (best) stdCost.value = best.price.toFixed(4).replace(/0+$/, '').replace(/\.$/, '');
    applyRowLock(row);
    recomputeExtCost(row);
  }

  // ------------------------------------------------------------------------ Price break rows
  var breakTmpl = document.getElementById('tmpl-break-row').innerHTML;
  function addBreakRow(breakRowEl) {
    var prefix = breakRowEl.getAttribute('data-break-new-prefix');
    var n = parseInt(breakRowEl.getAttribute('data-break-n') || '0', 10);
    breakRowEl.setAttribute('data-break-n', String(n + 1));
    var html = breakTmpl.split('__PREFIX__').join(prefix).split('__N__').join('n' + n);
    var tmp = document.createElement('tbody');
    tmp.innerHTML = html.trim();
    var tr = tmp.querySelector('tr');
    breakRowEl.querySelector('.breaklist').appendChild(tr);
    return tr;
  }

  // ------------------------------------------------------------------------------ BOM rows
  var bomBody = document.getElementById('bom-body');
  var bomTmpl = document.getElementById('tmpl-bom-row').innerHTML;
  var bomKeyN = 0;
  document.getElementById('add-bom-row').addEventListener('click', function () {
    bomKeyN++;
    var key = 'n' + Date.now() + '_' + bomKeyN;
    var html = bomTmpl.split('__KEY__').join(key);
    var tmp = document.createElement('tbody');
    tmp.innerHTML = html.trim();
    var rows = Array.prototype.slice.call(tmp.querySelectorAll('tr'));
    rows.forEach(function (r) { bomBody.appendChild(r); });
    markDirty();
  });

  form.addEventListener('click', function (e) {
    if (e.target.matches('.remove-new-row')) {
      var tr = e.target.closest('tr');
      var next = tr.nextElementSibling;
      tr.remove();
      if (next && next.classList.contains('breakrow')) next.remove();
      markDirty();
      rebuildSummary();
      return;
    }
    if (e.target.matches('.add-break')) {
      var breakRow = e.target.closest('.breakrow');
      addBreakRow(breakRow);
      markDirty();
      return;
    }
    if (e.target.matches('.remove-break-row')) {
      var row = e.target.closest('tr');
      var bomRow = row.closest('.breakrow').previousElementSibling;
      row.remove();
      if (bomRow) { resolveStdCostFromBreaks(bomRow); }
      markDirty();
      recomputeAll();
      return;
    }
  });

  // ------------------------------------------------------------------------- Labor rows
  var laborBody = document.getElementById('labor-body');
  var tierTmpl = document.getElementById('tmpl-tier-row').innerHTML;
  var tierKeyN = 0;
  document.getElementById('add-tier-row').addEventListener('click', function () {
    tierKeyN++;
    var key = 't' + Date.now() + '_' + tierKeyN;
    var html = tierTmpl.split('__KEY__').join(key);
    var tmp = document.createElement('tbody');
    tmp.innerHTML = html.trim();
    laborBody.appendChild(tmp.querySelector('tr'));
    markDirty();
  });

  // -------------------------------------------------------------- Program Manager auto-fill
  function fillProgramManager() {
    var custSel = document.getElementById('f_customer');
    var plantSel = document.getElementById('f_plant');
    var pmInp = document.getElementById('f_pm');
    if (!custSel || !plantSel || !pmInp) return;
    if (pmInp.value.trim() !== '') return;             // never overwrite a typed value
    var key = custSel.value.trim().toLowerCase() + '|' + plantSel.value.trim();
    if (PM_INDEX[key]) { pmInp.value = PM_INDEX[key]; markDirty(); }
  }
  var custSel = document.getElementById('f_customer');
  var plantSel = document.getElementById('f_plant');
  if (custSel) custSel.addEventListener('change', fillProgramManager);
  if (plantSel) plantSel.addEventListener('change', function () { fillProgramManager(); recomputeAll(); });

  // ------------------------------------------------------------------ Labor rate auto-fill
  function fillLaborRate(row) {
    var typeSel = row.querySelector('.f-labortype');
    var rateInp = row.querySelector('.f-laborrate');
    var plantSel = document.getElementById('f_plant');
    if (!typeSel || !rateInp || !plantSel) return;
    if (rateInp.value.trim() !== '') return;           // a manually typed rate wins
    var rates = RATE_MAP[plantSel.value] || {};
    var r = rates[typeSel.value];
    if (r !== undefined && r !== null) { rateInp.value = r; markDirty(); }
  }

  // ---------------------------------------------------------------------- Item typeahead
  var suggestBox = null;
  function closeSuggest() { if (suggestBox) { suggestBox.remove(); suggestBox = null; } }
  var debounceT = null;

  function showSuggestions(input, list) {
    closeSuggest();
    if (!list.length) return;
    var td = input.closest('td');
    var box = document.createElement('div');
    box.className = 'addr-suggest';
    list.forEach(function (item) {
      var d = document.createElement('div');
      d.className = 'as-item';
      d.innerHTML = '<span class="as-street">' + item.item_number + ' — ' + (item.type_label || '') + '</span>' +
                    '<span class="as-rest">' + (item.description || '') + '</span>';
      d.addEventListener('mousedown', function (e) {
        e.preventDefault();
        applySuggestion(input, item);
        closeSuggest();
      });
      box.appendChild(d);
    });
    td.appendChild(box);
    suggestBox = box;
  }

  function applySuggestion(input, item) {
    var row = input.closest('tr');
    if (!row) return;
    var mfg = row.querySelector('.f-mfgitem');
    var desc = row.querySelector('.f-desc');
    var custPn = row.querySelector('.f-custpn');
    var uom = row.querySelector('.f-uom');
    var moq = row.querySelector('.f-moq');
    var flm = row.querySelector('.lockable[name*="[flm]"]');
    var supplier = row.querySelector('.f-supplier');
    var supplierItem = row.querySelector('.f-supplieritem');
    var typeSel = row.querySelector('.f-type');
    if (mfg) mfg.value = item.item_number;
    if (desc) desc.value = item.description || '';
    if (custPn && custPn.value.trim() === '') custPn.value = item.item_number;
    if (uom) uom.value = item.primary_uom || '';
    if (moq && item.moq !== null && item.moq !== undefined) moq.value = item.moq;
    if (flm && item.flm !== null && item.flm !== undefined) flm.value = item.flm;
    if (supplier) supplier.value = item.supplier || '';
    if (supplierItem) supplierItem.value = item.supplier_item || '';
    if (typeSel && item.type_label) typeSel.value = item.type_label;
    applyRowLock(row);
    recomputeExtCost(row);
    markDirty();
    recomputeAll();
  }

  form.addEventListener('input', function (e) {
    if (!e.target.matches('.suggest-src')) return;
    var input = e.target;
    clearTimeout(debounceT);
    var term = input.value.trim();
    if (term.length < 2) { closeSuggest(); return; }
    debounceT = setTimeout(function () {
      fetch('quote-item-suggest.php?q=' + encodeURIComponent(term))
        .then(function (r) { return r.json(); })
        .then(function (data) { showSuggestions(input, data.suggestions || []); })
        .catch(function () { closeSuggest(); });
    }, 250);
  });
  document.addEventListener('click', function (e) {
    if (suggestBox && !e.target.closest('.addr-field')) closeSuggest();
  });

  // ---------------------------------------------------------- Quote Summary live recompute
  var summaryTmpl = document.getElementById('tmpl-summary-row').innerHTML;
  var summaryBody = document.getElementById('summary-body');
  var summaryWrap = document.getElementById('summary-wrap');

  function currentPlant() {
    var sel = document.getElementById('f_plant');
    return sel ? sel.value : '';
  }

  function componentCostTotal() {
    var total = 0;
    document.querySelectorAll('#bom-body .bomrow').forEach(function (row) {
      if (row.classList.contains('removedrow')) return;
      var c = num((row.querySelector('.f-stdcost') || {}).value);
      var q = num((row.querySelector('.f-qtyper') || {}).value);
      if (c !== null && q !== null) total += c * q;
    });
    return total;
  }

  function laborByBuildQty() {
    var out = {};
    document.querySelectorAll('#labor-body .tierrow').forEach(function (row) {
      if (row.classList.contains('removedrow')) return;
      var bq = (row.querySelector('.f-buildqty') || {}).value;
      var bqN = parseInt(bq, 10);
      if (!bqN) return;
      var rate = num((row.querySelector('.f-laborrate') || {}).value) || 0;
      var hrs  = num((row.querySelector('.f-laborhours') || {}).value) || 0;
      out[bqN] = (out[bqN] || 0) + rate * hrs;
    });
    return out;
  }

  function rebuildSummary() {
    var labor = laborByBuildQty();
    var qtys = Object.keys(labor).map(Number).sort(function (a, b) { return a - b; });

    // Remove rows whose build qty disappeared.
    summaryBody.querySelectorAll('tr').forEach(function (row) {
      var bq = parseInt(row.getAttribute('data-summary-qty'), 10);
      if (qtys.indexOf(bq) === -1) row.remove();
    });
    // Add rows for new build qtys.
    qtys.forEach(function (bq) {
      if (summaryBody.querySelector('tr[data-summary-qty="' + bq + '"]')) return;
      var html = summaryTmpl.split('__QTY__').join(bq);
      var tmp = document.createElement('tbody');
      tmp.innerHTML = html.trim();
      summaryBody.appendChild(tmp.querySelector('tr'));
    });
    summaryWrap.hidden = qtys.length === 0;
    recomputeAll();
  }

  function recomputeAll() {
    var plant = currentPlant();
    var burden = BURDEN_MAP[plant] || { materials: 0, labor: 0 };
    var component = componentCostTotal();
    var labor = laborByBuildQty();

    document.querySelectorAll('#bom-body .bomrow').forEach(recomputeExtCost);
    document.getElementById('bom-mat-total').textContent = '$' + component.toFixed(2);

    summaryBody.querySelectorAll('tr').forEach(function (row) {
      var bq = parseInt(row.getAttribute('data-summary-qty'), 10);
      var laborCost = labor[bq] || 0;
      var marginInp = row.querySelector('.f-margin');
      var marginPct = marginInp ? num(marginInp.value) : null;
      var margin = (marginPct !== null) ? marginPct / 100 : 0.25;
      var bm = burden.materials < 1 ? (1 - burden.materials) : 1e-9;
      var bl = burden.labor < 1 ? (1 - burden.labor) : 1e-9;
      var mg = margin < 1 ? (1 - margin) : 1e-9;
      var transfer = (component / bm) + (laborCost / bl);
      var sale = transfer / mg;
      row.querySelector('.f-sum-component').textContent = '$' + component.toFixed(2);
      row.querySelector('.f-sum-labor').textContent = '$' + laborCost.toFixed(2);
      row.querySelector('.f-sum-burden').textContent = (burden.materials * 100).toFixed(1) + '% / ' + (burden.labor * 100).toFixed(1) + '%';
      row.querySelector('.f-sum-transfer').textContent = '$' + transfer.toFixed(2);
      row.querySelector('.f-sum-sale').textContent = '$' + sale.toFixed(2);
    });
  }

  // ----------------------------------------------------------------------- Delegated events
  form.addEventListener('change', function (e) {
    if (e.target.matches('.f-type')) { applyRowLock(e.target.closest('tr')); recomputeExtCost(e.target.closest('tr')); recomputeAll(); }
    if (e.target.matches('.f-labortype')) fillLaborRate(e.target.closest('tr'));
  });
  form.addEventListener('input', function (e) {
    if (e.target.matches('.f-stdcost, .f-qtyper')) recomputeExtCost(e.target.closest('tr'));
    if (e.target.matches('.f-moq')) resolveStdCostFromBreaks(e.target.closest('.bomrow'));
    if (e.target.matches('.f-brk-min, .f-brk-price')) {
      var breakRow = e.target.closest('.breakrow');
      if (breakRow && breakRow.previousElementSibling) resolveStdCostFromBreaks(breakRow.previousElementSibling);
    }
    if (e.target.matches('.f-stdcost, .f-qtyper, .f-laborrate, .f-laborhours, .f-margin')) recomputeAll();
    if (e.target.matches('.f-buildqty, .f-laborrate, .f-laborhours')) rebuildSummary();
  });
  form.addEventListener('change', function (e) {
    if (e.target.matches('.f-buildqty, .f-laborrate, .f-laborhours')) rebuildSummary();
  });
  // Initial paint: apply locks/greying + Ext cost for server-rendered rows.
  document.querySelectorAll('#bom-body .bomrow').forEach(function (row) {
    applyRowLock(row);
    recomputeExtCost(row);
  });
  recomputeAll();
})();
</script>
</body>
</html>
