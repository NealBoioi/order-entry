<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/profile.php';
auth_boot();

$me  = require_login();
$uid = (int) $me['id'];
$branch = (string) ($me['branch'] ?? '');
ensure_profile($uid);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    switch ($_POST['action'] ?? '') {
        case 'save_profile':
            [$ok, $err] = save_profile_core($uid, $_POST, false);
            $_SESSION['flash'] = $ok ? ['ok', 'Account info saved.'] : ['err', $err];
            break;
        case 'save_method':
            [$ok, $res] = save_ship_method($uid, (int) ($_POST['id'] ?? 0) ?: null, $_POST);
            if ($ok && empty(get_profile($uid)['default_method_id']) && count(list_ship_methods($uid)) === 1) set_default_method($uid, (int) $res);
            $_SESSION['flash'] = $ok ? ['ok', 'Ship method saved.'] : ['err', $res];
            break;
        case 'delete_method':
            delete_ship_method($uid, (int) ($_POST['id'] ?? 0));
            $_SESSION['flash'] = ['info', 'Ship method removed.'];
            break;
        case 'default_method':
            set_default_method($uid, (int) ($_POST['id'] ?? 0));
            $_SESSION['flash'] = ['ok', 'Default ship method updated.'];
            break;
    }
    redirect('settings.php#' . ($_POST['anchor'] ?? ''));
}

$flash     = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$profile   = get_profile($uid) ?: [];
$methods   = list_ship_methods($uid);
$defMethod = (int) ($profile['default_method_id'] ?? 0);
$nShip     = count(list_ship_addresses($uid));
$nBill     = count(list_bill_addresses($uid));
$methEdit  = isset($_GET['method']) ? get_ship_method((int) $_GET['method']) : null;
if ($methEdit && (int) $methEdit['user_id'] !== $uid) $methEdit = null;
$mem = fn($f) => h($methEdit[$f] ?? '');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Settings — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('settings'); ?>
<main>
  <h1>Account settings <span class="sub">the info you entered at signup — update it anytime</span></h1>
  <?php if ($flash): ?><div class="msg <?= h($flash[0]) ?>"><?= h($flash[1]) ?></div><?php endif; ?>

  <!-- Account info -->
  <form method="post" action="settings.php" class="qsection" id="info">
    <?= csrf_field() ?><input type="hidden" name="action" value="save_profile"><input type="hidden" name="anchor" value="info">
    <h2 class="h2">Your info</h2>
    <div class="qgrid">
      <label>Full name *<input type="text" name="full_name" value="<?= h($profile['full_name'] ?? '') ?>" required></label>
      <label>Title<input type="text" name="title" value="<?= h($profile['title'] ?? '') ?>" placeholder="e.g. Buyer, Inside Sales Rep, Outside Sales Rep"></label>
      <label>Branch<input type="text" value="<?= h($branch) ?>" disabled></label>
      <label>Email<input type="text" value="<?= h($me['email']) ?>" disabled></label>
    </div>
    <div class="saverow"><button type="submit" class="btn-save">Save info</button></div>
  </form>

  <!-- Address books -->
  <a class="settingscard" href="addresses.php?type=ship">
    <div><div class="sc-title">Ship-To Addresses</div><div class="sc-sub"><?= $nShip ?> saved · add, edit, or set a default</div></div>
    <div class="sc-arrow">›</div>
  </a>
  <a class="settingscard" href="addresses.php?type=bill">
    <div><div class="sc-title">Bill-To Addresses</div><div class="sc-sub"><?= $nBill ?> saved · add, edit, or set a default</div></div>
    <div class="sc-arrow">›</div>
  </a>

  <!-- Ship methods -->
  <div class="qsection" id="method">
    <h2 class="h2">Ship methods <span class="subnote">pick one per order; ★ = default</span></h2>
    <?php if ($methods): ?>
      <div class="tablewrap"><table>
        <thead><tr><th></th><th>Label</th><th>Terms</th><th>Method</th><th>Carrier acct #</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($methods as $m): ?>
          <tr class="<?= $methEdit && (int)$methEdit['id']===(int)$m['id'] ? 'editing' : '' ?>">
            <td><?php if ((int)$m['id']===$defMethod): ?><span class="statuspill active">★ default</span><?php else: ?>
              <form class="inline" method="post" action="settings.php"><?= csrf_field() ?><input type="hidden" name="action" value="default_method"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><input type="hidden" name="anchor" value="method"><button class="btn-sm" type="submit">Set default</button></form>
            <?php endif; ?></td>
            <td><?= h($m['label'] ?: '—') ?></td>
            <td><?= h($m['terms'] ?: '—') ?></td>
            <td><?= h($m['method'] ?: '—') ?></td>
            <td><?= h($m['carrier_acct'] ?: '—') ?></td>
            <td class="right">
              <a class="btn-sm" href="settings.php?method=<?= (int)$m['id'] ?>#methodform">Edit</a>
              <form class="inline" method="post" action="settings.php" data-confirm="Remove this ship method?"><?= csrf_field() ?><input type="hidden" name="action" value="delete_method"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><input type="hidden" name="anchor" value="method"><button class="btn-sm danger" type="submit">✕</button></form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php else: ?><p class="empty">No ship methods yet — add one below.</p><?php endif; ?>

    <h3 class="grouplabel" id="methodform"><?= $methEdit ? 'Edit ship method' : 'Add a ship method' ?></h3>
    <form method="post" action="settings.php" class="<?= $methEdit ? 'editing' : '' ?>" style="padding:12px;border-radius:8px;">
      <?= csrf_field() ?><input type="hidden" name="action" value="save_method"><input type="hidden" name="anchor" value="method">
      <?php if ($methEdit): ?><input type="hidden" name="id" value="<?= (int)$methEdit['id'] ?>"><?php endif; ?>
      <div class="qgrid">
        <label>Label<input type="text" name="label" value="<?= $mem('label') ?>" placeholder="e.g. Standard, Rush"></label>
        <label>Shipping terms<input type="text" name="terms" value="<?= $mem('terms') ?>" placeholder="Prepaid &amp; Add, Collect"></label>
        <label>Ship method *<input type="text" name="method" value="<?= $mem('method') ?>" placeholder="UPS Ground, R&amp;L Freight" required></label>
        <label>Carrier account #<input type="text" name="carrier_acct" value="<?= $mem('carrier_acct') ?>"></label>
      </div>
      <div class="saverow"><button type="submit" class="btn-save"><?= $methEdit ? 'Update method' : 'Add method' ?></button>
        <?php if ($methEdit): ?><a class="btn-sm" href="settings.php#method">Cancel</a><?php endif; ?></div>
    </form>
  </div>
</main>
<footer>Account settings · PHP <?= PHP_VERSION ?></footer>
</body>
</html>
