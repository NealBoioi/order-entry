/* Themed confirmation modal — replaces native confirm() sitewide.
 * Any <form data-confirm="message"> (or <a data-confirm>) shows a centered, on-brand dialog
 * over a blurred/dimmed backdrop instead of the browser's confirm box.
 *
 * Auto-behavior (no extra attributes needed):
 *   - variant: "danger" if the trigger's submit button has a .danger class, else "primary"
 *   - confirm-label: the submit button's own text (e.g. "Delete", "Deny"), else a sensible default
 * Override with data-confirm-variant / data-confirm-ok / data-confirm-title if desired.
 */
(function () {
  'use strict';
  var modal, badgeEl, titleEl, msgEl, okBtn, cancelBtn, pending = null;

  var GLYPH_DANGER = '<svg viewBox="0 0 24 24" fill="none"><path d="M13.94 4.67 21.6 18a2.24 2.24 0 0 1-1.94 3.36H4.34A2.24 2.24 0 0 1 2.4 18l7.66-13.33a2.24 2.24 0 0 1 3.88 0Z" fill="currentColor"/><path d="M12 9.4v3.9" stroke="#fff" stroke-width="2.1" stroke-linecap="round"/><circle cx="12" cy="16.5" r="1.1" fill="#fff"/></svg>';
  var GLYPH_ASK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.5"/><path d="M9.3 9.2a2.8 2.8 0 1 1 3.9 2.6c-.79.5-1.4.9-1.4 1.9"/><path d="M12 17h.01"/></svg>';

  ready(function () {
    build();
    bind(document);
  });

  function ready(fn) { document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn); }

  function build() {
    modal = document.createElement('div');
    modal.className = 'cmodal';
    modal.hidden = true;
    modal.innerHTML =
      '<div class="cmodal-backdrop"></div>' +
      '<div class="cmodal-card" role="dialog" aria-modal="true" aria-labelledby="cmodal-title">' +
        '<div class="cmodal-icon" aria-hidden="true">' +
          '<span class="cmodal-ring"></span><span class="cmodal-ring cmodal-ring-2"></span>' +
          '<span class="cmodal-badge"></span>' +
        '</div>' +
        '<h2 class="cmodal-title" id="cmodal-title"></h2>' +
        '<p class="cmodal-msg"></p>' +
        '<div class="cmodal-actions">' +
          '<button type="button" class="btn-sm cmodal-cancel">Cancel</button>' +
          '<button type="button" class="btn-sm cmodal-ok">Confirm</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(modal);
    badgeEl  = modal.querySelector('.cmodal-badge');
    titleEl  = modal.querySelector('.cmodal-title');
    msgEl    = modal.querySelector('.cmodal-msg');
    okBtn    = modal.querySelector('.cmodal-ok');
    cancelBtn = modal.querySelector('.cmodal-cancel');

    cancelBtn.addEventListener('click', close);
    modal.querySelector('.cmodal-backdrop').addEventListener('click', close);
    okBtn.addEventListener('click', proceed);
    document.addEventListener('keydown', function (e) {
      if (modal.hidden) return;
      if (e.key === 'Escape') close();
      else if (e.key === 'Enter') { e.preventDefault(); proceed(); }
    });
  }

  function bind(root) {
    root.querySelectorAll('form[data-confirm]').forEach(function (f) {
      f.addEventListener('submit', function (e) {
        if (f.__confirmed) { f.__confirmed = false; return; }   // our own re-submit passes through
        e.preventDefault();
        open(f);
      });
    });
    root.querySelectorAll('a[data-confirm]').forEach(function (a) {
      a.addEventListener('click', function (e) { e.preventDefault(); open(a); });
    });
  }

  function open(el) {
    pending = el;
    var msg = el.getAttribute('data-confirm') || 'Are you sure?';
    var submitBtn = el.querySelector('button[type="submit"], button:not([type]), input[type="submit"]');
    var btnText = submitBtn ? (submitBtn.textContent || submitBtn.value || '').trim() : '';

    var variant = el.getAttribute('data-confirm-variant');
    if (!variant) variant = (submitBtn && /\bdanger\b/.test(submitBtn.className)) ? 'danger' : 'primary';

    var okLabel = el.getAttribute('data-confirm-ok');
    if (!okLabel) okLabel = /^[A-Za-z][A-Za-z ]{1,14}$/.test(btnText) ? btnText : (variant === 'danger' ? 'Remove' : 'Confirm');

    var title = el.getAttribute('data-confirm-title') || (variant === 'danger' ? 'Are you sure?' : 'Please confirm');

    badgeEl.innerHTML = variant === 'danger' ? GLYPH_DANGER : GLYPH_ASK;
    titleEl.textContent = title;
    msgEl.textContent = msg;
    okBtn.textContent = okLabel;
    okBtn.className = 'btn-sm cmodal-ok ' + (variant === 'danger' ? 'danger' : 'primary');
    modal.classList.toggle('danger', variant === 'danger');

    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(function () { modal.classList.add('open'); });
    okBtn.focus();
  }

  function close() {
    modal.classList.remove('open');
    document.body.style.overflow = '';
    var el = modal;
    setTimeout(function () { if (!modal.classList.contains('open')) el.hidden = true; }, 200);
    pending = null;
  }

  function proceed() {
    var el = pending;
    close();
    if (!el) return;
    if (el.tagName === 'FORM') { el.__confirmed = true; el.requestSubmit ? el.requestSubmit() : el.submit(); }
    else if (el.tagName === 'A' && el.href) { window.location = el.href; }
  }
})();
