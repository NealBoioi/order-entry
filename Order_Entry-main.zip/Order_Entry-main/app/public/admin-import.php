<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/import.php';
auth_boot();
$me = require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    if ($action === 'import') {
        // Pull today's file from ALL THREE source folders.
        $it = import_items();
        $ol = import_order_lines();
        $ms = import_material_stats();
        $ok = $it['ok'] && $ol['ok'] && $ms['ok'];
        $parts = [];
        $parts[] = $it['ok'] ? number_format($it['count']) . ' items (' . $it['file'] . ')' : 'items — ' . $it['error'];
        $parts[] = $ol['ok'] ? number_format($ol['count']) . ' order lines (' . $ol['file'] . ')' : 'orders — ' . $ol['error'];
        $parts[] = $ms['ok'] ? number_format($ms['count']) . ' material stats rows (' . $ms['file'] . ')' : 'material stats — ' . $ms['error'];
        $_SESSION['flash'] = [$ok ? 'ok' : 'err', ($ok ? 'Imported ' : 'Partial import — ') . implode('; ', $parts) . '.'];
    } elseif ($action === 'erase') {
        $n = erase_items();
        $_SESSION['flash'] = ['info', 'Erased ' . number_format($n) . ' item rows (local catalog only — source files untouched).'];
    }
    redirect('admin-import.php');
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$today = import_today();
$itemNo = count_items();

// Abbreviate the home dir for tidier local paths (UNC/Windows paths are shown as-is).
$home = getenv('HOME') ?: ($_SERVER['HOME'] ?? '');
$abbr = fn(string $p) => ($p !== '' && $home && str_starts_with($p, $home)) ? '~' . substr($p, strlen($home)) : $p;

// Each feed: folder, whether it's reachable, and whether TODAY's file is present.
$feeds = [
    ['Item warehouse',  import_source('items'),          import_items_source(),  'lr_item_warehouse_all_' . $today . '.xlsx'],
    ['RG report',       import_source('orders'),         import_orders_source(), 'A10_daily_rg_' . $today . '.csv'],
    ['Material Stats',  import_source('material_stats'), import_stats_source(),  'all_orgs_material_stats_' . $today . '.xlsx'],
];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Import — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('import'); ?>
<main>
  <h1>Daily Import <span class="sub">pull today's item &amp; order reports from the server · admin only</span></h1>

  <?php if ($flash): ?><div class="msg <?= h($flash[0]) ?>"><?= h($flash[1]) ?></div><?php endif; ?>

  <section class="submitform importcard">
    <div class="import-status">
      <div class="import-stat">
        <div class="import-stat-num"><?= number_format($itemNo) ?></div>
        <div class="import-stat-label">items loaded</div>
      </div>
      <div class="import-src">
        <div class="import-today">Looking for files dated <strong><?= h($today) ?></strong> (updates automatically each day)</div>
      </div>
    </div>

    <?php foreach ($feeds as [$name, $dir, $file, $expected]): ?>
      <?php $dirOk = $dir !== '' && is_dir($dir); ?>
      <div class="import-feed">
        <div class="import-feed-head">
          <span class="import-feed-name"><?= h($name) ?></span>
          <?php if ($file): ?>
            <span class="statuspill active">today's file found</span>
          <?php elseif (!$dirOk): ?>
            <span class="statuspill urgent">folder unreachable</span>
          <?php else: ?>
            <span class="statuspill pending">today's file not found</span>
          <?php endif; ?>
        </div>
        <div class="import-feed-line"><span class="import-src-k">Folder</span>
          <code class="import-src-path" title="<?= h($dir) ?>"><?= h($abbr($dir) !== '' ? $abbr($dir) : '(not configured)') ?></code></div>
        <div class="import-feed-line"><span class="import-src-k">File</span>
          <span class="import-feed-file<?= $file ? ' ok' : '' ?>"><?= h($expected) ?></span></div>
      </div>
    <?php endforeach; ?>

    <p class="note import-note">Pulls <strong>today's</strong> dated file from each folder above and
      replaces the catalog (atomic — a failed load keeps current data). <strong>Erase</strong> clears the
      local catalog only; it never deletes files from the server.</p>

    <div class="import-actions">
      <form method="post" action="admin-import.php" class="inline">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="import">
        <button type="submit" class="submitbtn">Import today's reports</button>
      </form>
      <form method="post" action="admin-import.php" class="inline">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="erase">
        <button type="submit" class="btn-sm danger"
                data-confirm="Erase all <?= number_format($itemNo) ?> item rows from the local catalog? Price lookup and new-order pricing will show no items until the next import. (Source files on the server are not touched.)">
          Erase item data
        </button>
      </form>
    </div>
  </section>
</main>
<footer>Daily import · admin · PHP <?= PHP_VERSION ?></footer>
</body>
</html>
