<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/orders.php';
require __DIR__ . '/../src/notify.php';
require __DIR__ . '/../src/profile.php';
auth_boot();

$me     = require_login();
$role   = $me['role'];
$branch = $me['branch'];            // fixed for customers; null for admins (they type it)

$errors = [];
// Repopulated on a failed submit so the user doesn't lose their header entries.
$fOrg      = $_POST['org']           ?? '';
$fLot      = $_POST['lot']           ?? '';
$fNotes    = $_POST['notes']         ?? '';
$fDelivery = trim($_POST['delivery_date'] ?? '');   // Requested Delivery Date (optional, YYYY-MM-DD)
$fUrgent   = !empty($_POST['urgent']);              // URGENT flag
$fShipRef  = trim($_POST['shipment_ref'] ?? '');    // optional Shipment Reference #

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $itemNo = trim($_POST['item_number'] ?? '');
        $qty    = max(1, (int) ($_POST['qty'] ?? 1));
        $item   = $itemNo !== '' ? find_item($itemNo, $role) : null;
        if (!$item) {
            $_SESSION['flash'] = ['err', 'Item not found (or not available to your account).'];
        } else {
            $pr = price_for_item($item, $qty);
            cart_add([
                'item_number' => $item['item_number'],
                'description' => $item['description'],
                'item_type'   => $item['item_type'],
                'uom'         => $item['primary_uom'] ?? null,
                'quantity'    => $qty,
                'unit_price'  => $pr['unit_price'],
                'price_source'=> $pr['source'],
            ]);
            $_SESSION['flash'] = ['ok', 'Added ' . $item['item_number'] . ' × ' . $qty . '.'];
        }
        redirect('new-order.php');
    }
    if ($action === 'remove') { cart_remove((int) ($_POST['i'] ?? -1)); redirect('new-order.php'); }
    if ($action === 'clear')  { cart_clear(); redirect('new-order.php'); }

    if ($action === 'submit') {
        $lines = cart();
        $useBranch = $role === 'admin' ? trim($_POST['branch'] ?? '') : (string) $branch;
        $lot = trim($fLot);

        if (!$lines)                                   $errors[] = 'Add at least one line before submitting.';
        if (!array_key_exists($fOrg, org_options()))   $errors[] = 'Choose a plant.';
        if (!preg_match('/^\d{4}$/', $useBranch))       $errors[] = 'Branch # must be 4 digits.';
        if ($lot === '')                                $errors[] = 'Enter the PO/lot number.';
        // Requested delivery date is optional, but if given it must be a real date, today or later.
        $delivery = null;
        if ($fDelivery !== '') {
            $d = DateTime::createFromFormat('Y-m-d', $fDelivery);
            if (!$d || $d->format('Y-m-d') !== $fDelivery) {
                $errors[] = 'Requested delivery date is not a valid date.';
            } elseif ($fDelivery < date('Y-m-d')) {
                $errors[] = 'Requested delivery date cannot be in the past.';
            } else {
                $delivery = $fDelivery;
            }
        }

        if (!$errors) {
            $po = $useBranch . '-' . $lot;
            // Snapshot the CHOSEN ship-to + ship method (from the customer's saved options) and
            // their bill-to onto the order.
            $shipTo = format_ship_address(resolve_ship_address((int) $me['id'], (int) ($_POST['ship_id'] ?? 0) ?: null));
            $method = format_ship_method(resolve_ship_method((int) $me['id'], (int) ($_POST['method_id'] ?? 0) ?: null));
            $billTo = format_bill_address(resolve_bill_address((int) $me['id'], (int) ($_POST['bill_id'] ?? 0) ?: null));
            $orderId = create_site_order($me['id'], $useBranch, $fOrg, $po, $fNotes, $lines, $shipTo, $billTo, $method, $delivery, $fUrgent, $fShipRef);
            notify_new_order($orderId, $po, $fOrg);
            cart_clear();
            redirect('order.php?id=' . $orderId . '&new=1');
        }
        // fall through and re-render with $errors + repopulated header fields
    }
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$q       = trim($_GET['q'] ?? '');
$matches = $q !== '' ? lookup_items($q, $role) : [];
$lines   = cart();
$orgs    = org_options();
// Saved ship-to options / ship methods / bill-to for the order form (customers).
$myShips    = list_ship_addresses((int) $me['id']);
$myBills    = list_bill_addresses((int) $me['id']);
$myMethods  = list_ship_methods((int) $me['id']);
$prof       = get_profile((int) $me['id']) ?: [];
$defShip    = (int) ($prof['default_ship_id'] ?? 0);
$defBill    = (int) ($prof['default_bill_id'] ?? 0);
$defMethod  = (int) ($prof['default_method_id'] ?? 0);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>New Order — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('new'); ?>
<main>
  <h1>New Order <span class="sub">search parts &amp; add lines · pricing auto-populates by item &amp; qty</span></h1>

  <?php if ($flash): ?><div class="msg <?= h($flash[0]) ?>"><?= h($flash[1]) ?></div><?php endif; ?>
  <?php if ($errors): ?><div class="msg err"><?= h(implode(' ', $errors)) ?></div><?php endif; ?>

  <div class="grid2">
    <!-- Left: find & add parts -->
    <section>
      <h2 class="h2">Add parts</h2>
      <form method="get" action="new-order.php" class="searchbar">
        <input type="text" name="q" value="<?= h($q) ?>" placeholder="Part # / description — exact, or use % (e.g. %320% , 320%)" autofocus>
        <button type="submit">Find</button>
      </form>
      <?php if ($q !== ''): ?>
        <p class="note"><?= count($matches) ?> match(es)
          <?php if ($role==='customer'): ?><span class="tag">assemblies only</span><?php endif; ?>
        </p>
        <?php foreach ($matches as $it): ?>
          <form method="post" action="new-order.php" class="addrow">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add">
            <input type="hidden" name="item_number" value="<?= h($it['item_number']) ?>">
            <div class="addrow-main">
              <span class="itemno sm"><?= h($it['item_number']) ?></span>
              <span class="desc sm"><?= h($it['description']) ?></span>
            </div>
            <input type="number" name="qty" value="1" min="1" class="qtybox">
            <button class="btn-sm primary" type="submit">Add</button>
          </form>
        <?php endforeach; ?>
        <?php if (!$matches): ?><p class="empty">No matching parts.</p><?php endif; ?>
      <?php endif; ?>
    </section>

    <!-- Right: current order (cart) + submit -->
    <section>
      <h2 class="h2">This order</h2>
      <?php if (!$lines): ?>
        <p class="empty">No lines yet — find a part and add it.</p>
      <?php else: ?>
        <div class="tablewrap"><table>
          <thead><tr><th>Item</th><th>Description</th><th>Qty</th><th>Unit</th><th>Ext</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($lines as $i => $l): ?>
            <tr>
              <td><?= h($l['item_number']) ?></td>
              <td><?= h($l['description']) ?></td>
              <td><?= h($l['quantity']) ?></td>
              <td><?= $l['unit_price']!==null ? '$'.number_format($l['unit_price'],4) : '<span class="muted">—</span>' ?>
                <?php $srcLabel = price_source_label($l['price_source'] ?? null); ?>
                <?php if ($srcLabel): ?><br><span class="tag" style="margin-left:0;"><?= h($srcLabel) ?></span><?php endif; ?>
              </td>
              <td><?= $l['unit_price']!==null ? '$'.number_format($l['unit_price']*$l['quantity'],2) : '<span class="muted">no price</span>' ?></td>
              <td>
                <form class="inline" method="post" action="new-order.php">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="remove">
                  <input type="hidden" name="i" value="<?= (int) $i ?>">
                  <button class="btn-sm danger" type="submit">✕</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
          <tfoot><tr><th colspan="4" class="right">Total</th><th>$<?= number_format(cart_total(),2) ?></th><th></th></tr></tfoot>
        </table></div>
        <form class="inline" method="post" action="new-order.php"><?= csrf_field() ?><input type="hidden" name="action" value="clear"><button type="submit" class="clear-order-link">clear order</button></form>
      <?php endif; ?>

      <form method="post" action="new-order.php" class="submitform">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="submit">
        <label>Plant
          <select name="org">
            <option value="">— choose plant —</option>
            <?php foreach ($orgs as $code => $label): ?>
              <option value="<?= h($code) ?>" <?= $fOrg===$code?'selected':'' ?>><?= h($label) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>PO #
          <span class="pocompose">
            <?php if ($role==='admin'): ?>
              <input type="text" name="branch" value="<?= h($_POST['branch'] ?? '') ?>" size="5"
                     inputmode="numeric" pattern="\d{4}" maxlength="4" placeholder="branch">
            <?php else: ?>
              <span class="fixedbranch"><?= h($branch) ?></span><input type="hidden" name="branch" value="<?= h($branch) ?>">
            <?php endif; ?>
            <span class="dash">–</span>
            <input type="text" name="lot" value="<?= h($fLot) ?>" placeholder="lot / PO number">
          </span>
        </label>
        <label>Shipment Reference # (optional)
          <input type="text" name="shipment_ref" value="<?= h($fShipRef) ?>" placeholder="your shipment / release reference">
        </label>
        <label>Notes (optional)
          <input type="text" name="notes" value="<?= h($fNotes) ?>" placeholder="anything the plant should know">
        </label>
        <label>Requested delivery date (optional)
          <input type="date" name="delivery_date" value="<?= h($fDelivery) ?>" min="<?= h(date('Y-m-d')) ?>">
        </label>
        <label class="urgentcheck">
          <input type="checkbox" name="urgent" value="1" <?= $fUrgent ? 'checked' : '' ?>>
          <span>Mark this order <strong>URGENT</strong> — flags it prominently in the plant's email</span>
        </label>
        <?php if ($role === 'customer'): ?>
          <label>Ship to
            <select name="ship_id">
              <?php foreach ($myShips as $s): ?>
                <option value="<?= (int) $s['id'] ?>" <?= (int) $s['id'] === $defShip ? 'selected' : '' ?>><?= h(ship_address_label($s)) ?></option>
              <?php endforeach; ?>
              <?php if (!$myShips): ?><option value="">— none set —</option><?php endif; ?>
            </select>
          </label>
          <label>Ship method
            <select name="method_id">
              <?php foreach ($myMethods as $m): ?>
                <option value="<?= (int) $m['id'] ?>" <?= (int) $m['id'] === $defMethod ? 'selected' : '' ?>><?= h(ship_method_label($m)) ?></option>
              <?php endforeach; ?>
              <?php if (!$myMethods): ?><option value="">— none set —</option><?php endif; ?>
            </select>
          </label>
          <label>Bill to
            <select name="bill_id">
              <?php foreach ($myBills as $b): ?>
                <option value="<?= (int) $b['id'] ?>" <?= (int) $b['id'] === $defBill ? 'selected' : '' ?>><?= h(bill_address_label($b)) ?></option>
              <?php endforeach; ?>
              <?php if (!$myBills): ?><option value="">— none set —</option><?php endif; ?>
            </select>
          </label>
          <p class="note" style="margin:4px 0 12px;">Manage ship-to, bill-to &amp; ship methods under <a href="settings.php">Settings</a>.</p>
        <?php endif; ?>
        <button type="submit" class="submitbtn" <?= $lines ? '' : 'disabled' ?>>Submit order</button>
      </form>
    </section>
  </div>
</main>
<footer>Thin MVP slice · order entry · email notification is stubbed (roadmap #3) · PHP <?= PHP_VERSION ?></footer>
<script src="datepicker.js"></script>
</body>
</html>
