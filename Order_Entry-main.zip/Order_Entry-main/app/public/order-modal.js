/* "View order" popup — opens a submitted order's details in a themed modal (blurred backdrop)
 * instead of navigating away. Any <a data-order-modal data-order-id="N"> is intercepted; the
 * details are fetched from order-view.php. Degrades gracefully: without JS the link's href
 * (order.php?id=N) still opens the full page.
 */
(function () {
  'use strict';
  var modal, body;

  ready(function () { build(); bind(document); });

  function ready(fn) { document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn); }

  function build() {
    modal = document.createElement('div');
    modal.className = 'vmodal';
    modal.hidden = true;
    modal.innerHTML =
      '<div class="vmodal-backdrop"></div>' +
      '<div class="vmodal-card" role="dialog" aria-modal="true" aria-label="Order details">' +
        '<button type="button" class="vmodal-close" aria-label="Close">&times;</button>' +
        '<div class="vmodal-body"></div>' +
      '</div>';
    document.body.appendChild(modal);
    body = modal.querySelector('.vmodal-body');
    modal.querySelector('.vmodal-backdrop').addEventListener('click', close);
    modal.querySelector('.vmodal-close').addEventListener('click', close);
    document.addEventListener('keydown', function (e) { if (!modal.hidden && e.key === 'Escape') close(); });
  }

  function bind(root) {
    root.querySelectorAll('a[data-order-modal], button[data-order-modal]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        var id = el.getAttribute('data-order-id');
        if (!id) return;
        e.preventDefault();
        openOrder(id);
      });
    });
  }

  function openOrder(id) {
    body.innerHTML = '<div class="vmodal-loading">Loading order…</div>';
    show();
    fetch('order-view.php?id=' + encodeURIComponent(id), { headers: { Accept: 'text/html' } })
      .then(function (r) { return r.text(); })
      .then(function (html) { body.innerHTML = html; })
      .catch(function () { body.innerHTML = '<div class="ov-err">Could not load this order. Please try again.</div>'; });
  }

  function show() {
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(function () { modal.classList.add('open'); });
  }

  function close() {
    modal.classList.remove('open');
    document.body.style.overflow = '';
    setTimeout(function () { if (!modal.classList.contains('open')) modal.hidden = true; }, 200);
  }
})();
