<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/contacts.php';
auth_boot();

$me      = require_login();
$role    = $me['role'];
$isAdmin = $role === 'admin';   // admins edit; everyone else (sales / customers) is view-only

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (!$isAdmin) { http_response_code(403); exit('403 — admin access required.'); }
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        [$ok, $err] = save_program_assignment((int) ($_POST['id'] ?? 0) ?: null, $_POST);
        $_SESSION['flash'] = $ok ? ['ok', 'Contact saved.'] : ['err', $err];
    } elseif ($action === 'delete') {
        delete_program_assignment((int) ($_POST['id'] ?? 0));
        $_SESSION['flash'] = ['info', 'Contact removed.'];
    }
    redirect('contacts.php');
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$q     = trim($_GET['q'] ?? '');
$rows  = list_program_assignments($q);

// Admin edit prefill (Edit links pass ?edit=id).
$edit = null;
if ($isAdmin && isset($_GET['edit'])) $edit = get_program_assignment((int) $_GET['edit']);
$e = fn($k) => h($edit[$k] ?? '');

// Canonical customer picklist for the add/edit form's search/type-ahead (admin only).
$customerNames = $isAdmin ? list_customers() : [];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Contact List — Order Entry</title>
<link rel="stylesheet" href="style.css">
<style>
  /* Customer picklist widget (contacts.php only — keeps out of the shared stylesheet). */
  .customer-field .customer-row { display: flex; gap: .5rem; align-items: center; }
  .customer-field input[type="text"] { flex: 1 1 auto; }
  .customer-field .new-toggle { display: flex; align-items: center; gap: .35rem; font-weight: normal;
    font-size: .85rem; white-space: nowrap; margin: 0; }
  .customer-field .new-toggle input { width: auto; }
  .customer-field .new-customer-wrap { margin-top: .4rem; }
  .customer-field .new-customer-wrap[hidden] { display: none; }
  .customer-field .hint { font-size: .8rem; color: var(--muted, #666); margin-top: .25rem; }
</style>
</head>
<body>
<?php render_header('contacts'); ?>
<main>
  <h1>Contact List
    <span class="sub"><?= $isAdmin ? 'program assignments · admin — add / edit / remove' : 'program assignments · view only' ?></span>
  </h1>

  <?php if ($flash): ?><div class="msg <?= h($flash[0]) ?>"><?= h($flash[1]) ?></div><?php endif; ?>

  <?php if ($isAdmin): ?>
    <!-- Add / edit form (admins only) -->
    <div class="qsection">
      <h2 class="h2"><?= $edit ? 'Edit contact' : 'Add a contact' ?></h2>
      <form method="post" action="contacts.php">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>
        <div class="qgrid">
          <label class="customer-field">Customer
            <div class="customer-row">
              <input type="text" id="customer-input" name="customer" list="customer-datalist"
                     value="<?= $e('customer') ?>" placeholder="Search existing customers…"
                     autocomplete="off" required>
              <label class="new-toggle"><input type="checkbox" id="new-customer-toggle" name="is_new_customer" value="1"> new customer</label>
            </div>
            <datalist id="customer-datalist">
              <?php foreach ($customerNames as $cn): ?><option value="<?= h($cn) ?>"><?php endforeach; ?>
            </datalist>
            <div class="new-customer-wrap" id="new-customer-wrap" hidden>
              <input type="text" id="new-customer-name" name="new_customer_name" placeholder="Exact new customer name…">
              <p class="hint">Adds this name to the canonical customer list — use only for a customer that really isn't in the search above.</p>
            </div>
          </label>
          <label>PM (Program Manager)<input type="text" name="pm" value="<?= $e('pm') ?>"></label>
          <label>Plant Order Inbox <span class="tag">admin only</span>
            <input type="text" name="plant_order_inbox" value="<?= $e('plant_order_inbox') ?>" placeholder="orders@…"></label>
          <label>Plant site<input type="text" name="plant_site" value="<?= $e('plant_site') ?>" placeholder="Little Rock (3908)"></label>
          <label>Sales Contact<input type="text" name="sales_contact" value="<?= $e('sales_contact') ?>"></label>
          <label>Sales Branch<input type="text" name="sales_branch" value="<?= $e('sales_branch') ?>"></label>
          <label>BDM<input type="text" name="bdm" value="<?= $e('bdm') ?>"></label>
        </div>
        <div class="saverow">
          <button type="submit" class="btn-save"><?= $edit ? 'Update contact' : 'Add contact' ?></button>
          <?php if ($edit): ?><a class="btn-sm" href="contacts.php">Cancel edit</a><?php endif; ?>
        </div>
      </form>
    </div>
  <?php endif; ?>

  <form method="get" action="contacts.php" class="searchbar">
    <input type="text" name="q" value="<?= h($q) ?>" placeholder="Search customer, contact, branch, PM, BDM…">
    <button type="submit">Search</button>
    <?php if ($q !== ''): ?><a class="btn-sm" href="contacts.php" style="align-self:center;">Clear</a><?php endif; ?>
  </form>
  <p class="note"><?= count($rows) ?> contact<?= count($rows) === 1 ? '' : 's' ?><?= $q !== '' ? ' matching “' . h($q) . '”' : '' ?></p>

  <div class="tablewrap"><table>
    <thead><tr>
      <th>Customer</th>
      <th>PM</th>
      <?php if ($isAdmin): ?><th>Plant Order Inbox</th><?php endif; ?>
      <th>Plant site</th>
      <th>Sales Contact</th>
      <th>Sales Branch</th>
      <th>BDM</th>
      <?php if ($isAdmin): ?><th></th><?php endif; ?>
    </tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= h($r['customer']) ?></td>
        <td><?= h($r['pm'] ?: '—') ?></td>
        <?php if ($isAdmin): ?><td><?= h($r['plant_order_inbox'] ?: '—') ?></td><?php endif; ?>
        <td><?= h($r['plant_site'] ?: '—') ?></td>
        <td><?= h($r['sales_contact'] ?: '—') ?></td>
        <td><?= h($r['sales_branch'] ?: '—') ?></td>
        <td><?= h($r['bdm'] ?: '—') ?></td>
        <?php if ($isAdmin): ?>
          <td class="right">
            <a class="btn-sm" href="contacts.php?edit=<?= (int) $r['id'] ?>">Edit</a>
            <form class="inline" method="post" action="contacts.php" data-confirm="Remove <?= h($r['customer']) ?>?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
              <button class="btn-sm danger" type="submit">✕</button>
            </form>
          </td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?>
      <tr><td colspan="<?= $isAdmin ? 8 : 6 ?>" class="empty"><?= $q !== '' ? 'No contacts match your search.' : 'No contacts yet.' ?></td></tr>
    <?php endif; ?>
    </tbody>
  </table></div>
</main>
<footer>Contact list · program assignments<?= $isAdmin ? '' : ' · view only' ?> · PHP <?= PHP_VERSION ?></footer>
<?php if ($isAdmin): ?>
<script>
// Toggle between "pick an existing customer" (datalist search) and "add a new customer"
// (explicit, separate field) so a plain typo can't silently become a new customer variant.
(function () {
  var toggle = document.getElementById('new-customer-toggle');
  var wrap   = document.getElementById('new-customer-wrap');
  var existing = document.getElementById('customer-input');
  var fresh  = document.getElementById('new-customer-name');
  if (!toggle) return;
  function sync() {
    var isNew = toggle.checked;
    wrap.hidden = !isNew;
    existing.disabled = isNew;
    existing.required = !isNew;
    fresh.required = isNew;
    if (isNew) fresh.focus(); else existing.focus();
  }
  toggle.addEventListener('change', sync);
  sync();
})();
</script>
<?php endif; ?>
</body>
</html>
