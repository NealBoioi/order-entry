/* Themed date picker — replaces the browser's un-styleable native <input type=date>
 * calendar with an on-brand popup (Wesco charcoal + green). Progressive enhancement:
 * with JS off, the native date input still works. No dependencies.
 *
 * For each input[type=date] it: keeps a hidden input (same name, ISO YYYY-MM-DD value)
 * for the form, turns the visible field into a read-only text trigger showing a friendly
 * date, and opens a custom calendar that respects the input's `min` attribute.
 */
(function () {
  'use strict';
  var MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  var MON = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  var DOW = ['S','M','T','W','T','F','S'];

  function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function iso(y, m, d) { return y + '-' + pad(m + 1) + '-' + pad(d); }          // m is 0-based
  function parseIso(s) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); return m ? { y: +m[1], m: +m[2] - 1, d: +m[3] } : null; }
  function fmtDisplay(p) { return MON[p.m] + ' ' + p.d + ', ' + p.y; }
  function today() { var t = new Date(); return { y: t.getFullYear(), m: t.getMonth(), d: t.getDate() }; }

  ready(function () {
    var dates = document.querySelectorAll('input[type=date]');
    for (var i = 0; i < dates.length; i++) enhance(dates[i]);
  });

  function enhance(src) {
    var name = src.getAttribute('name');
    var minP = parseIso(src.getAttribute('min'));
    var valP = parseIso(src.value);

    // Hidden ISO field that actually submits with the form.
    var hid = document.createElement('input');
    hid.type = 'hidden'; if (name) hid.name = name; hid.value = src.value || '';
    src.parentNode.insertBefore(hid, src.nextSibling);

    // Turn the visible field into a themed read-only trigger.
    src.removeAttribute('name');
    src.type = 'text'; src.readOnly = true; src.autocomplete = 'off';
    src.classList.add('dp-input');
    src.setAttribute('placeholder', src.getAttribute('placeholder') || 'Select a date');
    src.value = valP ? fmtDisplay(valP) : '';
    src.parentNode.classList.add('dp-wrap');

    var pop = document.createElement('div');
    pop.className = 'dp'; pop.hidden = true;
    src.parentNode.appendChild(pop);

    var selected = valP ? { y: valP.y, m: valP.m, d: valP.d } : null;
    var view = valP ? { y: valP.y, m: valP.m } : (minP ? { y: minP.y, m: minP.m } : { y: today().y, m: today().m });

    function beforeMin(y, m, d) { if (!minP) return false; return (y * 10000 + m * 100 + d) < (minP.y * 10000 + minP.m * 100 + minP.d); }

    function render() {
      var t = today();
      var h = '<div class="dp-head"><button type="button" class="dp-nav" data-nav="-1" aria-label="Previous month">‹</button>'
            + '<span class="dp-title">' + MONTHS[view.m] + ' ' + view.y + '</span>'
            + '<button type="button" class="dp-nav" data-nav="1" aria-label="Next month">›</button></div>'
            + '<div class="dp-grid dp-dow">';
      for (var w = 0; w < 7; w++) h += '<span>' + DOW[w] + '</span>';
      h += '</div><div class="dp-grid dp-days">';
      var first = new Date(view.y, view.m, 1).getDay();
      var dim = new Date(view.y, view.m + 1, 0).getDate();
      for (var b = 0; b < first; b++) h += '<span class="dp-empty"></span>';
      for (var d = 1; d <= dim; d++) {
        var cls = 'dp-day';
        if (selected && selected.y === view.y && selected.m === view.m && selected.d === d) cls += ' sel';
        if (t.y === view.y && t.m === view.m && t.d === d) cls += ' today';
        var dis = beforeMin(view.y, view.m, d);
        h += '<button type="button" class="' + cls + (dis ? ' dis' : '') + '" data-d="' + d + '"' + (dis ? ' disabled' : '') + '>' + d + '</button>';
      }
      h += '</div><div class="dp-foot"><button type="button" class="dp-clear" data-act="clear">Clear</button>'
         + '<button type="button" class="dp-today" data-act="today">Today</button></div>';
      pop.innerHTML = h;
    }

    // scrollIntoView: inside scrollable containers (e.g. the pricing edit popup) the
    // calendar can open past the visible edge — nudge the container so it's in view.
    function open() { render(); pop.hidden = false; if (pop.scrollIntoView) pop.scrollIntoView({ block: 'nearest' }); }
    function close() { pop.hidden = true; }
    function changed() { hid.dispatchEvent(new Event('change', { bubbles: true })); }   // user picked/cleared — let page JS react
    function pick(y, m, d) { selected = { y: y, m: m, d: d }; hid.value = iso(y, m, d); src.value = fmtDisplay(selected); view = { y: y, m: m }; close(); changed(); }

    // Programmatic setter for page JS (e.g. auto-filling an expire date from a quote date).
    // Does NOT fire `change` — only real user picks do, so autofill can't loop.
    src.dpSet = function (isoStr) {
      var p = parseIso(isoStr);
      if (!p) return;
      selected = p; hid.value = isoStr; src.value = fmtDisplay(p); view = { y: p.y, m: p.m };
    };

    src.addEventListener('focus', open);
    src.addEventListener('click', open);
    src.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); if (e.key === 'Enter') e.preventDefault(); });

    pop.addEventListener('click', function (e) {
      // Stop the click reaching the document-level outside-click handler below. Nav clicks
      // re-render pop.innerHTML, which detaches e.target — so that handler's pop.contains(e.target)
      // check would read false and wrongly close the calendar. Intentional closes (pick/clear/
      // today) still happen because they call close() directly.
      e.stopPropagation();
      var nav = e.target.closest('[data-nav]');
      if (nav) {
        view.m += +nav.getAttribute('data-nav');
        if (view.m < 0) { view.m = 11; view.y--; }
        if (view.m > 11) { view.m = 0; view.y++; }
        render(); return;
      }
      var act = e.target.closest('[data-act]');
      if (act) {
        if (act.getAttribute('data-act') === 'clear') { selected = null; hid.value = ''; src.value = ''; close(); changed(); }
        else { var td = today(); if (!beforeMin(td.y, td.m, td.d)) pick(td.y, td.m, td.d); }
        return;
      }
      var day = e.target.closest('.dp-day');
      if (day && !day.disabled) pick(view.y, view.m, +day.getAttribute('data-d'));
    });

    document.addEventListener('click', function (e) { if (e.target !== src && !pop.contains(e.target)) close(); });
  }
})();
