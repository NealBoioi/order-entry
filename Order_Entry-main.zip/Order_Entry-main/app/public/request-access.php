<?php
require __DIR__ . '/../src/auth.php';
auth_boot();

if (current_user()) redirect('index.php');

$err = null; $done = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    [$allowed, $retry] = rate_limit_hit('request_access', client_ip(), 6, 3600);   // 6 / hour per IP
    if (!$allowed) {
        $err = 'Too many requests from your network. Please try again later.';
    } else {
        [$ok, $err] = create_access_request($_POST['email'] ?? '', $_POST['branch'] ?? '');
        $done = $ok;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Request access — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="authwrap">
  <div class="brandbig"><svg class="wmark" viewBox="217 219 943 441" xmlns="http://www.w3.org/2000/svg"><path fill="#00AA13" d="M938.2,652.9l221.1-415.8c4.1-7.8-1.5-17.2-10.3-17.2H934.2c-6.2,0-11.8,3.4-14.7,8.9L804.8,444.3l110.9,208.6c2.2,4.2,6.5,6.8,11.2,6.8h0C931.7,659.6,936,657,938.2,652.9z"/><path fill="#00AA13" d="M221.3,237.1l211.1,397.1l115.3-216.9L447.5,228.7c-2.9-5.4-8.6-8.9-14.7-8.9H231.6C222.8,219.9,217.2,229.3,221.3,237.1z"/><path fill="#00AA13" d="M446,659.6h234.3c6.2,0,11.8-3.4,14.7-8.9l109.8-206.5L693.9,235.7c-2.2-4.1-6.5-6.8-11.2-6.8l0,0c-4.7,0-9,2.6-11.2,6.8L446,659.6z"/></svg><span class="brand-text"><b>ASSEMBLIES</b><i>Order Entry</i></span></div>
  <div class="authcard">
    <h1>Request access</h1>
    <p class="lead">A plant admin reviews each request and assigns your role.</p>
    <?php if ($done): ?>
      <div class="msg ok">Thanks — your request is in. An admin will review it and send you a link to set your password.</div>
      <p class="alt"><a href="login.php">Back to sign in</a></p>
    <?php else: ?>
      <?php if ($err): ?><div class="msg err"><?= h($err) ?></div><?php endif; ?>
      <form method="post" action="request-access.php">
        <?= csrf_field() ?>
        <label for="email">Work email</label>
        <input type="email" id="email" name="email" value="<?= h($_POST['email'] ?? '') ?>" autofocus required>
        <label for="branch">Branch # (4 digits)</label>
        <input type="text" id="branch" name="branch" value="<?= h($_POST['branch'] ?? '') ?>"
               inputmode="numeric" pattern="\d{4}" maxlength="4" placeholder="e.g. 1938" required>
        <button type="submit">Request access</button>
      </form>
      <p class="alt">Already approved? <a href="login.php">Sign in</a></p>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
