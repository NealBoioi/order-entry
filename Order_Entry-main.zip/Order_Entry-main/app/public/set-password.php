<?php
require __DIR__ . '/../src/auth.php';
auth_boot();

// Token arrives in the link (GET) and is carried through the POST.
$token = trim($_GET['token'] ?? $_POST['token'] ?? '');
$err = null; $done = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $pw  = $_POST['password'] ?? '';
    $pw2 = $_POST['password2'] ?? '';
    if ($pw !== $pw2) {
        $err = 'The two passwords do not match.';
    } else {
        [$done, $err] = set_password_with_token($token, $pw);
    }
}

$tokenLive = $token !== '' && find_valid_token($token) !== null;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Set your password — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="authwrap">
  <div class="brandbig"><svg class="wmark" viewBox="217 219 943 441" xmlns="http://www.w3.org/2000/svg"><path fill="#00AA13" d="M938.2,652.9l221.1-415.8c4.1-7.8-1.5-17.2-10.3-17.2H934.2c-6.2,0-11.8,3.4-14.7,8.9L804.8,444.3l110.9,208.6c2.2,4.2,6.5,6.8,11.2,6.8h0C931.7,659.6,936,657,938.2,652.9z"/><path fill="#00AA13" d="M221.3,237.1l211.1,397.1l115.3-216.9L447.5,228.7c-2.9-5.4-8.6-8.9-14.7-8.9H231.6C222.8,219.9,217.2,229.3,221.3,237.1z"/><path fill="#00AA13" d="M446,659.6h234.3c6.2,0,11.8-3.4,14.7-8.9l109.8-206.5L693.9,235.7c-2.2-4.1-6.5-6.8-11.2-6.8l0,0c-4.7,0-9,2.6-11.2,6.8L446,659.6z"/></svg><span class="brand-text"><b>ASSEMBLIES</b><i>Order Entry</i></span></div>
  <div class="authcard">
    <h1>Set your password</h1>
    <?php if ($done): ?>
      <div class="msg ok">Password set. You can sign in now.</div>
      <p class="alt"><a href="login.php">Go to sign in</a></p>
    <?php elseif (!$tokenLive): ?>
      <div class="msg err"><?= h($err ?: 'This link is invalid or has expired. Ask an admin for a new one.') ?></div>
      <p class="alt"><a href="login.php">Back to sign in</a></p>
    <?php else: ?>
      <p class="lead">Choose a password — at least 10 characters, with a letter and a number.</p>
      <?php if ($err): ?><div class="msg err"><?= h($err) ?></div><?php endif; ?>
      <form method="post" action="set-password.php">
        <?= csrf_field() ?>
        <input type="hidden" name="token" value="<?= h($token) ?>">
        <label for="password">New password</label>
        <input type="password" id="password" name="password" minlength="10" autofocus required>
        <label for="password2">Confirm password</label>
        <input type="password" id="password2" name="password2" minlength="10" required>
        <button type="submit">Set password</button>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
