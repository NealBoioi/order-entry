<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/profile.php';
auth_boot();
$me = require_admin();

// Target user id comes from ?id= (GET) or the hidden uid on every form (POST).
$id = (int) ($_POST['uid'] ?? $_GET['id'] ?? 0);
$ust = db()->prepare('SELECT id, email, branch, role, status, created_at, approved_at FROM users WHERE id = ?');
$ust->execute([$id]);
$u = $ust->fetch();
if (!$u) { http_response_code(404); exit('404 — user not found.'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    ensure_profile($id);
    switch ($_POST['action'] ?? '') {
        case 'save_profile':
            [$ok, $err] = save_profile_core($id, $_POST, false);
            $_SESSION['flash'] = $ok ? ['ok', 'Profile saved.'] : ['err', $err];
            break;
        case 'save_ship':
            [$ok, $r] = save_ship_address($id, (int) ($_POST['id'] ?? 0) ?: null, $_POST);
            if ($ok && empty(get_profile($id)['default_ship_id']) && count(list_ship_addresses($id)) === 1) set_default_ship($id, (int) $r);
            $_SESSION['flash'] = $ok ? ['ok', 'Ship-to saved.'] : ['err', $r];
            break;
        case 'delete_ship':   delete_ship_address($id, (int) ($_POST['id'] ?? 0)); $_SESSION['flash'] = ['info', 'Ship-to removed.']; break;
        case 'default_ship':  set_default_ship($id, (int) ($_POST['id'] ?? 0));    $_SESSION['flash'] = ['ok', 'Default ship-to updated.']; break;
        case 'save_bill':
            [$ok, $r] = save_bill_address($id, (int) ($_POST['id'] ?? 0) ?: null, $_POST);
            if ($ok && empty(get_profile($id)['default_bill_id']) && count(list_bill_addresses($id)) === 1) set_default_bill($id, (int) $r);
            $_SESSION['flash'] = $ok ? ['ok', 'Bill-to saved.'] : ['err', $r];
            break;
        case 'delete_bill':   delete_bill_address($id, (int) ($_POST['id'] ?? 0)); $_SESSION['flash'] = ['info', 'Bill-to removed.']; break;
        case 'default_bill':  set_default_bill($id, (int) ($_POST['id'] ?? 0));    $_SESSION['flash'] = ['ok', 'Default bill-to updated.']; break;
        case 'save_method':
            [$ok, $r] = save_ship_method($id, (int) ($_POST['id'] ?? 0) ?: null, $_POST);
            if ($ok && empty(get_profile($id)['default_method_id']) && count(list_ship_methods($id)) === 1) set_default_method($id, (int) $r);
            $_SESSION['flash'] = $ok ? ['ok', 'Ship method saved.'] : ['err', $r];
            break;
        case 'delete_method': delete_ship_method($id, (int) ($_POST['id'] ?? 0)); $_SESSION['flash'] = ['info', 'Ship method removed.']; break;
        case 'default_method':set_default_method($id, (int) ($_POST['id'] ?? 0)); $_SESSION['flash'] = ['ok', 'Default ship method updated.']; break;
    }
    redirect('admin-user-account.php?id=' . $id . '#' . ($_POST['anchor'] ?? ''));
}

$flash     = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$profile   = get_profile($id) ?: [];
$ships     = list_ship_addresses($id);
$bills     = list_bill_addresses($id);
$methods   = list_ship_methods($id);
$defShip   = (int) ($profile['default_ship_id'] ?? 0);
$defBill   = (int) ($profile['default_bill_id'] ?? 0);
$defMethod = (int) ($profile['default_method_id'] ?? 0);
$shipEdit  = isset($_GET['ship'])   ? get_ship_address((int) $_GET['ship'])  : null;
$billEdit  = isset($_GET['bill'])   ? get_bill_address((int) $_GET['bill'])  : null;
$methEdit  = isset($_GET['method']) ? get_ship_method((int) $_GET['method']) : null;
if ($shipEdit && (int) $shipEdit['user_id'] !== $id) $shipEdit = null;
if ($billEdit && (int) $billEdit['user_id'] !== $id) $billEdit = null;
if ($methEdit && (int) $methEdit['user_id'] !== $id) $methEdit = null;
$se = fn($f) => h($shipEdit[$f] ?? '');
$be = fn($f) => h($billEdit[$f] ?? '');
$mem = fn($f) => h($methEdit[$f] ?? '');
$uidField = '<input type="hidden" name="uid" value="' . $id . '">';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Account info — <?= h($u['email']) ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('users'); ?>
<main>
  <p class="note"><a href="admin-users.php">← Users</a></p>
  <h1>Account information <span class="sub"><?= h($u['email']) ?> · admin can edit</span></h1>
  <?php if ($flash): ?><div class="msg <?= h($flash[0]) ?>"><?= h($flash[1]) ?></div><?php endif; ?>

  <!-- Account + profile edit -->
  <form method="post" action="admin-user-account.php" class="qsection" id="info">
    <?= csrf_field() ?><?= $uidField ?><input type="hidden" name="action" value="save_profile"><input type="hidden" name="anchor" value="info">
    <h2 class="h2">Account</h2>
    <div class="qgrid">
      <label>Full name<input type="text" name="full_name" value="<?= h($profile['full_name'] ?? '') ?>"></label>
      <label>Title<input type="text" name="title" value="<?= h($profile['title'] ?? '') ?>" placeholder="e.g. Buyer, Inside Sales Rep"></label>
      <label>Email<input type="text" value="<?= h($u['email']) ?>" disabled></label>
      <label>Branch<input type="text" value="<?= h($u['branch'] ?: '—') ?>" disabled></label>
      <label>Role<input type="text" value="<?= h($u['role']) ?>" disabled></label>
      <label>Status<input type="text" value="<?= h($u['status']) ?>" disabled></label>
    </div>
    <div class="saverow"><button type="submit" class="btn-save">Save profile</button>
      <span class="savedtag">Setup <?= !empty($profile['setup_complete']) ? 'complete' : 'not finished' ?> · requested <?= h($u['created_at']) ?></span></div>
  </form>

  <!-- Ship-to addresses -->
  <div class="qsection" id="ship">
    <h2 class="h2">Ship-to addresses (<?= count($ships) ?>)</h2>
    <?php foreach ($ships as $s): $d = (int)$s['id']===$defShip; ?>
      <div class="addrcard <?= $d ? 'isdefault' : '' ?>">
        <div class="ac-head"><span class="ac-label"><?= h($s['label'] ?: 'Ship-to') ?></span><?php if ($d): ?><span class="statuspill active">★ Default</span><?php endif; ?></div>
        <div class="ac-body"><?= h(format_ship_address($s)) ?></div>
        <div class="ac-actions">
          <?php if (!$d): ?><form class="inline" method="post" action="admin-user-account.php"><?= csrf_field().$uidField ?><input type="hidden" name="action" value="default_ship"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><input type="hidden" name="anchor" value="ship"><button class="btn-sm primary" type="submit">Set To Default</button></form><?php endif; ?>
          <a class="btn-sm" href="admin-user-account.php?id=<?= $id ?>&ship=<?= (int)$s['id'] ?>#shipform">Edit</a>
          <form class="inline" method="post" action="admin-user-account.php" data-confirm="Remove this ship-to?"><?= csrf_field().$uidField ?><input type="hidden" name="action" value="delete_ship"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><input type="hidden" name="anchor" value="ship"><button class="btn-sm danger" type="submit">Delete</button></form>
        </div>
      </div>
    <?php endforeach; if (!$ships): ?><p class="empty">None yet.</p><?php endif; ?>
    <h3 class="grouplabel" id="shipform"><?= $shipEdit ? 'Edit ship-to' : 'Add a ship-to' ?></h3>
    <form method="post" action="admin-user-account.php" class="<?= $shipEdit ? 'editing' : '' ?>" style="padding:12px;border-radius:8px;">
      <?= csrf_field().$uidField ?><input type="hidden" name="action" value="save_ship"><input type="hidden" name="anchor" value="ship">
      <?php if ($shipEdit): ?><input type="hidden" name="id" value="<?= (int)$shipEdit['id'] ?>"><?php endif; ?>
      <div class="qgrid">
        <label>Label<input type="text" name="label" value="<?= $se('label') ?>"></label>
        <label>Attention<input type="text" name="attn" value="<?= $se('attn') ?>"></label>
        <label class="wide">Street address *<input type="text" name="addr1" value="<?= $se('addr1') ?>" required></label>
        <label class="wide">Address line 2<input type="text" name="addr2" value="<?= $se('addr2') ?>"></label>
        <label>City *<input type="text" name="city" value="<?= $se('city') ?>" required></label>
        <label>State *<input type="text" name="state" value="<?= $se('state') ?>" required></label>
        <label>ZIP *<input type="text" name="zip" value="<?= $se('zip') ?>" required></label>
        <label>Country<input type="text" name="country" value="<?= $shipEdit ? $se('country') : 'USA' ?>"></label>
      </div>
      <div class="saverow"><button type="submit" class="btn-save"><?= $shipEdit ? 'Update' : 'Add' ?></button><?php if ($shipEdit): ?><a class="btn-sm" href="admin-user-account.php?id=<?= $id ?>#ship">Cancel</a><?php endif; ?></div>
    </form>
  </div>

  <!-- Bill-to addresses -->
  <div class="qsection" id="bill">
    <h2 class="h2">Bill-to addresses (<?= count($bills) ?>)</h2>
    <?php foreach ($bills as $b): $d = (int)$b['id']===$defBill; ?>
      <div class="addrcard <?= $d ? 'isdefault' : '' ?>">
        <div class="ac-head"><span class="ac-label"><?= h($b['label'] ?: ($b['company'] ?: 'Bill-to')) ?></span><?php if ($d): ?><span class="statuspill active">★ Default</span><?php endif; ?></div>
        <div class="ac-body"><?= h(format_bill_address($b)) ?></div>
        <div class="ac-actions">
          <?php if (!$d): ?><form class="inline" method="post" action="admin-user-account.php"><?= csrf_field().$uidField ?><input type="hidden" name="action" value="default_bill"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>"><input type="hidden" name="anchor" value="bill"><button class="btn-sm primary" type="submit">Set To Default</button></form><?php endif; ?>
          <a class="btn-sm" href="admin-user-account.php?id=<?= $id ?>&bill=<?= (int)$b['id'] ?>#billform">Edit</a>
          <form class="inline" method="post" action="admin-user-account.php" data-confirm="Remove this bill-to?"><?= csrf_field().$uidField ?><input type="hidden" name="action" value="delete_bill"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>"><input type="hidden" name="anchor" value="bill"><button class="btn-sm danger" type="submit">Delete</button></form>
        </div>
      </div>
    <?php endforeach; if (!$bills): ?><p class="empty">None yet.</p><?php endif; ?>
    <h3 class="grouplabel" id="billform"><?= $billEdit ? 'Edit bill-to' : 'Add a bill-to' ?></h3>
    <form method="post" action="admin-user-account.php" class="<?= $billEdit ? 'editing' : '' ?>" style="padding:12px;border-radius:8px;">
      <?= csrf_field().$uidField ?><input type="hidden" name="action" value="save_bill"><input type="hidden" name="anchor" value="bill">
      <?php if ($billEdit): ?><input type="hidden" name="id" value="<?= (int)$billEdit['id'] ?>"><?php endif; ?>
      <div class="qgrid">
        <label>Label<input type="text" name="label" value="<?= $be('label') ?>"></label>
        <label class="wide">Company / bill-to name<input type="text" name="company" value="<?= $be('company') ?>"></label>
        <label class="wide">Street address *<input type="text" name="addr1" value="<?= $be('addr1') ?>" required></label>
        <label class="wide">Address line 2<input type="text" name="addr2" value="<?= $be('addr2') ?>"></label>
        <label>City *<input type="text" name="city" value="<?= $be('city') ?>" required></label>
        <label>State *<input type="text" name="state" value="<?= $be('state') ?>" required></label>
        <label>ZIP *<input type="text" name="zip" value="<?= $be('zip') ?>" required></label>
        <label>Country<input type="text" name="country" value="<?= $billEdit ? $be('country') : 'USA' ?>"></label>
      </div>
      <div class="saverow"><button type="submit" class="btn-save"><?= $billEdit ? 'Update' : 'Add' ?></button><?php if ($billEdit): ?><a class="btn-sm" href="admin-user-account.php?id=<?= $id ?>#bill">Cancel</a><?php endif; ?></div>
    </form>
  </div>

  <!-- Ship methods -->
  <div class="qsection" id="method">
    <h2 class="h2">Ship methods (<?= count($methods) ?>)</h2>
    <?php if ($methods): ?>
      <div class="tablewrap"><table>
        <thead><tr><th></th><th>Label</th><th>Terms</th><th>Method</th><th>Carrier acct #</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($methods as $m): ?>
          <tr>
            <td><?php if ((int)$m['id']===$defMethod): ?><span class="statuspill active">★</span><?php else: ?><form class="inline" method="post" action="admin-user-account.php"><?= csrf_field().$uidField ?><input type="hidden" name="action" value="default_method"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><input type="hidden" name="anchor" value="method"><button class="btn-sm" type="submit">Set default</button></form><?php endif; ?></td>
            <td><?= h($m['label'] ?: '—') ?></td><td><?= h($m['terms'] ?: '—') ?></td><td><?= h($m['method'] ?: '—') ?></td><td><?= h($m['carrier_acct'] ?: '—') ?></td>
            <td class="right"><a class="btn-sm" href="admin-user-account.php?id=<?= $id ?>&method=<?= (int)$m['id'] ?>#methodform">Edit</a>
              <form class="inline" method="post" action="admin-user-account.php" data-confirm="Remove?"><?= csrf_field().$uidField ?><input type="hidden" name="action" value="delete_method"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><input type="hidden" name="anchor" value="method"><button class="btn-sm danger" type="submit">✕</button></form></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php else: ?><p class="empty">None yet.</p><?php endif; ?>
    <h3 class="grouplabel" id="methodform"><?= $methEdit ? 'Edit ship method' : 'Add a ship method' ?></h3>
    <form method="post" action="admin-user-account.php" class="<?= $methEdit ? 'editing' : '' ?>" style="padding:12px;border-radius:8px;">
      <?= csrf_field().$uidField ?><input type="hidden" name="action" value="save_method"><input type="hidden" name="anchor" value="method">
      <?php if ($methEdit): ?><input type="hidden" name="id" value="<?= (int)$methEdit['id'] ?>"><?php endif; ?>
      <div class="qgrid">
        <label>Label<input type="text" name="label" value="<?= $mem('label') ?>"></label>
        <label>Shipping terms<input type="text" name="terms" value="<?= $mem('terms') ?>"></label>
        <label>Ship method *<input type="text" name="method" value="<?= $mem('method') ?>" required></label>
        <label>Carrier account #<input type="text" name="carrier_acct" value="<?= $mem('carrier_acct') ?>"></label>
      </div>
      <div class="saverow"><button type="submit" class="btn-save"><?= $methEdit ? 'Update' : 'Add' ?></button><?php if ($methEdit): ?><a class="btn-sm" href="admin-user-account.php?id=<?= $id ?>#method">Cancel</a><?php endif; ?></div>
    </form>
  </div>
</main>
<footer>Admin · edit user account · PHP <?= PHP_VERSION ?></footer>
<script src="address-autocomplete.js?v=3"></script>
</body>
</html>
