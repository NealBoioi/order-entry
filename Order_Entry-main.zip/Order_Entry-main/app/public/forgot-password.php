<?php
require __DIR__ . '/../src/account_mail.php';   // pulls auth.php (session/CSRF) + email helpers
auth_boot();

if (current_user()) redirect('index.php');       // already signed in — nothing to reset here

$sent = false; $err = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = trim($_POST['email'] ?? '');
    [$ipOk] = rate_limit_hit('reset_ip', client_ip(), 8, 900);     // 8 / 15 min per IP
    [$emOk] = rate_limit_hit('reset_email', $email, 4, 900);       // 4 / 15 min per email
    if (!$ipOk || !$emOk) {
        $err = 'You\'ve made several reset requests recently. Please wait a few minutes and try again.';
    } else {
        request_and_send_password_reset($email, app_base_url());
        $sent = true;                             // uniform confirmation (no account enumeration)
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reset password — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="authwrap">
  <div class="brandbig"><svg class="wmark" viewBox="217 219 943 441" xmlns="http://www.w3.org/2000/svg"><path fill="#00AA13" d="M938.2,652.9l221.1-415.8c4.1-7.8-1.5-17.2-10.3-17.2H934.2c-6.2,0-11.8,3.4-14.7,8.9L804.8,444.3l110.9,208.6c2.2,4.2,6.5,6.8,11.2,6.8h0C931.7,659.6,936,657,938.2,652.9z"/><path fill="#00AA13" d="M221.3,237.1l211.1,397.1l115.3-216.9L447.5,228.7c-2.9-5.4-8.6-8.9-14.7-8.9H231.6C222.8,219.9,217.2,229.3,221.3,237.1z"/><path fill="#00AA13" d="M446,659.6h234.3c6.2,0,11.8-3.4,14.7-8.9l109.8-206.5L693.9,235.7c-2.2-4.1-6.5-6.8-11.2-6.8l0,0c-4.7,0-9,2.6-11.2,6.8L446,659.6z"/></svg><span class="brand-text"><b>ASSEMBLIES</b><i>Order Entry</i></span></div>
  <div class="authcard">
    <h1>Reset your password</h1>
    <?php if ($sent): ?>
      <div class="msg ok">If that email has an active account, a password-reset link is on its way.
        The link works once and expires in 72 hours.</div>
      <p class="alt"><a href="login.php">Back to sign in</a></p>
    <?php else: ?>
      <?php if ($err): ?><div class="msg err"><?= h($err) ?></div><?php endif; ?>
      <p class="lead">Enter your account email and we'll send you a link to set a new password.</p>
      <form method="post" action="forgot-password.php">
        <?= csrf_field() ?>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= h($_POST['email'] ?? '') ?>" autofocus required>
        <button type="submit">Send reset link</button>
      </form>
      <p class="alt">Remembered it? <a href="login.php">Sign in</a></p>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
