<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/orders.php';   // allocate_on_hand() + order_date_ts() (PO-card sorting)
auth_boot();

// --- Identity (real session auth; role & branch drive gating and scoping) ---
$me     = require_login();
$role   = $me['role'];            // 'customer' | 'admin'
$branch = $me['branch'];          // 4-digit branch for customers; null for admins
// This page is Order Status search only — the old Price Lookup view (?page=price) moved
// to Components (another worker's page).

// h() is provided by auth.php.

// --- Simplified order status (item 5 of the overhaul) ------------------------------
// The imported RG "Line Status" column (order_lines.line_status) carries whatever raw
// value Oracle used. We collapse it to exactly one of four buyer-facing statuses.
// Matching is case/spacing-insensitive; anything unrecognized displays as-is (grey pill).
const LINE_STATUS_BUCKETS = [
    'Shipped'   => ['closed'],
    'Cancelled' => ['cancelled', 'canceled'],
    'Open'      => ['awaiting shipping', 'entered'],
    'RMA'       => ['awaiting return'],
];
const LINE_STATUS_CLASS = ['Shipped' => 'green', 'Cancelled' => 'red', 'Open' => 'blue', 'RMA' => 'amber'];

// Map a raw line_status value to ['label' => display text, 'class' => pill color].
function map_line_status(?string $raw): array
{
    $norm = strtolower(trim(preg_replace('/\s+/', ' ', (string) $raw)));
    foreach (LINE_STATUS_BUCKETS as $label => $variants) {
        if (in_array($norm, $variants, true)) return ['label' => $label, 'class' => LINE_STATUS_CLASS[$label]];
    }
    $raw = trim((string) $raw);
    return ['label' => $raw !== '' ? $raw : '—', 'class' => 'grey'];
}

// Customer-safe order columns (NO pricing, cost, or scheduled-ship on existing orders).
$CUSTOMER_COLS = [
    'PO #'             => 'customer_po_number',
    'Order #'          => 'order_number',
    'Order Date'       => 'order_date',
    'Item'             => 'ordered_item',
    'Description'      => 'item_description',
    'Ord Qty'          => 'ordered_qty',
    'Ship Qty'         => 'shipped_qty',
    'Line Status'      => 'line_status',
    'Ship Status'      => 'ship_line_status',
    'Tracking #'       => 'tracking_number',
    'Actual Ship'      => 'actual_ship_date',
    'Target Ship Date' => 'promise_date',
    'Request'          => 'request_date',
    'Invoice #'        => 'invoice_number',
    'Invoice Date'     => 'invoice_date',
];
$ADMIN_EXTRA = [
    'Unit Price'  => 'unit_price',
    'Ext Price'   => 'extended_price',
    'Unit Cost'   => 'unit_cost',
    'Sched Ship'  => 'scheduled_ship_date',
    'Plant(Org)'  => 'inventory_org',
];
$cols = $role === 'admin' ? array_merge($CUSTOMER_COLS, $ADMIN_EXTRA) : $CUSTOMER_COLS;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Order Status — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('status'); ?>
<main>
  <?php
    // Multi-field search. Text fields are EXACT, or a LIKE wildcard when they contain "%".
    // The Status filter is one dropdown over the 4 mapped buckets (item 5); the ship-date
    // range and the sorts parse the stored date strings (M/D/YYYY from the export, or ISO
    // from seeds) with STR_TO_DATE.
    $sf = [
      'po'       => trim($_GET['po'] ?? ''),
      'ord'      => trim($_GET['ord'] ?? ''),
      'part'     => trim($_GET['part'] ?? ''),
      'desc'     => trim($_GET['desc'] ?? ''),
      'branch'   => trim($_GET['branch'] ?? ''),
      'status'   => trim($_GET['status'] ?? ''),    // one of LINE_STATUS_BUCKETS keys
      'shipfrom' => trim($_GET['shipfrom'] ?? ''),  // Actual ship date range
      'shipto'   => trim($_GET['shipto'] ?? ''),
    ];
    // Sort: field (po|request|order|actual) + direction (asc|desc); applies to the PO cards.
    $sortBy  = in_array($_GET['sort_by']  ?? '', ['po', 'request', 'order', 'actual'], true) ? $_GET['sort_by']  : 'po';
    $sortDir = (($_GET['sort_dir'] ?? '') === 'desc') ? 'desc' : 'asc';
    $sortDateCol = ['request' => 'request_date', 'order' => 'order_date', 'actual' => 'actual_ship_date'][$sortBy] ?? null;

    // Parse a stored date column tolerant of M/D/YYYY and ISO (column name is code-controlled).
    $dexpr = fn(string $col) => "COALESCE(STR_TO_DATE($col,'%c/%e/%Y'), STR_TO_DATE($col,'%Y-%m-%d'))";

    $hasCriteria = (implode('', [$sf['po'], $sf['ord'], $sf['part'], $sf['desc'], $sf['status'], $sf['shipfrom'], $sf['shipto']]) !== '')
                 || ($role === 'admin' && $sf['branch'] !== '');
    $rows = [];
    if ($hasCriteria) {
        $mk = function (string $col, string $val, array &$c, array &$p) {
            if ($val === '') return;
            $c[] = (strpos($val, '%') !== false) ? "$col LIKE ?" : "$col = ?";
            $p[] = $val;
        };
        $conds = []; $params = [];
        $mk('customer_po_number', $sf['po'], $conds, $params);
        $mk('order_number', $sf['ord'], $conds, $params);
        // Part # is tracked separately for the customer cross-branch rule (§8.1).
        $partCond = null; $partParam = null;
        if ($sf['part'] !== '') {
            $partCond  = (strpos($sf['part'], '%') !== false) ? 'ordered_item LIKE ?' : 'ordered_item = ?';
            $partParam = $sf['part'];
            $conds[] = $partCond; $params[] = $partParam;
        }
        $mk('item_description', $sf['desc'], $conds, $params);
        // Single Status filter — matches ANY raw line_status variant that maps to the chosen
        // bucket. REGEXP_REPLACE collapses internal whitespace runs (mirrors the PHP-side
        // preg_replace in map_line_status()) so matching is case/spacing-insensitive both ways.
        if ($sf['status'] !== '' && isset(LINE_STATUS_BUCKETS[$sf['status']])) {
            $variants = LINE_STATUS_BUCKETS[$sf['status']];
            $conds[]  = "LOWER(TRIM(REGEXP_REPLACE(line_status, '[[:space:]]+', ' '))) IN (" . implode(',', array_fill(0, count($variants), '?')) . ')';
            foreach ($variants as $v) $params[] = $v;
        }
        if ($sf['shipfrom'] !== '') { $conds[] = $dexpr('actual_ship_date') . ' >= ?'; $params[] = $sf['shipfrom']; }
        if ($sf['shipto'] !== '')   { $conds[] = $dexpr('actual_ship_date') . ' <= ?'; $params[] = $sf['shipto']; }

        // Base fetch order is stable (PO, then id) — the PO cards themselves are re-ordered
        // in PHP below per the Sort-by/direction controls, and lines within a card are
        // re-ordered open-first, so this ORDER BY just needs to be deterministic.
        $collist = 'id,' . implode(',', array_values($cols));   // id needed to map allocation
        if (!$conds) {
            $sql = null;                                        // nothing to search on
        } elseif ($role === 'admin') {
            $mk('branch', $sf['branch'], $conds, $params);
            $sql = "SELECT $collist FROM order_lines WHERE " . implode(' AND ', $conds)
                 . " ORDER BY customer_po_number, id";
            $qp  = $params;
        } elseif ($partCond) {
            // Customer WITH a part# search: cross-branch per §8.1 — but ALL filters still apply
            // (previously the cross-branch OR bypassed the status/date filters — fixed).
            $sql = "SELECT $collist FROM order_lines WHERE " . implode(' AND ', $conds)
                 . " ORDER BY customer_po_number, id";
            $qp  = $params;
        } else {
            // Customer, no part#: scoped to their branch; all filters apply.
            $sql = "SELECT $collist FROM order_lines WHERE branch = ? AND " . implode(' AND ', $conds)
                 . " ORDER BY customer_po_number, id";
            $qp  = array_merge([$branch], $params);
        }
        if ($sql !== null) {
            $st = db()->prepare($sql);
            $st->execute($qp);
            $rows = $st->fetchAll();
        }
    }
    // Admin-only: allocate each item's on-hand stock across its open orders by request date.
    $alloc = ($role === 'admin' && $rows) ? allocate_on_hand(array_column($rows, 'ordered_item')) : [];
    $qf = fn($n) => rtrim(rtrim(number_format((float) $n, 2), '0'), '.');

    // Group the filtered lines by PO — one collapsible card per PO (only lines that matched
    // the search/filters are included, so each card shows just the parts under that filter).
    $byPo = [];
    foreach ($rows as $r) { $byPo[$r['customer_po_number'] ?: '—'][] = $r; }

    // Within each PO card: OPEN lines first, then shipped/cancelled/RMA/other (stable order
    // otherwise) — item 6 of the overhaul.
    foreach ($byPo as $po => $lines) {
        usort($lines, function ($a, $b) {
            $ao = map_line_status($a['line_status'])['label'] === 'Open' ? 0 : 1;
            $bo = map_line_status($b['line_status'])['label'] === 'Open' ? 0 : 1;
            return $ao <=> $bo;
        });
        $byPo[$po] = $lines;
    }

    // Sort the PO cards themselves. Cust PO # sorts alphabetically; date fields use the
    // earliest (ascending) or latest (descending) matching date across that PO's lines,
    // via the same tolerant date parser orders.php already uses for on-hand allocation.
    if ($sortBy === 'po') {
        uksort($byPo, fn($a, $b) => $sortDir === 'desc' ? strnatcasecmp($b, $a) : strnatcasecmp($a, $b));
    } else {
        $poKeys = [];
        foreach ($byPo as $po => $lines) {
            $ts = array_map(fn($l) => order_date_ts($l[$sortDateCol] ?? null), $lines);
            $poKeys[$po] = $sortDir === 'desc' ? max($ts) : min($ts);
        }
        uksort($byPo, fn($a, $b) => $sortDir === 'desc' ? ($poKeys[$b] <=> $poKeys[$a]) : ($poKeys[$a] <=> $poKeys[$b]));
    }
  ?>
  <h1 class="centered">Order Status</h1>
  <form method="get" class="ordersearch" id="ordersearch">
    <div class="searchpanel">
      <div class="sf-grid">
        <label>PO #<input type="text" name="po" value="<?= h($sf['po']) ?>"></label>
        <label>Order #<input type="text" name="ord" value="<?= h($sf['ord']) ?>"></label>
        <label>Part #<input type="text" name="part" value="<?= h($sf['part']) ?>" placeholder="e.g. VR-2-ET-G  ·  %123%"></label>
        <label>Description<input type="text" name="desc" value="<?= h($sf['desc']) ?>" placeholder="e.g. %switch%"></label>
        <?php if ($role === 'admin'): ?><label>Branch<input type="text" name="branch" value="<?= h($sf['branch']) ?>"></label><?php endif; ?>
      </div>
      <div class="sf-actions">
        <button type="submit">Search</button>
        <?php if ($hasCriteria): ?><a class="btn-sm" href="index.php">Clear</a><?php endif; ?>
      </div>
      <p class="wildhint">Tip: <code>%</code> is a wildcard. <code>%123%</code> finds any part # <em>containing</em> 123; <code>123%</code> <em>starts-with</em> 123. Without a <code>%</code> the field is an exact match.</p>
    </div>

    <!-- Filter & sort bar — refines the search above; auto-applies on change (falls back to
         the Search button with JS off, since it's the same form). -->
    <div class="filterbar" role="group" aria-label="Filter and sort results">
      <span class="fb-title">Filter &amp; sort</span>
      <label class="fb-field">Status
        <select name="status">
          <option value="">Any</option>
          <?php foreach (array_keys(LINE_STATUS_BUCKETS) as $s): ?><option value="<?= h($s) ?>" <?= $sf['status'] === $s ? 'selected' : '' ?>><?= h($s) ?></option><?php endforeach; ?>
        </select>
      </label>
      <label class="fb-field">Ship date from<input type="date" name="shipfrom" value="<?= h($sf['shipfrom']) ?>"></label>
      <label class="fb-field">Ship date to<input type="date" name="shipto" value="<?= h($sf['shipto']) ?>"></label>
      <label class="fb-field">Sort by
        <select name="sort_by">
          <option value="po"      <?= $sortBy === 'po'      ? 'selected' : '' ?>>Cust PO #</option>
          <option value="request" <?= $sortBy === 'request' ? 'selected' : '' ?>>Request Date</option>
          <option value="order"   <?= $sortBy === 'order'   ? 'selected' : '' ?>>Order Date</option>
          <option value="actual"  <?= $sortBy === 'actual'  ? 'selected' : '' ?>>Actual Ship Date</option>
        </select>
      </label>
      <label class="fb-field">Direction
        <select name="sort_dir">
          <option value="asc"  <?= $sortDir === 'asc'  ? 'selected' : '' ?>>A–Z</option>
          <option value="desc" <?= $sortDir === 'desc' ? 'selected' : '' ?>>Z–A</option>
        </select>
      </label>
      <noscript><button type="submit" class="fb-apply">Apply</button></noscript>
    </div>
  </form>

  <?php if ($hasCriteria): ?>
    <p class="note"><?= count($rows) ?> line(s) across <?= count($byPo) ?> order(s).
      <?php if ($role==='customer'): ?><span class="tag">pricing &amp; cost hidden for customers</span><?php endif; ?>
    </p>
    <?php if ($rows): ?>
      <?php
        // Labeled fields shown in each order card's body grid (role-gated: admins also see
        // pricing/cost/scheduled-ship/plant per §8.2). The header carries PO/Order/status/item.
        $gridFields = [
          'Ordered Qty' => 'ordered_qty', 'Shipped Qty' => 'shipped_qty',
          'Tracking #'  => 'tracking_number', 'Actual Ship' => 'actual_ship_date',
          'Target Ship Date' => 'promise_date', 'Request' => 'request_date',
          'Invoice #'   => 'invoice_number', 'Invoice Date' => 'invoice_date',
        ];
        if ($role === 'admin') $gridFields += [
          'Plant (Org)' => 'inventory_org', 'Unit Price' => 'unit_price',
          'Ext Price'   => 'extended_price', 'Unit Cost' => 'unit_cost',
          'Sched Ship'  => 'scheduled_ship_date',
        ];
        $money = ['unit_price', 'extended_price', 'unit_cost'];
      ?>
      <div class="order-results">
      <?php foreach ($byPo as $po => $lines): $first = $lines[0]; ?>
        <?php
          // Status pill summary for the collapsed summary row, e.g. "3 Open · 1 Shipped"
          // (rendered as separate color-coded pills, Open-first to match the line ordering).
          // Count by label + mapped class together, so an UNMAPPED raw value that happens to
          // equal a bucket name (e.g. raw "Shipped" vs the mapped Closed→Shipped) keeps its
          // grey shown-as-is pill instead of borrowing the bucket's color.
          $counts = [];
          foreach ($lines as $r) {
              $m = map_line_status($r['line_status']);
              $key = $m['label'] . '|' . $m['class'];
              $counts[$key] = ($counts[$key] ?? 0) + 1;
          }
          uksort($counts, fn($a, $b) => (strtok($a, '|') === 'Open' ? 0 : 1) <=> (strtok($b, '|') === 'Open' ? 0 : 1));
        ?>
        <details class="po-card">
          <summary class="po-head">
            <span class="po-caret" aria-hidden="true">&#9656;</span>
            <div class="po-head-main">
              <span class="po-no"><?= h($po) ?></span>
              <span class="po-sub">Order #<?= h($first['order_number'] ?: '—') ?><?php if (!empty($first['order_date'])): ?> · <?= h($first['order_date']) ?><?php endif; ?></span>
            </div>
            <div class="po-head-meta">
              <span class="po-linecount"><?= count($lines) ?> line<?= count($lines) === 1 ? '' : 's' ?></span>
              <span class="po-pills">
                <?php foreach ($counts as $key => $n): [$label, $cls] = explode('|', $key, 2); ?><span class="ocs ocs-<?= h($cls) ?>"><?= $n ?> <?= h($label) ?></span><?php endforeach; ?>
              </span>
            </div>
          </summary>
          <div class="po-body">
          <?php foreach ($lines as $r): $st = map_line_status($r['line_status']); ?>
            <div class="po-line">
              <div class="pl-top">
                <div class="pl-id">
                  <span class="pl-item"><?= h($r['ordered_item'] ?: '—') ?></span>
                  <?php if (!empty($r['item_description'])): ?><span class="pl-desc"><?= h($r['item_description']) ?></span><?php endif; ?>
                </div>
                <div class="pl-status">
                  <span class="ocs ocs-<?= $st['class'] ?>"><?= h($st['label']) ?></span>
                </div>
              </div>
              <div class="oc-grid">
                <?php foreach ($gridFields as $label => $f):
                    $v = (string) ($r[$f] ?? '');
                    if (in_array($f, $money, true) && $v !== '' && is_numeric($v)) $v = '$' . number_format((float) $v, 2);
                    $empty = ($v === '');
                    $mono  = ($f === 'tracking_number');
                ?>
                  <div class="oc-cell">
                    <span class="oc-lbl"><?= h($label) ?></span>
                    <span class="oc-val<?= $empty ? ' empty' : '' ?><?= $mono ? ' mono' : '' ?>"><?= h($empty ? '—' : $v) ?></span>
                  </div>
                <?php endforeach; ?>
              </div>
              <?php if ($role === 'admin' && isset($alloc[$r['id']])): $a = $alloc[$r['id']]; ?>
                <?php if ($a['on_hand'] === null): ?>
                  <div class="oc-alloc none">Stock: <span class="muted">no on-hand qty in the daily file</span></div>
                <?php else: $covered = $a['shortfall'] <= 0; ?>
                  <div class="oc-alloc <?= $covered ? 'ok' : 'short' ?>">
                    On hand <b><?= $qf($a['on_hand']) ?></b>
                    · <b><?= $qf($a['avail_before']) ?></b> available for this order (need <?= $qf($a['remaining']) ?>)
                    <?php if ($covered): ?><span class="pill ok">covered from stock</span>
                    <?php else: ?><span class="pill short">short <?= $qf($a['shortfall']) ?></span><?php endif; ?>
                  </div>
                <?php endif; ?>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
          </div>
        </details>
      <?php endforeach; ?>
      </div>
    <?php else: ?><p class="empty">No matching orders.</p><?php endif; ?>
  <?php endif; ?>
</main>
<footer>Thin MVP slice · PHP <?= PHP_VERSION ?> · auth/email &amp; New Order come next</footer>
<script src="datepicker.js"></script>
<script>
// Filter/sort bar auto-applies: any change (dropdowns, or a date pick — datepicker.js fires
// a bubbling `change` on its hidden input) re-runs the search, preserving the text fields.
(function () {
  var bar = document.querySelector('.filterbar');
  if (!bar) return;
  var form = document.getElementById('ordersearch');
  bar.addEventListener('change', function () { if (form) form.submit(); });
})();
</script>
</body>
</html>
