<?php
// Quotes landing = Search or Create (overhaul spec, Batch 2). Two panels:
//   (a) SEARCH saved quotes by Quote #, Customer, or Part # (app-wide wildcard rule: exact
//       unless the term contains "%", then LIKE) — results carry an Edit button into the
//       workspace (quote.php), whose existing save-all already up-revs + records changes,
//       satisfying "editing up-revs the quote" without any extra plumbing here.
//   (b) CREATE a quote — minimal Customer / Assembly Plant / Part # form that calls straight
//       through to src/quotes.php's create_quote() (assigns the Q-number) + update_quote()
//       (to store the chosen plant, since create_quote() only takes customer + part), then
//       redirects into the workspace.
// Admin-only (quoting is plant-side; cost/margin data — see quote.php — never reaches
// customers per §8.2).
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/quotes.php';
require __DIR__ . '/../src/contacts.php';   // list_customers() — canonical customer dropdown
auth_boot();
$me = require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $customer = trim($_POST['customer'] ?? '');
        $org      = trim($_POST['inventory_org'] ?? '');
        $part     = trim($_POST['part_number'] ?? '');
        if ($customer === '' && $part === '') {
            $_SESSION['flash'] = ['err', 'Choose a customer or enter a part number to start a quote.'];
            redirect('quotes.php');
        }
        $id = create_quote($me['id'], $customer, $part);
        if ($org !== '') update_quote($id, ['inventory_org' => $org]);   // create_quote() has no org param
        redirect('quote.php?id=' . $id);
    }
    if ($action === 'delete') {
        delete_quote((int) ($_POST['id'] ?? 0));
        $_SESSION['flash'] = ['info', 'Quote deleted.'];
        redirect('quotes.php');
    }
}

// --- Search (built here — list_quotes() in src/quotes.php doesn't join the plant name and
// takes no filters, so the search query lives with the page that needs it). Same app-wide
// wildcard rule as everywhere else: exact match unless the term contains "%".
function quotes_search(string $quoteNo, string $customer, string $part, int $limit): array
{
    $conds = []; $params = [];
    $add = function (string $col, string $val) use (&$conds, &$params) {
        $val = trim($val);
        if ($val === '') return;
        $conds[] = (strpos($val, '%') !== false) ? "$col LIKE ?" : "$col = ?";
        $params[] = $val;
    };
    $add('q.quote_number', $quoteNo);
    $add('q.customer', $customer);
    $add('q.part_number', $part);

    $sql = 'SELECT q.id, q.quote_number, q.quote_id, q.customer, q.part_number, q.revision,
                   q.inventory_org, q.created_at, g.name AS plant_name
            FROM quotes q
            LEFT JOIN orgs g ON g.inventory_org = q.inventory_org';
    if ($conds) $sql .= ' WHERE ' . implode(' AND ', $conds);
    $sql .= ' ORDER BY q.created_at DESC, q.id DESC LIMIT ' . max(1, (int) $limit);
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

$fQn   = trim($_GET['qn']   ?? '');
$fCust = trim($_GET['cust'] ?? '');
$fPart = trim($_GET['part'] ?? '');
$hasCriteria = ($fQn !== '' || $fCust !== '' || $fPart !== '');

// Default state (no search yet) shows the 15 most recent quotes so the page isn't empty;
// an active search returns up to 200 matches.
$quotes = quotes_search($fQn, $fCust, $fPart, $hasCriteria ? 200 : 15);

$orgs      = db()->query('SELECT inventory_org, name FROM orgs ORDER BY name')->fetchAll();
$customers = list_customers();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quotes — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php render_header('quotes'); ?>
<main>
  <h1>Quotes <span class="sub">search saved quotes or start a new one — admin/quoting only</span></h1>

  <?php if ($flash): ?><div class="msg <?= h($flash[0]) ?>"><?= h($flash[1]) ?></div><?php endif; ?>

  <div class="grid2">
    <!-- Left: search saved quotes -->
    <section>
      <h2 class="h2">Search quotes</h2>
      <form method="get" action="quotes.php" class="searchpanel">
        <div class="sf-grid">
          <label>Quote #<input type="text" name="qn" value="<?= h($fQn) ?>" placeholder="e.g. Q-2026-0001"></label>
          <label>Customer<input type="text" name="cust" value="<?= h($fCust) ?>" placeholder="e.g. %TKE%"></label>
          <label>Part #<input type="text" name="part" value="<?= h($fPart) ?>" placeholder="e.g. 320FP23,00"></label>
        </div>
        <div class="sf-actions">
          <button type="submit">Search</button>
          <?php if ($hasCriteria): ?><a class="btn-sm" href="quotes.php">Clear</a><?php endif; ?>
        </div>
        <p class="wildhint">Tip: <code>%</code> is a wildcard. <code>%320%</code> finds any part # <em>containing</em> 320. Without a <code>%</code> a field is an exact match.</p>
      </form>
    </section>

    <!-- Right: start a new quote -->
    <section>
      <h2 class="h2">Create a quote</h2>
      <form method="post" action="quotes.php" class="card">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <div class="qgrid">
          <label>Customer
            <select name="customer">
              <option value="">— Select customer —</option>
              <?php foreach ($customers as $c): ?>
                <option value="<?= h($c) ?>"><?= h($c) ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <label>Assembly Plant
            <select name="inventory_org">
              <option value="">—</option>
              <?php foreach ($orgs as $o): ?>
                <option value="<?= h($o['inventory_org']) ?>"><?= h($o['name']) ?> (<?= h($o['inventory_org']) ?>)</option>
              <?php endforeach; ?>
            </select>
          </label>
          <label class="wide">Part number<input type="text" name="part_number" placeholder="e.g. 320FP23,00"></label>
        </div>
        <p class="note" style="margin:12px 0 0;">A quote number is assigned automatically — the new quote opens straight into the workspace.</p>
        <button type="submit" class="btn-sm primary" style="margin-top:10px;">Create quote</button>
      </form>
    </section>
  </div>

  <h2 class="h2" style="margin-top:22px;"><?= $hasCriteria ? count($quotes) . ' match(es)' : 'Recent quotes' ?></h2>
  <?php if (!$quotes): ?>
    <p class="empty">No quotes found<?= $hasCriteria ? ' for that search.' : ' yet — create one above.' ?></p>
  <?php else: ?>
    <div class="tablewrap"><table>
      <thead><tr>
        <th>Quote #</th><th>Customer</th><th>Plant</th><th>Part #</th><th>Rev</th><th>Quote date</th><th></th>
      </tr></thead>
      <tbody>
      <?php foreach ($quotes as $q): ?>
        <tr>
          <td><?= h($q['quote_number'] ?: $q['quote_id'] ?: ('#' . $q['id'])) ?></td>
          <td><?= h($q['customer'] ?: '—') ?></td>
          <td><?= $q['plant_name'] ? h($q['plant_name'] . ' (' . $q['inventory_org'] . ')') : '<span class="muted">—</span>' ?></td>
          <td><?= h($q['part_number'] ?: '—') ?></td>
          <td><?= h($q['revision'] ?: '—') ?></td>
          <td><?= h(date('n/j/Y', strtotime($q['created_at']))) ?></td>
          <td class="right">
            <a class="btn-sm primary" href="quote.php?id=<?= (int) $q['id'] ?>">Edit</a>
            <form class="inline" method="post" action="quotes.php" data-confirm="Delete this quote and all its BOM/cost data?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int) $q['id'] ?>">
              <button class="btn-sm danger" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  <?php endif; ?>
</main>
<footer>Quoting module (Phase 2) · search or create · PHP <?= PHP_VERSION ?></footer>
</body>
</html>
