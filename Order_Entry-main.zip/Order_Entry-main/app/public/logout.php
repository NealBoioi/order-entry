<?php
require __DIR__ . '/../src/auth.php';
auth_boot();
// POST-only so a stray GET / prefetch can't log the user out.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    logout();
}
redirect('login.php');
