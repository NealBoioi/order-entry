<?php
// Components — EXPERIMENTAL quoting aid (re-scoped 2026-07-15 per Neal): RAW MATERIAL /
// component lookup only. Prices come straight from the item warehouse daily file (list
// price + frozen cost); per-plant availability from the "Material Stats" daily import
// (app/src/import.php: import_material_stats(), §34). Assemblies (WES-ETO) are deliberately
// EXCLUDED — assemblies are priced on the Quote page and ordered on New Order; this page
// exists to make component sourcing during quoting easier.
//
// ADMIN-ONLY: it's a quoting/plant-side tool carrying buy-item pricing + cost data (§8.2
// forbids exposing any of that to customer accounts anyway).
//
// Future direction (Neal, 2026-07-15): augment with authorized spot-market distributors
// (DigiKey, Mouser, RS, Master Electronics) and manufacturer availability via their product
// APIs — and if it proves out, surface the same lookup inside the quote page itself.
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/header.php';
require __DIR__ . '/../src/pricing.php';   // search_items() — also pulls in db.php
auth_boot();

$me   = require_admin();
$role = 'admin';

// Per-plant availability for a set of item numbers, from the material_stats daily import.
// Returns [item_number => [ row, row, ... ] ] each row keyed by org, sorted by org.
function material_stats_for_items(array $itemNumbers): array
{
    $itemNumbers = array_values(array_unique(array_filter($itemNumbers, fn($v) => trim((string) $v) !== '')));
    if (!$itemNumbers) return [];
    $ph = implode(',', array_fill(0, count($itemNumbers), '?'));
    $st = db()->prepare(
        "SELECT item_number, org, qty, uom, demand, excess, aged, months_inactive
         FROM material_stats
         WHERE item_number IN ($ph)
         ORDER BY item_number, org"
    );
    $st->execute($itemNumbers);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $out[$r['item_number']][] = $r;
    }
    return $out;
}

// Components not in the item price master at all (no item_type / no pricing — e.g. a raw
// material tracked only in Material Stats) still need to show up here so plant availability
// is visible across ALL components, not just priced ones. Same wildcard rule as search_items().
// No pricing/cost data exists on these rows at all, so there's nothing to gate by role (§8.2
// only restricts PRICE/COST exposure — availability qty is fine for every role).
function search_material_only_items(string $partNo, string $desc, array $exclude): array
{
    $conds = []; $params = [];
    $add = function (string $col, string $val) use (&$conds, &$params) {
        $val = trim($val);
        if ($val === '') return;
        $conds[] = (strpos($val, '%') !== false) ? "$col LIKE ?" : "$col = ?";
        $params[] = $val;
    };
    $add('item_number', $partNo);
    $add('description', $desc);
    if (!$conds) return [];

    $sql = 'SELECT item_number, MIN(description) AS description
            FROM material_stats WHERE ' . implode(' AND ', $conds);
    if ($exclude) {
        $sql .= ' AND item_number NOT IN (' . implode(',', array_fill(0, count($exclude), '?')) . ')';
        $params = array_merge($params, $exclude);
    }
    $sql .= ' GROUP BY item_number ORDER BY item_number LIMIT 50';
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

$part = trim($_GET['part'] ?? $_GET['item'] ?? '');
$desc = trim($_GET['desc'] ?? '');
$qty  = max(1, (int) ($_GET['qty'] ?? 1));
$hasCriteria = ($part !== '' || $desc !== '');
// Raw materials only — assemblies (WES-ETO) are quoted/ordered elsewhere and have no
// warehouse price by definition (two-source pricing, §8.1).
$matches      = $hasCriteria
    ? array_values(array_filter(search_items($part, $desc, $role), fn($it) => $it['item_type'] !== 'WES-ETO'))
    : [];
$materialOnly = $hasCriteria ? search_material_only_items($part, $desc, array_column($matches, 'item_number')) : [];
$avail = $hasCriteria
    ? material_stats_for_items(array_merge(array_column($matches, 'item_number'), array_column($materialOnly, 'item_number')))
    : [];
$totalFound = count($matches) + count($materialOnly);

// Renders the "Availability by plant" block shared by priced and material-only cards.
function render_availability(array $rows, string $role): void
{
    ?>
    <div class="availgrid">
      <p class="availgrid-title">Availability by plant</p>
      <?php if ($rows): ?>
        <table class="availtable">
          <thead>
            <tr>
              <th>Plant (Org)</th>
              <th class="num">On hand</th>
              <th>UOM</th>
              <th class="num">Demand</th>
              <th class="num">Excess</th>
              <?php if ($role === 'admin'): ?>
                <th class="num">Aged</th>
                <th class="num">Mo. inactive</th>
              <?php endif; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td><?= h($r['org']) ?></td>
                <td class="num"><?= $r['qty'] !== null ? number_format((float) $r['qty'], 2) : '—' ?></td>
                <td><?= h($r['uom'] ?: '—') ?></td>
                <td class="num"><?= $r['demand'] !== null ? number_format((float) $r['demand'], 2) : '—' ?></td>
                <td class="num"><?= $r['excess'] !== null ? number_format((float) $r['excess'], 2) : '—' ?></td>
                <?php if ($role === 'admin'): ?>
                  <td class="num"><?= $r['aged'] !== null ? number_format((float) $r['aged'], 2) : '—' ?></td>
                  <td class="num"><?= $r['months_inactive'] !== null ? number_format((float) $r['months_inactive'], 1) : '—' ?></td>
                <?php endif; ?>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <p class="availnone">No plant availability data for this item in today's Material Stats file.</p>
      <?php endif; ?>
    </div>
    <?php
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Components — Order Entry</title>
<link rel="stylesheet" href="style.css">
<style>
  /* Per-plant availability grid — reuses the site's card/dl look, adds a compact table. */
  .availgrid { margin-top: 14px; border-top: 1px solid var(--line); padding-top: 12px; }
  .availgrid-title { font-size: 12px; font-weight: 700; color: var(--slate-2); text-transform: uppercase;
                      letter-spacing: .03em; margin: 0 0 8px; }
  .availtable { width: 100%; border-collapse: collapse; font-size: 13.5px; }
  .availtable th, .availtable td { text-align: left; padding: 6px 10px; border-bottom: 1px solid var(--line); }
  .availtable th { color: var(--slate-2); font-weight: 600; font-size: 12px; text-transform: uppercase; letter-spacing: .02em; }
  .availtable td.num, .availtable th.num { text-align: right; font-variant-numeric: tabular-nums; }
  .availtable tr:last-child td { border-bottom: none; }
  .availnone { color: var(--slate); font-size: 13px; margin: 6px 0 0; }
</style>
</head>
<body>
<?php render_header('components'); ?>
<main>
  <h1 class="centered">Components</h1>
  <form method="get" class="searchpanel">
    <input type="hidden" name="page" value="components">
    <div class="sf-grid">
      <label>Part #<input type="text" name="part" value="<?= h($part) ?>" placeholder="e.g. 320FP23  ·  %VR%"></label>
      <label>Description<input type="text" name="desc" value="<?= h($desc) ?>" placeholder="e.g. %valve%"></label>
      <label>Qty<input type="number" name="qty" value="<?= h($qty) ?>" min="1"></label>
    </div>
    <div class="sf-actions">
      <button type="submit">Look up</button>
      <?php if ($hasCriteria): ?><a class="btn-sm" href="components.php">Clear</a><?php endif; ?>
    </div>
    <p class="wildhint">Tip: <code>%</code> is a wildcard. <code>%VR%</code> finds any part <em>containing</em> VR. Without a <code>%</code> the field is an exact match.</p>
  </form>

  <?php if ($hasCriteria): ?>
    <p class="note"><?= $totalFound ?> item(s) found
      <span class="tag">raw materials / components only — assemblies are priced on the Quote page</span>
    </p>
    <?php if (!$totalFound): ?>
      <p class="empty">No matching items.</p>
    <?php endif; ?>
    <?php foreach ($matches as $it):
        $rows = $avail[$it['item_number']] ?? [];
    ?>
      <div class="card">
        <div class="card-head">
          <div class="itemno"><?= h($it['item_number']) ?></div>
          <span class="badge">Buy item</span>
          <?php // Component pricing = the item warehouse daily file, nothing else. ?>
          <?php if ($it['list_price'] !== null): ?>
            <div class="price">$<?= number_format((float) $it['list_price'], 4) ?> <span class="ea">/ ea</span>
              <span class="ext">× <?= $qty ?> = <strong>$<?= number_format((float) $it['list_price'] * $qty, 2) ?></strong></span></div>
          <?php else: ?>
            <div class="price bad">No list price in the daily file</div>
          <?php endif; ?>
        </div>
        <div class="desc"><?= h($it['description']) ?></div>
        <dl>
          <dt>UOM</dt><dd><?= h($it['primary_uom'] ?: '—') ?></dd>
          <dt>Status</dt><dd><?= h($it['item_status'] ?: '—') ?></dd>
          <dt>MOQ</dt><dd><?= h($it['min_order_qty'] ?: '—') ?></dd>
          <dt>FLM</dt><dd><?= h($it['flm'] ?: '—') ?></dd>
          <dt>Lead time</dt><dd><?= $it['cumulative_lead_time'] !== null ? (int) $it['cumulative_lead_time'] . ' days' : '—' ?></dd>
          <dt>Supplier</dt><dd><?= h($it['supplier'] ?: '—') ?></dd>
          <dt>SIM</dt><dd><?= h($it['sim_number'] ?: '—') ?></dd>
          <dt>Supplier Item</dt><dd><?= h($it['supplier_item'] ?: '—') ?></dd>
          <?php if ($role === 'admin'): ?>
            <!-- Cost data is ADMIN-only (§8.2 — never shown to customer accounts). -->
            <dt>Frozen cost</dt><dd><?= $it['frozen_cost'] !== null ? '$' . number_format((float) $it['frozen_cost'], 4) . ' / unit' : '—' ?></dd>
          <?php endif; ?>
        </dl>

        <?php render_availability($rows, $role); ?>
      </div>
    <?php endforeach; ?>

    <?php foreach ($materialOnly as $mo): $rows = $avail[$mo['item_number']] ?? []; ?>
      <div class="card">
        <div class="card-head">
          <div class="itemno"><?= h($mo['item_number']) ?></div>
          <span class="badge">Availability only</span>
        </div>
        <div class="desc"><?= h($mo['description'] ?: '—') ?>
          <span class="note" style="display:block;margin:2px 0 0;">Not in the item price master — no pricing available; plant availability shown below.</span>
        </div>
        <?php render_availability($rows, $role); ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</main>
<footer>Components · PHP <?= PHP_VERSION ?></footer>
</body>
</html>
