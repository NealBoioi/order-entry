<?php
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/profile.php';
auth_boot();

$me     = require_login();          // exempt from the setup gate (see require_login)
$uid    = (int) $me['id'];
$branch = (string) ($me['branch'] ?? '');
$err    = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (empty($_POST['bill_confirm'])) {
        $err = 'Please verify your bill-to address to finish.';
    } else {
        ensure_profile($uid);
        [$ok, $err] = save_profile_core($uid, $_POST, false);
        if ($ok) {
            $sp = $_POST; if (trim($sp['ship_label'] ?? '') === '') $sp['label'] = 'Default';
            [$sok, $sid] = save_ship_address($uid, null, $sp);
            $bp = $_POST; $bp['label'] = 'Default';                 // bill fields are bill_*
            [$bok, $bid] = save_bill_address($uid, null, $bp);
            if (!$sok)      { $err = $sid; }
            elseif (!$bok)  { $err = $bid; }
            else {
                set_default_ship($uid, (int) $sid);
                set_default_bill($uid, (int) $bid);
                if (trim($_POST['method'] ?? '') !== '') {
                    $mp = $_POST; if (trim($mp['label'] ?? '') === '') $mp['label'] = 'Default';
                    [$mok, $mid] = save_ship_method($uid, null, $mp);
                    if ($mok) set_default_method($uid, (int) $mid);
                }
                set_setup_complete($uid);
                redirect('index.php?welcome=1');
            }
        }
    }
}

$profile     = get_profile($uid) ?: [];
$firstShip   = list_ship_addresses($uid)[0] ?? [];
$firstBill   = list_bill_addresses($uid)[0] ?? [];
$firstMethod = list_ship_methods($uid)[0] ?? [];
$bv = fn($x) => h($_POST['bill_' . $x] ?? $firstBill[$x] ?? '');
$sv = fn($x) => h($_POST['ship_' . $x] ?? $firstShip[$x] ?? '');
$mv = fn($x) => h($_POST[$x] ?? $firstMethod[$x] ?? '');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Complete your account — Order Entry</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <div class="brand">Order<span>Entry</span></div>
  <div class="usr">
    <span class="who"><?= h($me['email']) ?></span>
    <?php if ($branch): ?><span class="rolechip">branch <?= h($branch) ?></span><?php endif; ?>
    <form class="inline" method="post" action="logout.php"><?= csrf_field() ?><a href="#" onclick="this.closest('form').submit();return false;">Sign out</a></form>
  </div>
</header>
<main>
  <h1>Complete your account setup <span class="sub">so your orders fill in automatically</span></h1>
  <div class="msg info">Your account was approved. Finish setup below to start entering orders — you can change any of this later under Settings.</div>
  <?php if ($err): ?><div class="msg err"><?= h($err) ?></div><?php endif; ?>

  <form method="post" action="account-setup.php">
    <?= csrf_field() ?>

    <div class="qsection">
      <h2 class="h2">Your info</h2>
      <div class="qgrid">
        <label>Full name *<input type="text" name="full_name" value="<?= h($_POST['full_name'] ?? $profile['full_name'] ?? '') ?>" required></label>
        <label>Title<input type="text" name="title" value="<?= h($_POST['title'] ?? $profile['title'] ?? '') ?>" placeholder="e.g. Buyer, Inside Sales Rep, Outside Sales Rep"></label>
        <label>Branch<input type="text" value="<?= h($branch) ?>" disabled></label>
      </div>
    </div>

    <div class="qsection">
      <h2 class="h2">Bill-to location <span class="subnote">Verify Bill-To-Address Below. Will Auto-Populate On Future Orders</span></h2>
      <div class="qgrid">
        <label class="wide">Company / bill-to name<input type="text" name="bill_company" value="<?= $bv('company') ?>"></label>
        <label class="wide">Street address<input type="text" name="bill_addr1" value="<?= $bv('addr1') ?>"></label>
        <label class="wide">Address line 2<input type="text" name="bill_addr2" value="<?= $bv('addr2') ?>"></label>
        <label>City<input type="text" name="bill_city" value="<?= $bv('city') ?>"></label>
        <label>State<input type="text" name="bill_state" value="<?= $bv('state') ?>"></label>
        <label>ZIP<input type="text" name="bill_zip" value="<?= $bv('zip') ?>"></label>
        <label>Country<input type="text" name="bill_country" value="<?= h($_POST['bill_country'] ?? $firstBill['country'] ?? 'USA') ?>"></label>
      </div>
      <label class="confirmline"><input type="checkbox" name="bill_confirm" value="1" <?= !empty($_POST['bill_confirm']) ? 'checked' : '' ?>>
        I've verified this bill-to address.</label>
    </div>

    <div class="qsection">
      <h2 class="h2">Ship-to location <span class="subnote">where your orders are delivered (you can add more later)</span></h2>
      <div class="qgrid">
        <label>Attention / recipient<input type="text" name="ship_attn" value="<?= $sv('attn') ?>" placeholder="e.g. Receiving Dept"></label>
        <label class="wide">Street address *<input type="text" name="ship_addr1" value="<?= $sv('addr1') ?>" required></label>
        <label class="wide">Address line 2<input type="text" name="ship_addr2" value="<?= $sv('addr2') ?>"></label>
        <label>City *<input type="text" name="ship_city" value="<?= $sv('city') ?>" required></label>
        <label>State *<input type="text" name="ship_state" value="<?= $sv('state') ?>" required></label>
        <label>ZIP *<input type="text" name="ship_zip" value="<?= $sv('zip') ?>" required></label>
        <label>Country<input type="text" name="ship_country" value="<?= h($_POST['ship_country'] ?? $firstShip['country'] ?? 'USA') ?>"></label>
      </div>
    </div>

    <div class="qsection">
      <h2 class="h2">Ship method <span class="subnote">your default — auto-fills on future orders</span></h2>
      <div class="qgrid">
        <label>Shipping terms<input type="text" name="terms" value="<?= $mv('terms') ?>" placeholder="e.g. Prepaid &amp; Add, Collect"></label>
        <label>Ship method<input type="text" name="method" value="<?= $mv('method') ?>" placeholder="e.g. UPS Ground, R&amp;L Freight"></label>
        <label>Carrier account #<input type="text" name="carrier_acct" value="<?= $mv('carrier_acct') ?>"></label>
      </div>
    </div>

    <div class="saverow"><button type="submit" class="btn-save">Finish setup</button></div>
  </form>
</main>
<footer>Account setup · ship-to, bill-to &amp; ship method autopopulate your orders · PHP <?= PHP_VERSION ?></footer>
<script src="address-autocomplete.js?v=3"></script>
</body>
</html>
