<?php
/**
 * BOM line typeahead (JSON). GET ?q=<partial MFG item or description> -> matching
 * item-warehouse rows, contains-match on either column, obsolete-looking parts excluded.
 *   { "suggestions": [ { item_number, description, item_type, type_label, uom, moq, flm,
 *                        supplier, supplier_item }, ... ] }
 * Logic lives in app/src/quotes.php::bom_lookup_items(). Admin-only (quoting is admin-only
 * throughout — see quote.php) so it can't be an open catalog scrape.
 */
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/quotes.php';
auth_boot();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, max-age=30');

$me = current_user();
if (!$me || $me['role'] !== 'admin') {
    http_response_code($me ? 403 : 401);
    echo json_encode(['error' => $me ? 'forbidden' : 'auth', 'suggestions' => []]);
    exit;
}

$q = trim((string) ($_GET['q'] ?? ''));
if (mb_strlen($q) < 2) {           // typeahead: start suggesting after a couple characters
    echo json_encode(['suggestions' => []]);
    exit;
}

echo json_encode(['suggestions' => bom_lookup_items($q, 20)], JSON_UNESCAPED_SLASHES);
