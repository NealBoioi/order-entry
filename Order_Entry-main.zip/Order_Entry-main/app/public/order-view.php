<?php
/**
 * Order-detail HTML fragment (no page chrome) — loaded into the "View order" modal on the
 * Submitted page via fetch. Mirrors order.php's data + access control. Falls back gracefully:
 * the Submitted page's View link still points at the full order.php for no-JS users.
 */
require __DIR__ . '/../src/auth.php';
require __DIR__ . '/../src/orders.php';
auth_boot();

$me = current_user();
if (!$me) { http_response_code(401); exit('<div class="ov-err">Please sign in.</div>'); }

$role = $me['role'];
$id   = (int) ($_GET['id'] ?? 0);
$data = $id ? get_site_order($id) : null;
if (!$data) { http_response_code(404); exit('<div class="ov-err">Order not found.</div>'); }

$order = $data['order'];
if ($role !== 'admin' && $order['branch'] !== $me['branch']) {
    http_response_code(403);
    exit('<div class="ov-err">This order belongs to another branch.</div>');
}

$total = 0.0;
foreach ($data['lines'] as $l) { if ($l['unit_price'] !== null) $total += $l['unit_price'] * $l['quantity']; }
?>
<div class="ov-head">
  <div class="ov-id">
    <span class="ov-po"><?= h($order['po_number']) ?></span>
    <span class="ov-sub"><?= h($order['plant_name']) ?> (<?= h($order['inventory_org']) ?>) · submitted <?= h($order['created_at']) ?></span>
  </div>
  <span class="ocs ocs-blue"><?= h($order['status']) ?></span>
</div>

<dl class="ordermeta">
  <dt>PO #</dt><dd><?= h($order['po_number']) ?></dd>
  <dt>Branch</dt><dd><?= h($order['branch']) ?></dd>
  <dt>Plant</dt><dd><?= h($order['plant_name']) ?> (<?= h($order['inventory_org']) ?>)</dd>
  <dt>Entered by</dt><dd><?= h($order['created_by_email']) ?></dd>
  <dt>Created</dt><dd><?= h($order['created_at']) ?></dd>
  <?php if (!empty($order['notes'])): ?><dt>Notes</dt><dd><?= h($order['notes']) ?></dd><?php endif; ?>
  <?php if (!empty($order['ship_to'])): ?><dt>Ship to</dt><dd style="white-space:pre-line;"><?= h($order['ship_to']) ?></dd><?php endif; ?>
  <?php if (!empty($order['ship_method'])): ?><dt>Ship method</dt><dd><?= h($order['ship_method']) ?></dd><?php endif; ?>
  <?php if (!empty($order['bill_to'])): ?><dt>Bill to</dt><dd style="white-space:pre-line;"><?= h($order['bill_to']) ?></dd><?php endif; ?>
</dl>

<div class="tablewrap"><table>
  <thead><tr><th>Item</th><th>Description</th><th>Qty</th><th>Unit</th><th>Ext</th></tr></thead>
  <tbody>
  <?php foreach ($data['lines'] as $l): ?>
    <tr>
      <td><?= h($l['item_number']) ?></td>
      <td><?= h($l['description']) ?></td>
      <td><?= h($l['quantity']) ?></td>
      <td><?= $l['unit_price'] !== null ? '$' . number_format($l['unit_price'], 4) : '<span class="muted">—</span>' ?></td>
      <td><?= $l['unit_price'] !== null ? '$' . number_format($l['unit_price'] * $l['quantity'], 2) : '<span class="muted">no price</span>' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
  <tfoot><tr><th colspan="4" class="right">Total</th><th>$<?= number_format($total, 2) ?></th></tr></tfoot>
</table></div>
