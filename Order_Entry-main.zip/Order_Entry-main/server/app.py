import sqlite3
import os
import time
import threading
from flask import Flask, request, jsonify, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'orders.db')
CLIENT_DIR = os.path.join(BASE_DIR, '..', 'client')

app = Flask(__name__, static_folder=CLIENT_DIR, static_url_path='')

# ─── Heartbeat / auto-shutdown ───────────────────────────────────────────────
_last_beat = None
_monitor_started = False

def _watch():
    while True:
        time.sleep(3)
        if _last_beat and time.time() - _last_beat > 8:
            os._exit(0)

@app.route('/api/heartbeat', methods=['POST'])
def heartbeat():
    global _last_beat, _monitor_started
    _last_beat = time.time()
    if not _monitor_started:
        _monitor_started = True
        threading.Thread(target=_watch, daemon=True).start()
    return '', 204

# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with get_db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                address TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                unit_price REAL NOT NULL DEFAULT 0,
                sku TEXT UNIQUE,
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER,
                status TEXT NOT NULL DEFAULT 'Draft',
                notes TEXT,
                created_at TEXT DEFAULT (datetime('now')),
                updated_at TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (customer_id) REFERENCES customers(id)
            );
            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL,
                product_id INTEGER,
                product_name TEXT NOT NULL,
                quantity INTEGER NOT NULL DEFAULT 1,
                unit_price REAL NOT NULL DEFAULT 0,
                FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products(id)
            );
        """)

init_db()

# ---------------------------------------------------------------------------
# Serve frontend
# ---------------------------------------------------------------------------

@app.route('/')
def index():
    return send_from_directory(CLIENT_DIR, 'index.html')

# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------

@app.route('/api/customers', methods=['GET'])
def list_customers():
    with get_db() as conn:
        rows = conn.execute('SELECT * FROM customers ORDER BY name').fetchall()
    return jsonify([dict(r) for r in rows])

@app.route('/api/customers/<int:cid>', methods=['GET'])
def get_customer(cid):
    with get_db() as conn:
        row = conn.execute('SELECT * FROM customers WHERE id=?', (cid,)).fetchone()
    if not row:
        return jsonify({'error': 'Not found'}), 404
    return jsonify(dict(row))

@app.route('/api/customers', methods=['POST'])
def create_customer():
    data = request.json
    if not data.get('name'):
        return jsonify({'error': 'Name is required'}), 400
    with get_db() as conn:
        cur = conn.execute(
            'INSERT INTO customers (name, email, phone, address) VALUES (?,?,?,?)',
            (data['name'], data.get('email'), data.get('phone'), data.get('address'))
        )
    return jsonify({'id': cur.lastrowid}), 201

@app.route('/api/customers/<int:cid>', methods=['PUT'])
def update_customer(cid):
    data = request.json
    with get_db() as conn:
        conn.execute(
            'UPDATE customers SET name=?, email=?, phone=?, address=? WHERE id=?',
            (data['name'], data.get('email'), data.get('phone'), data.get('address'), cid)
        )
    return jsonify({'success': True})

@app.route('/api/customers/<int:cid>', methods=['DELETE'])
def delete_customer(cid):
    with get_db() as conn:
        conn.execute('DELETE FROM customers WHERE id=?', (cid,))
    return jsonify({'success': True})

# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------

@app.route('/api/products', methods=['GET'])
def list_products():
    with get_db() as conn:
        rows = conn.execute('SELECT * FROM products ORDER BY name').fetchall()
    return jsonify([dict(r) for r in rows])

@app.route('/api/products/<int:pid>', methods=['GET'])
def get_product(pid):
    with get_db() as conn:
        row = conn.execute('SELECT * FROM products WHERE id=?', (pid,)).fetchone()
    if not row:
        return jsonify({'error': 'Not found'}), 404
    return jsonify(dict(row))

@app.route('/api/products', methods=['POST'])
def create_product():
    data = request.json
    if not data.get('name'):
        return jsonify({'error': 'Name is required'}), 400
    with get_db() as conn:
        cur = conn.execute(
            'INSERT INTO products (name, description, unit_price, sku) VALUES (?,?,?,?)',
            (data['name'], data.get('description'), data.get('unit_price', 0), data.get('sku'))
        )
    return jsonify({'id': cur.lastrowid}), 201

@app.route('/api/products/<int:pid>', methods=['PUT'])
def update_product(pid):
    data = request.json
    with get_db() as conn:
        conn.execute(
            'UPDATE products SET name=?, description=?, unit_price=?, sku=? WHERE id=?',
            (data['name'], data.get('description'), data.get('unit_price', 0), data.get('sku'), pid)
        )
    return jsonify({'success': True})

@app.route('/api/products/<int:pid>', methods=['DELETE'])
def delete_product(pid):
    with get_db() as conn:
        conn.execute('DELETE FROM products WHERE id=?', (pid,))
    return jsonify({'success': True})

# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------

def fetch_order(conn, oid):
    order = conn.execute("""
        SELECT o.*, c.name as customer_name, c.email as customer_email,
               c.phone as customer_phone, c.address as customer_address
        FROM orders o
        LEFT JOIN customers c ON o.customer_id = c.id
        WHERE o.id = ?
    """, (oid,)).fetchone()
    if not order:
        return None
    order = dict(order)
    items = conn.execute("""
        SELECT oi.*, p.sku FROM order_items oi
        LEFT JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = ? ORDER BY oi.id
    """, (oid,)).fetchall()
    order['items'] = [dict(i) for i in items]
    order['total'] = sum(i['quantity'] * i['unit_price'] for i in order['items'])
    return order

@app.route('/api/orders', methods=['GET'])
def list_orders():
    with get_db() as conn:
        rows = conn.execute("""
            SELECT o.*, c.name as customer_name,
                   COALESCE((SELECT SUM(oi.quantity * oi.unit_price)
                              FROM order_items oi WHERE oi.order_id = o.id), 0) as total
            FROM orders o
            LEFT JOIN customers c ON o.customer_id = c.id
            ORDER BY o.created_at DESC
        """).fetchall()
    return jsonify([dict(r) for r in rows])

@app.route('/api/orders/<int:oid>', methods=['GET'])
def get_order(oid):
    with get_db() as conn:
        order = fetch_order(conn, oid)
    if not order:
        return jsonify({'error': 'Not found'}), 404
    return jsonify(order)

@app.route('/api/orders', methods=['POST'])
def create_order():
    data = request.json
    items = data.get('items', [])
    with get_db() as conn:
        cur = conn.execute(
            'INSERT INTO orders (customer_id, notes, status) VALUES (?,?,?)',
            (data.get('customer_id'), data.get('notes'), 'Draft')
        )
        oid = cur.lastrowid
        for item in items:
            conn.execute(
                'INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price) VALUES (?,?,?,?,?)',
                (oid, item.get('product_id'), item['product_name'], item['quantity'], item['unit_price'])
            )
        order = fetch_order(conn, oid)
    return jsonify(order), 201

@app.route('/api/orders/<int:oid>', methods=['PUT'])
def update_order(oid):
    data = request.json
    items = data.get('items')
    with get_db() as conn:
        conn.execute(
            "UPDATE orders SET customer_id=?, notes=?, status=?, updated_at=datetime('now') WHERE id=?",
            (data.get('customer_id'), data.get('notes'), data.get('status', 'Draft'), oid)
        )
        if items is not None:
            conn.execute('DELETE FROM order_items WHERE order_id=?', (oid,))
            for item in items:
                conn.execute(
                    'INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price) VALUES (?,?,?,?,?)',
                    (oid, item.get('product_id'), item['product_name'], item['quantity'], item['unit_price'])
                )
        order = fetch_order(conn, oid)
    return jsonify(order)

@app.route('/api/orders/<int:oid>', methods=['DELETE'])
def delete_order(oid):
    with get_db() as conn:
        conn.execute('DELETE FROM orders WHERE id=?', (oid,))
    return jsonify({'success': True})

# ---------------------------------------------------------------------------

if __name__ == '__main__':
    print("Server running at http://localhost:5000")
    app.run(port=5000, debug=True)
