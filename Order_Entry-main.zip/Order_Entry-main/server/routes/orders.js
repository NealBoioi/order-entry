const express = require('express');
const router = express.Router();
const db = require('../db');

function getOrderWithItems(id) {
  const order = db.prepare(`
    SELECT o.*, c.name as customer_name, c.email as customer_email,
           c.phone as customer_phone, c.address as customer_address
    FROM orders o
    LEFT JOIN customers c ON o.customer_id = c.id
    WHERE o.id = ?
  `).get(id);
  if (!order) return null;
  order.items = db.prepare(`
    SELECT oi.*, p.sku FROM order_items oi
    LEFT JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
    ORDER BY oi.id
  `).all(id);
  order.total = order.items.reduce((sum, i) => sum + i.quantity * i.unit_price, 0);
  return order;
}

router.get('/', (req, res) => {
  const rows = db.prepare(`
    SELECT o.*, c.name as customer_name,
           COALESCE((
             SELECT SUM(oi.quantity * oi.unit_price)
             FROM order_items oi WHERE oi.order_id = o.id
           ), 0) as total
    FROM orders o
    LEFT JOIN customers c ON o.customer_id = c.id
    ORDER BY o.created_at DESC
  `).all();
  res.json(rows);
});

router.get('/:id', (req, res) => {
  const order = getOrderWithItems(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

router.post('/', (req, res) => {
  const { customer_id, notes, items = [] } = req.body;

  const insertOrder = db.transaction(() => {
    const result = db.prepare(
      'INSERT INTO orders (customer_id, notes, status) VALUES (?, ?, ?)'
    ).run(customer_id || null, notes || null, 'Draft');
    const orderId = result.lastInsertRowid;

    for (const item of items) {
      db.prepare(
        'INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price) VALUES (?, ?, ?, ?, ?)'
      ).run(orderId, item.product_id || null, item.product_name, item.quantity, item.unit_price);
    }
    return orderId;
  });

  const orderId = insertOrder();
  res.status(201).json(getOrderWithItems(orderId));
});

router.put('/:id', (req, res) => {
  const { customer_id, notes, status, items } = req.body;

  const updateOrder = db.transaction(() => {
    const result = db.prepare(
      'UPDATE orders SET customer_id=?, notes=?, status=?, updated_at=datetime(\'now\') WHERE id=?'
    ).run(customer_id || null, notes || null, status, req.params.id);
    if (result.changes === 0) return false;

    if (items !== undefined) {
      db.prepare('DELETE FROM order_items WHERE order_id=?').run(req.params.id);
      for (const item of items) {
        db.prepare(
          'INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price) VALUES (?, ?, ?, ?, ?)'
        ).run(req.params.id, item.product_id || null, item.product_name, item.quantity, item.unit_price);
      }
    }
    return true;
  });

  const ok = updateOrder();
  if (!ok) return res.status(404).json({ error: 'Order not found' });
  res.json(getOrderWithItems(req.params.id));
});

router.delete('/:id', (req, res) => {
  const result = db.prepare('DELETE FROM orders WHERE id=?').run(req.params.id);
  if (result.changes === 0) return res.status(404).json({ error: 'Order not found' });
  res.json({ success: true });
});

module.exports = router;
