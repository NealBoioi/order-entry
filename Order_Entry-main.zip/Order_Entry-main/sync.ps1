# sync.ps1 — back up EVERYTHING (code + current database data) to GitHub in one step.
# Run this whenever you've made changes on the website or in code:
#   Right-click > Run with PowerShell, or:
#   powershell -ExecutionPolicy Bypass -File sync.ps1
#
# It (1) dumps the DB into app/sql/dev_snapshot.sql, (2) commits all code + data changes,
# (3) pulls any remote changes, and (4) pushes. The other machine then runs:
#   git pull && php app\bin\migrate.php && php app\bin\load_snapshot.php
Set-Location $PSScriptRoot

# 1. Refresh the shared data snapshot (same tables as load_snapshot.php; skip transient ones).
$dump = 'C:\Dev\tools\mariadb\bin\mysqldump.exe'
if (-not (Test-Path $dump)) { $dump = 'C:\Dev\tools\mariadb\bin\mariadb-dump.exe' }
# Redirect via cmd so the file is written as raw UTF-8 (no PowerShell BOM/encoding surprises).
$cmd = "`"$dump`" -u oe_app -poe_app_dev_pw --no-tablespaces --skip-dump-date " +
       "--default-character-set=utf8mb4 " +
       "--ignore-table=order_entry.login_tokens " +
       "--ignore-table=order_entry.password_tokens " +
       "--ignore-table=order_entry.auth_rate_limits " +
       "order_entry > `"app\sql\dev_snapshot.sql`""
cmd /c $cmd
if ($LASTEXITCODE -ne 0) { Write-Host "X  Database dump failed (is MariaDB running? run-dev.ps1 starts it)."; exit 1 }
Write-Host "OK Database snapshot refreshed."

# 2. Stage everything and commit if there's anything new.
git add -A
if (git status --porcelain) {
    $msg = "Sync: code + data snapshot ($(Get-Date -Format 'yyyy-MM-dd HH:mm'))"
    git commit -m $msg | Out-Null
    Write-Host "OK Committed: $msg"
} else {
    Write-Host "-- No changes to commit."
}

# 3. Integrate remote changes, then push.
git pull --rebase origin main
if ($LASTEXITCODE -ne 0) {
    Write-Host "!! Pull/rebase hit a conflict. Resolve it, then run sync.ps1 again (nothing was pushed)."
    exit 1
}
git push origin main
if ($LASTEXITCODE -ne 0) { Write-Host "!! Push failed - see the message above."; exit 1 }
Write-Host "OK Pushed to GitHub. Everything is backed up."
