# stop-dev.ps1 — stops the Order Entry dev environment so the project folder is fully
# releasable (deletable/replaceable). run-dev.ps1 starts php.exe HIDDEN with app\public as
# its working directory, so until php.exe exits Windows will refuse to delete that folder —
# closing the browser/terminal windows does NOT stop it. Run this first:
#   Right-click > Run with PowerShell, or:  powershell -ExecutionPolicy Bypass -File stop-dev.ps1

# 1. Stop the PHP dev server (by recorded PID if available, else any php.exe).
$pidFile = 'C:\Dev\tools\phpserver.pid'
$stopped = $false
if (Test-Path $pidFile) {
    $srvPid = Get-Content $pidFile | Select-Object -First 1
    $proc = Get-Process -Id $srvPid -ErrorAction SilentlyContinue
    if ($proc -and $proc.ProcessName -eq 'php') {
        Stop-Process -Id $srvPid -Force
        Write-Host "OK Stopped PHP dev server (PID $srvPid)."
        $stopped = $true
    }
    Remove-Item $pidFile -ErrorAction SilentlyContinue
}
$others = Get-Process php -ErrorAction SilentlyContinue
if ($others) {
    $others | Stop-Process -Force
    Write-Host "OK Stopped remaining php.exe process(es): $($others.Id -join ', ')."
    $stopped = $true
}
if (-not $stopped) { Write-Host "-- No php.exe running." }

# 2. Optionally stop MariaDB too (frees C:\Dev\tools\mariadb-data, NOT the project folder).
#    The DB does not lock the Order Entry folder, so this is off by default; pass -IncludeDb.
if ($args -contains '-IncludeDb') {
    Get-Process mariadbd, mysqld -ErrorAction SilentlyContinue | Stop-Process -Force
    Write-Host "OK Stopped MariaDB."
}

Write-Host "Done. The Order Entry folder is no longer held open and can be deleted/replaced."
