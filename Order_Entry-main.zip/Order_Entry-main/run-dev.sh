#!/usr/bin/env bash
# Mac dev launcher for the Order Entry site (equivalent of run-dev.ps1 on Windows).
# Starts MariaDB (if not running) + the PHP built-in server, then opens the browser.
set -euo pipefail

PHP="/opt/homebrew/opt/php@8.3/bin/php"
HOST="127.0.0.1"
PORT="8000"
ROOT="$(cd "$(dirname "$0")" && pwd)"
DOCROOT="$ROOT/app/public"

# 1. Make sure MariaDB is up.
if ! /opt/homebrew/opt/mariadb/bin/mariadb-admin --silent ping >/dev/null 2>&1; then
  echo "Starting MariaDB..."
  brew services start mariadb >/dev/null
  for i in $(seq 1 20); do
    /opt/homebrew/opt/mariadb/bin/mariadb-admin --silent ping >/dev/null 2>&1 && break
    sleep 1
  done
fi

# 1b. Apply any new DB schema (idempotent — only adds missing tables/columns, never drops data).
echo "Applying database schema..."
"$PHP" "$ROOT/app/bin/migrate.php" >/dev/null || echo "(migrate warning — continuing)"

echo "Serving $DOCROOT at http://$HOST:$PORT/login.php"
# Open the browser shortly after the server comes up.
( sleep 1; open "http://$HOST:$PORT/login.php" ) &

exec "$PHP" -S "$HOST:$PORT" -t "$DOCROOT"
