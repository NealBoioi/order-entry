# Launches the Order Entry MVP (PHP) dev environment and opens it in the browser.
#   Right-click > Run with PowerShell, or:  powershell -ExecutionPolicy Bypass -File "run-dev.ps1"
$php    = 'C:\Dev\tools\php\php.exe'
$webroot = Join-Path $PSScriptRoot 'app\public'

# 1. Ensure MariaDB is up
powershell -ExecutionPolicy Bypass -File 'C:\Dev\tools\start-db.ps1'

# 1b. Apply any new DB schema (idempotent — only adds missing tables/columns, never drops data).
#     Runs on every launch so a fresh `git pull` needs no separate migrate step.
Write-Host "Applying database schema..."
& $php (Join-Path $PSScriptRoot 'app\bin\migrate.php')

# 2. (Re)start the PHP dev server on :8000, docroot = app\public (via working dir, so
#    the space in the path is not passed to php -t)
Get-Process php -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 300
$srv = Start-Process -FilePath $php -ArgumentList @('-S','127.0.0.1:8000') `
                     -WorkingDirectory $webroot -WindowStyle Hidden -PassThru
$srv.Id | Out-File 'C:\Dev\tools\phpserver.pid' -Encoding ascii
Write-Host "PHP dev server running (PID $($srv.Id)) at http://127.0.0.1:8000"
Write-Host "Tip: to reload data from the export folder, run:  php `"$(Join-Path $PSScriptRoot 'app\bin\import.php')`""

# 3. Open the app at the login page
Start-Sleep -Seconds 1
Start-Process 'http://127.0.0.1:8000/login.php'
