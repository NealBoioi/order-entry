# Order Entry

Customer-facing order-entry portal for an assembly plant running Oracle EBS
(file-based integration). Branches are the customers; the site imports Oracle
Excel/CSV exports and lets branches enter orders and check status.

**Full scope, architecture, and decisions live in [`PROJECT_BIBLE.md`](PROJECT_BIBLE.md).**
Read that first.

Stack: **PHP 8.3** + **MariaDB/MySQL** (server-rendered pages, light JS). The old
`client/`, `server/`, and `Launch Order Entry.vbs` are the retired React/Node/Flask
prototype, kept only as UX reference — the live app is under `app/`.

---

## First-time setup

### 1. Prerequisites
- **PHP 8.3** with extensions: `pdo_mysql, mysqli, mbstring, openssl, curl, fileinfo, zip`
- **MariaDB 11.4** (or MySQL 8) running on `127.0.0.1:3306`

> On Windows these can be installed portably (no admin) under `C:\Dev\tools\`.
> Ask a maintainer for the exact install steps, or see the Bible §12.

### 2. Clone
```
git clone <repo-url> "Order Entry"
cd "Order Entry"
```

### 3. Configure
```
copy app\config\config.example.php app\config\config.php
```
Edit `app/config/config.php` — set your DB password and your local `import_dir`
(the folder where the Oracle exports land). This file is gitignored.

### 4. Create the database
```
mysql -u root -e "CREATE DATABASE order_entry CHARACTER SET utf8mb4;"
mysql -u root -e "CREATE USER 'oe_app'@'localhost' IDENTIFIED BY 'YOURPASS'; GRANT ALL ON order_entry.* TO 'oe_app'@'localhost';"
mysql -u oe_app -p order_entry < app\sql\schema.sql
```

### 5. Load data (optional, from your local export folder)
```
php app\bin\import.php
```

### 6. Run it
```
powershell -ExecutionPolicy Bypass -File run-dev.ps1
```
Opens http://127.0.0.1:8000.

---

## Daily git workflow (with a collaborator)

Always pull before you start, and push when you finish a chunk:

```
git pull                 # get the latest from GitHub before working
# ...make changes...
git add -A
git commit -m "Describe what you changed"
git push                 # send your changes to GitHub
```

- **"Update my files from GitHub"** = `git pull`.
- If you both edited the same lines, git will report a **merge conflict** — stop and
  ask a maintainer to help resolve it (don't force-push over it).
- **Never commit real company data.** Keep exports in your `import_dir` (outside the
  repo) — it's gitignored by default.

### Getting the latest code AND data on another machine

`git pull` brings the **code** and the shared `config.php` (this private repo intentionally
commits `config.php` so both machines share DB + email settings). But database contents
(users, contacts, orders, pricing, quotes) live in MySQL, **not** in git — they're shared
via a snapshot file. To fully sync a second machine:

```
git pull                          # code + config.php
php app\bin\migrate.php           # create/refresh app tables (auth, quotes, rate-limit, ...)
php app\bin\load_snapshot.php     # load the shared data (users, contacts, orders, pricing)
```

> ⚠️ `load_snapshot.php` **replaces** those tables' contents with the shared snapshot.
> To publish *your* latest data for the other machine, re-dump it (command is documented at
> the top of `app/bin/load_snapshot.php`) and commit `app/sql/dev_snapshot.sql`.

---

## Layout
```
app/
  public/     web root (php -S serves this)
    index.php   pages: Order Search, Price Lookup
    style.css
  src/        db.php, xlsx.php (xlsx reader), pricing.php
  bin/        import.php (CLI importer)
  sql/        schema.sql
  config/     config.example.php  (copy to config.php)
run-dev.ps1   start DB + web server + open browser
PROJECT_BIBLE.md   scope / architecture / decisions
```
