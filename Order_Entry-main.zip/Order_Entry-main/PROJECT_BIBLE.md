# Order Entry — Project Bible

> Single source of truth for scope, architecture, progress, and decisions.
> Keep this current. When something material changes, update the relevant
> section and add a line to the Changelog at the bottom.

**Last updated:** 2026-07-15 (site overhaul Batch 2, quoting — §36)
**Maintainer:** Matthew Harvey (+ collaborator Neal)
**Status:** **MVP complete & verified live** (§14–§19); now in **Phase 2** (§11), worked in
Bible order — quoting module (§21) plus a complete auth suite: magic-link sign-in (§22),
branded emails (§23), self-service password reset (§24), and rate-limiting + password policy
(§25). Data-dependent Phase-2 items (material/on-hand visibility) are deferred until example
exports are uploaded. Live stack = PHP 8.3 + MariaDB/MySQL under `app/`, backed up to the
private GitHub repo `MatteoZoid/Order_Entry` (the Node/React/Flask code in `client/`/`server/`
is retired UX reference only — §4).

---

## 1. What this is

A **PHP + MariaDB/MySQL** order-entry portal that acts as a **file-based satellite
around Oracle EBS** for an assembly plant. Internal **branches** log in to enter orders
and check status; plant **Admins** manage pricing, contacts, and accounts. The site
imports Oracle Excel/CSV exports (items, buy pricing, order status/tracking) and emails
the plant when new orders are entered. The MVP is built and verified live.

Vision & domain rules are in **§8**; what's actually implemented is in **§13–§19**.

> ⚠️ The earlier React/Node/Flask CRUD prototype (described in **§4–§6**) is **retired** —
> kept in the repo as historical reference only. It is **not** the live app.

---

## 2. Status snapshot (current PHP/MariaDB app)

> This table tracks the **live PHP app under `app/`**. The old `client/`/`server/` Node/React/
> Flask stack is retired reference only (§4) and no longer reflected here.

| Area | State |
|------|-------|
| App architecture | ✅ Server-rendered PHP 8.3 + MariaDB/MySQL under `app/` (§4, §12) |
| Data model | ✅ users, branches, plants/orgs, items, assembly_pricing, site_orders/lines, plant_contacts, imported order_lines, quotes (+bom/cost/revisions) |
| Auth / users | ✅ **Feature-complete:** onboarding, emailed set-password link, magic-link sign-in, self-service reset, rate-limiting + password policy (§14, §22–§25) |
| Order entry + email | ✅ Auto-priced entry → store → PHPMailer notification to the plant; all emails branded (§15, §19, §23) |
| Search | ✅ Order search (branch / PO# / part# + Order/Ship status, ship-date range, sort by recent-invoice / soonest-request) with role-based column gating; admin stock-allocation column (§13, §18) |
| Admin pages | ✅ Assembly tiered pricing, contact directory, users (§16, §17, §14) |
| Imports | ✅ Item-master `.xlsx` + rg `.csv` (branch/plant parsing) (§13) |
| Quoting | ✅ Bid Prep + Costed BOM + cost roll-up (§21, admin-only) |
| Payments | ❌ None |
| Inventory on-hand / material status | 🟡 **On Hand Qty now imported** from the RG report into `order_lines.on_hand_qty`; drives the order-search stock-allocation column (§18). Broader material status still TBD |
| Tests | ⚠️ Ad-hoc smoke/verification scripts run at build time; no committed suite |
| Deployment | ⚠️ Local dev only (`run-dev.ps1` → PHP built-in server + portable MariaDB); IIS + HTTPS go-live pending |
| Version control | ✅ Private GitHub repo `MatteoZoid/Order_Entry` (Matthew + Neal) |

---

## 3. Tech stack (current)

- **App:** PHP 8.3, server-rendered pages + light JS, under `app/` (webroot `app/public/`).
- **Database:** MariaDB 11.4 in dev (drop-in for MySQL; prod may run Oracle MySQL) via PDO.
- **Email:** PHPMailer (vendored in `app/lib/`, no Composer) over SMTP; config-driven (§19).
- **Imports:** pure-PHP xlsx reader + CSV parser (`app/src/xlsx.php`, `app/bin/import.php`).
- **Run (dev):** `run-dev.ps1` or `Launch Order Entry (PHP - login).vbs` → starts MariaDB +
  PHP server on http://127.0.0.1:8000/login.php. Local env details in §12.
- **Target prod:** IIS on a 24/7 plant server, internet-facing + HTTPS (not yet built).

> **§4–§6 below describe the RETIRED React/Node/Flask prototype** — historical reference
> only, not the live stack.

---

## 4. [HISTORICAL — retired prototype] Two complete backends

> ⛔ **§4–§6 document the old React/Node/Flask prototype, which is retired.** They remain
> for historical context only. The live app is the PHP/MariaDB build — see §3 and §13–§19.

The same REST API is implemented **twice** against the **same** `orders.db`:

| | Node/Express | Python/Flask |
|--|--|--|
| File | `server/index.js` + `routes/` | `server/app.py` |
| Port | 3001 | 5000 |
| Serves client? | No (Vite does, in dev) | Yes (serves built client statically) |
| Special features | nodemon dev reload | Heartbeat auto-shutdown (`/api/heartbeat`, exits if no beat for 8s) |
| Role | **Dev mode** API behind Vite proxy | **"Desktop" mode** — single-origin app launched by the .vbs |

Both expose identical endpoints (full CRUD):
- `/api/customers` — GET list, GET :id, POST, PUT :id, DELETE :id
- `/api/products` — GET list, GET :id, POST, PUT :id, DELETE :id
- `/api/orders` — GET list, GET :id, POST, PUT :id, DELETE :id

**The client uses a relative `/api` base**, so it works against whichever backend
serves it (Vite proxy → Node in dev; Flask directly in desktop mode).

**Implication / risk:** every API change must be made in **both** backends or they
drift. This duplication is the first architectural decision to resolve — pick one
backend, or formally designate dev vs. packaging roles. **Decision pending (§9).**

---

## 5. [HISTORICAL — retired prototype] Data model

> Old prototype schema. The live app's schema is the PHP/MariaDB one (items, orgs,
> order_lines, users, site_orders, assembly_pricing, plant_contacts, branches) — see §8.2 and §14–§17.

SQLite, defined in `server/db.js` (Node side; Flask assumes same schema).

```
customers(id, name*, email, phone, address, created_at)
products(id, name*, description, unit_price*, sku UNIQUE, created_at)
orders(id, customer_id→customers, status* [default 'Draft'], notes,
       created_at, updated_at)
order_items(id, order_id→orders [ON DELETE CASCADE], product_id→products,
            product_name*, quantity* [default 1], unit_price* [default 0])
```
(* = NOT NULL). Order total is computed on the fly as Σ(quantity × unit_price);
not stored. `product_name`/`unit_price` are snapshotted onto the line item.

---

## 6. [HISTORICAL — retired prototype] Client pages (`client/src/pages/`)

- **Dashboard.jsx** — landing / overview
- **Orders.jsx** — order list
- **OrderDetail.jsx** — single order view
- **OrderForm.jsx** — create/edit order (shared for `/orders/new` and `/orders/:id/edit`)
- **Customers.jsx** — customer management
- **Products.jsx** — product catalog management

Routing defined in `client/src/App.jsx` (sidebar nav: Dashboard / Orders / Customers / Products).

---

## 7. Loose pieces (status unclear — confirm intent)

- **`Order Entry Assistant/`** — a Microsoft Copilot Studio agent (`.mcs.yml`,
  `topics/`, `workflows/`). It's a *guidance chatbot about how to build an order
  site* — NOT wired into the app. Open question: evolve into an in-app AI helper,
  or retire it? (§8 Q4)
- **`make_schema_doc.py` + `Schema Review.xlsx`** — script that generates schema
  documentation into an Excel workbook. Utility/reporting tool.
- **`~$Schema Review.xlsx`** — Excel lock/temp file; safe to ignore.

---

## 8. Product vision (captured 2026-06-30)

**What it is:** A customer-facing order-entry portal acting as a **satellite around
Oracle EBS** for an assembly plant. It is NOT a standalone store — EBS is the
system of record for the plant's operations; this site is the external front door
and a quoting workspace.

**Three parties / two roles:**
- **Customer**, **Plant**, **Quoting** are the three user constituencies.
- Account role is **Customer** or **Admin** (plant-side).
- **Account onboarding:** a customer submits a *login request* (name, contact info,
  branch # or customer name, etc.); a plant **Admin approves** the account and
  **assigns the role**.

**Customer role — deliberately narrow:**
- Enter a new order.
- Search existing orders by **PO#**.
- **Pricing auto-populates** when they select a part number + QTY.

**Admin (plant) role:**
- Set **tiered pricing** and **lead times**.
- Stronger search — e.g. **all open orders** across customers.

**System capabilities:**
- **Email notifications** to the plant when new orders are entered.
- **Automated Excel import from a server** (files exported from Excel) to update
  orders with **shipped status + tracking #**.

**Phase 2+ (eventually, not MVP):**
- Material status visibility.
- **Quoting module:** quoters create projects in the backend; visibility into what
  parts the plant has set up / on hand; possibly **scrape supplier sites** for
  pricing & availability.

### Open questions blocking workflow design (see chat 2026-06-30)
1. **EBS integration model** — live API vs. file-based exchange (the pivotal one).
   Do site orders push *into* EBS, or does the plant re-key from the email/notification?
2. **Part & pricing source of truth** — EBS export vs. admin-set tiered pricing in-site;
   how price is derived (per part, per customer tier, qty breaks).
3. **Account ↔ customer/branch scoping** — multiple users per customer? Customers see
   only their own orders?
4. **Hosting & IT constraints** — on-prem vs. internet-facing; OS/DB the plant IT supports.
5. **Auth/security** — external customers + internal staff; SSO/AD for plant?
6. **Email infra** — SMTP available, from-address, recipient distro.
7. **Excel feed mechanics** — share path, cadence, format, matching key.
8. **Scale** — # customers/users/orders → drives DB choice (SQLite is prototype-only).
9. **First milestone** — which slice is MVP #1.

### 8.1 Domain model (clarified 2026-07-01)

**Oracle relationship — CONFIRMED: no direct connection.** Oracle EBS exports many
Excel files to a server; the site **imports** them. Nothing writes back to Oracle
programmatically. Site-entered orders are emailed to the plant, who key them into
Oracle. Two datasets **reconcile on PO#**: (a) site-captured new orders, (b) imported
Oracle "Open Order" export carrying status/shipping/tracking. Order-*status* search
reads the imported data; order *entry* writes site records.

**Branches ARE the customers.** The plant sells to internal **branches** (not end
customers). Branch = 4-digit code (e.g. `1932`, `1918`). **PO# = `<branch>-<lot>`**,
e.g. `1932-999999` → PO#s are globally unique via the branch prefix. Customer account
stores its **branch #**; order search = `PO LIKE '<branch>-%'`. A Customer role can
also search **by part number across ALL orders** (even other branches' orders).

**Multi-org / plant selection.** Assembly plants are separate orgs, e.g. Austin
(Plant `1931`, Org `AA1`), Little Rock (Plant `3908`, Org `A10`), more later.
Customer **selects the plant during order entry** → orders sortable by plant, and
**email notifications route to that plant's contact**. NOTE: branch codes and plant
codes are different number sets — do not conflate.

**Pricing — two sources by item type:**
- `WES-PUR-RE` (purchased/buy items) — priced **in Oracle**, pulled from the item
  export `lr_item_warehouse_all_<YYYY-MM-DD>.xlsx` (e.g. `..._2026-07-01.xlsx`).
- `WES-ETO` (assembly items) — **NOT priced in Oracle**. Price comes from an
  **Admin-only Tiered Pricing page** (entered by Admin), resolved by QTY tier when a
  customer enters an order. This is the auto-populate source for assemblies.

**Pages implied:** Admin-only Assembly Tiered Pricing page; a Contact page (Admin-
editable, Customer view-only) tying **Branch # ↔ Plant site ↔ Plant contact ↔
Customer contact** — this drives email routing.

**Auth:** request access with **Email + Branch #** → Admin (Matthew for now) approves
→ user sets/reset password. Passwordless **magic-link** login = desirable fast-follow.
AD/SSO out of scope for now.

**Hosting:** eventually a 24/7 plant server, internet-accessible like a normal website
(external customers + internal admins). Implies HTTPS + hardening at go-live.

### 8.2 Export file schemas (from zeroed examples, 2026-07-01)

Examples now live **inside the project** at `Excel Examples Folder/` (moved 2026-07-09 from the
external Windows path `C:\Dev\Exported data examples\`). ⚠️ Only **zeroed/scrubbed** example files
belong here — never real company data (per CLAUDE.md §5); if any file could contain live data, keep
it out of the repo or gitignore this folder before committing.

**Item master — `lr_item_warehouse_all_<YYYY-MM-DD>.xlsx`** (sheet `items`, ~62 cols).
One file per plant (`lr` = Little Rock; `organization` col = `3908 - Little Rock
Assembly (MFG)`). Key cols: `organization`, `item_number` (carries `,NN` revision
suffix, e.g. `320FP23,00`), `description`, `primary_uom`, `item_status`, **`item_type`**
(`WES-PUR-RE` vs `WES-ETO`), **`list_price`** (populated for WES-PUR-RE, EMPTY for
WES-ETO → confirms two-source pricing), lead times (`fixed_lead_time`,
`cummulative_lead_time`, `flm`, pre/processing/post, `quoted_lead_time`),
`min_order_qty`, `frozen_cost`/`pending_cost`, `vendor_name`, `manufacturer`,
`product_code`, `quote_item_number`.

**Sales-order / shipping feed — `<ORG>_daily_rg_<YYYY-MM-DD>.csv`** (e.g.
`A10_daily_rg_...`; 84 cols, one file per org). This is BOTH the existing-order search
source AND the shipping/tracking feed. Key cols: `Customer Po Number` (e.g.
`1938-386772/4501051402` → branch `1938` + lot + optional `/release`), `Order Number`
(Oracle SO #), `Order Extended Line Number`, `Order Status`/`Line Status`/`Ship Line
Status`, `Ordered Item` (`,NN` suffix), `Item Description`, `Unit Price`/`Extended
Price`, `Uom`, `Ordered Qty`/`Shipped Qty`, **`Tracking Number`**, `Actual Ship Date`,
`Delivery Number`, `Invoice Number`/`Date`, request/promise/scheduled dates,
`Bill To`/`Ship To Customer`, `Ship To Site Name`, `Inside Salesrep`, `Operating Unit`
(`CBC US 1931 OU`), `Inventory Org` (`A10`).

**🔴 Customer-visibility rule (authorization) — CONFIRMED 2026-07-01:** on
existing-order / status views a **Customer role sees ONLY**: `Customer Po Number`,
`Order Number`, `Order Date`, item + description, `Ordered Qty`, `Shipped Qty`,
`Line Status`, `Ship Line Status`, `Tracking Number`, `Actual Ship Date`, promise &
request dates, `Invoice Number`/`Invoice Date`. **Explicitly HIDDEN from customers:**
ALL pricing (`Unit Price`/`Extended Price`) on existing orders, ALL cost/margin/S&D/
labor fields, AND `Scheduled Ship Date`/`ScheduledArrival Date`. Import every column;
gate exposure by role. NOTE: pricing is shown to customers ONLY during **new-order
auto-populate**, never on historical order lookup.

**Org/plant key — CONFIRMED:** the plant/org for a row = the **`Inventory Org` column
(last column, #83)** on the rg report, e.g. `A10` (Little Rock), `AA1` (Austin).
**IGNORE** the first two columns (`Operating Unit` `CBC US 1931 OU`, `Order Type`) —
the `1931` there is a selling OU, not the plant. Item master ties the same plant via
`organization` (`3908 - Little Rock Assembly (MFG)`). Need a small org reference table:
Inventory Org (A10) ↔ Plant code (3908) ↔ Name (Little Rock) ↔ contact — backs the
Contact page + email routing. "Plant selection" at order entry = this manufacturing org.

**Branch identity — CONFIRMED:** account branch # = **first 4 chars of `Customer Po
Number`** (e.g. `1938`). `Order Number` = the Oracle sales order #. Oracle Bill-To/
Ship-To customer numbers (1126/1040) are NOT used for account scoping.

### Data constraint
No live company data may be shared. Matthew will place **zeroed example files**
(headers + ideally one sample row) in `Excel Examples Folder/` (in-repo, as of 2026-07-09). Needed to
design schema + importers: `lr_item_warehouse_all_<date>.xlsx` (parts + buy pricing +
item type), the **Open Order** export (status/shipping/tracking + PO# column format),
and any **customer/branch** or **contact** file. **Ask before each so he can scrub it.**

---

## 9. Decisions log

| Date | Decision | Notes |
|------|----------|-------|
| 2026-07-01 | **Oracle = file-based only**, no live connection | §8.1 |
| 2026-07-01 | Audience = internal **branches** as customers + plant Admins | §8.1 |
| 2026-07-01 | MVP vs Phase 2 scope locked | §8 / §11 |
| 2026-07-01 | **Stack = PHP 8 + MySQL on IIS** (APPROVED), server-rendered + light JS; retire Node/Flask/React & SQLite (keep as UX reference) | Resolves the dual-backend question in §4. PHP + MySQL not yet installed — prereq for build/verify. |
| 2026-07-01 | **Customers see NO pricing/cost/margin on existing orders, and NO scheduled-ship date** — status/shipping whitelist only; pricing shows only at new-order entry | §8.2; high-stakes validation zone |
| 2026-07-01 | **Plant/org keyed off rg `Inventory Org` (last col)**, ignore the `1931` OU columns | §8.2 |
| 2026-07-01 *(proposed)* | Email via **PHPMailer**; POC through **Mailtrap**, live via Brevo/company relay | §8 |

---

## 10. Working agreement — AI orchestration preferences

For multi-agent workflows on this project (Matthew's stated approach):
- **Opus** = planning/decomposition layer + adjudicating contested results.
- **Sonnet** = implementation (workers) AND first-pass verification.
- **Escalation**: Sonnet verifiers flag `uncertain`/`blocking` items → those escalate
  to an **Opus** verifier. Opus does not blanket-verify every item (cost vs. value).
- Rationale: verifier independence comes from a *fresh context*, not a different
  model — so Sonnet-verifies-Sonnet is genuinely adversarial and far cheaper.
- Workflows are reviewed (script shown) **before** launch; cost matters (Max $100
  plan — workflows hit the weekly Opus cap fastest, so fan-out is sized deliberately).

---

## 11. Roadmap

**MVP (target build):**
1. **Foundation** — PHP+MySQL project on IIS; schema for users, accounts, branches,
   plants/orgs, items, assembly tiered pricing, orders, order lines, contacts, imports.
2. **Auth & onboarding** — request access (Email + Branch #) → Admin approval → role
   (Customer/Admin) → password set/reset.
3. **Order entry (Customer)** — plant selection, part lookup, **auto-pricing** by item
   type + QTY, submit → store + **email the right plant contact**. ✅ Store (§15) **and
   email** (§19) both built & verified — PHPMailer over SMTP, routed via the Contact
   directory.
4. **Search** — Customer: by branch (`PO LIKE '<branch>-%'`) + by part# across all orders.
   Admin: all open orders + stronger filters.
5. **Admin pages** — Assembly Tiered Pricing ✅ (§16); Contact directory
   (branch↔plant↔contacts) ✅ (§17).
6. **Imports** — `lr_item_warehouse_all_<date>.xlsx` (items + buy pricing); Open-Order
   export (status/shipping/tracking) matched to orders by parsed PO#.

**Phase 2** (working in Bible order; skip items that need example data until it's uploaded):
1. Quoting projects (backend) — ✅ **built** (§21).
2. Material status visibility — ⏸ **deferred**: needs an on-hand/inventory export we don't
   import yet (the item master has no quantity-on-hand column). Awaiting a zeroed sample.
3. Part on-hand / setup visibility — ⏸ **deferred**: same data dependency as #2.
4. Spot-market pricing/availability — ⬜ not started; vision refined 2026-07-15 (Neal): pull
   **authorized distributors** (DigiKey, Mouser, RS, Master Electronics) + manufacturer
   availability (Panduit, Phoenix Contact, Eaton, Hoffman) into the Components page — via the
   distributors' **product APIs, not HTML scraping** (DigiKey/Mouser have free-tier APIs;
   manufacturers rarely publish price — reach them by filtering distributor results). Match on
   **manufacturer part number** (items' supplier-item/SIM columns, with per-search override).
   Architecture when built: provider-adapter file like geocode.php + a TTL cache table; needs
   API keys (Matt) + outbound internet. If the Components experiment proves out, the same
   lookup likely gets embedded **inside the quote page** for use while writing a quote.
5. Magic-link login — ✅ **built** (§22). Listed last in the roadmap but done ahead of #2–#4
   because it needed no new data (Matthew's call, 2026-07-07: skip data-blocked items for now).

**Status:** MVP items #1–#6 are all built and verified live (§14–§19). Phase-2 has begun —
quoting (§21) and the full auth suite (§22–§25) are done. **Blocked on:** example export files
in `Excel Examples Folder/` for the data-dependent Phase-2 items (#2 material status,
#3 on-hand) — the same zeroed-sample process as §8.2. **Next:** quote export / test suite /
async email, and production hardening (IIS + HTTPS + real SMTP relay).

---

## 12. Local dev environment (stood up 2026-07-01)

Installed **no-admin** (winget PHP URLs were stale; MySQL/MariaDB service installs
need UAC which the non-interactive terminal can't drive — so everything is portable):

- **PHP 8.3.32 NTS** → `C:\Dev\tools\php` (on user PATH). Extensions enabled:
  `pdo_mysql, mysqli, mbstring, openssl, curl, fileinfo, gd`. Run app in dev with
  PHP's built-in server: `php -S localhost:8000 -t <webroot>`.
- **MariaDB 11.4.9 LTS** → `C:\Dev\tools\mariadb`, data at `C:\Dev\tools\mariadb-data`.
  Used as the local dev DB — a **drop-in for MySQL** (same `pdo_mysql` driver + SQL, so
  zero code change to run real Oracle MySQL on the production plant server later).
  - Start it (no admin): `powershell -File C:\Dev\tools\start-db.ps1`
  - Runs detached on **127.0.0.1:3306**; not a Windows service (must be restarted after
    reboot via the script above).
- **DB connection (dev):** host `127.0.0.1`, port `3306`, database `order_entry`,
  user `oe_app`, password `oe_app_dev_pw` (dev-only credential).
- **Verified:** PHP → PDO → MariaDB create/insert/select/drop roundtrip passes.

**Excel/CSV import tooling:** Python 3.14 + `openpyxl` are present (used to inspect the
exports). The PHP app's importer will parse the CSV rg feed natively; xlsx parsing
approach TBD in the spec (PHP lib vs. a Python helper).

## 13. MVP thin slice (built & verified 2026-07-01)

First working vertical slice — a **new PHP app** under `app/` (the old Node/React/Flask
prototype is untouched, still reference-only). Proves the three hardest mechanics.

- **Run it:** `powershell -ExecutionPolicy Bypass -File "run-dev.ps1"` (starts DB + PHP
  server on http://127.0.0.1:8000 and opens the browser). Reload data:
  `php app\bin\import.php`.
- **Layout:** `app/public/index.php` (UI), `app/src/{db,xlsx,pricing}.php`,
  `app/bin/import.php` (CLI importer), `app/sql/schema.sql`, `app/config/config.php`.
- **What works (all verified by running):**
  1. **Import** — pure-PHP xlsx reader loads the warehouse items; CSV reader loads the rg
     order lines; branch parsed from messy PO (`1938-386772/4501051402` → `1938`); plant
     from `Inventory Org`.
  2. **Order search** — by branch / PO# / part# (part# is cross-branch, per spec).
  3. **Role gating** — Customer view hides Unit Cost, Unit/Extended Price, and Scheduled
     Ship; Admin view shows them. (Confirmed present/absent in the rendered HTML.)
  4. **Two-source pricing** — buy item (`PDGXAC`) → Oracle `list_price` ($10); assembly
     (`320FP23,00`) → admin tier by qty ($12 @1, $10 @50); clean "No price" when an item
     isn't in the master.
- **Known slice limitations (by design, next up):** no auth yet (a Customer/Admin toggle
  stands in); pricing lookup requires the item to exist in the item master (the 2-row
  sample omits `VR-2-ET-G,00`); dates stored as text; single import folder; no email.

## 14. Auth & onboarding slice (built 2026-07-06)

Roadmap item **#2** — replaces the fake Customer/Admin toggle with real session auth.
New PHP files under `app/`; durable auth schema separate from the data-import schema so
`php app/bin/import.php` never wipes accounts.

- **Setup / seed the first admin (one command):**
  `php app\bin\bootstrap_admin.php admin@example.com "changeme123"` — creates the
  `users` + `password_tokens` tables (from `app/sql/auth.sql`) and upserts an active
  Admin. Re-running with the same email just resets that admin's password.
- **Onboarding flow:** `request-access.php` (Email + 4-digit Branch #) → status
  `pending` → Admin approves on `admin-users.php` (assigns role + confirms branch) →
  a one-time **set-password token** is issued → user sets password on
  `set-password.php` → `login.php` (session). Tokens expire in 72h and are stored as
  SHA-256 only. **No email yet** (roadmap #3): on approval the admin is shown the
  set-password link to relay manually — the honest stand-in until PHPMailer lands.
- **Files:** `app/src/auth.php` (session, guards, CSRF, login, onboarding, tokens),
  `app/sql/auth.sql`, `app/bin/bootstrap_admin.php`, and pages `login.php`,
  `logout.php`, `request-access.php`, `set-password.php`, `admin-users.php`.
- **Security posture:** `password_hash()` (bcrypt) + `password_verify`; per-session
  CSRF tokens on every POST; `session_regenerate_id()` on login; uniform login-failure
  message (no account-existence leak); httponly/SameSite=Lax cookie, `secure` auto-on
  under HTTPS; POST-only logout.
- **Role now drives real behavior:** the existing column gating (hide cost/price/
  scheduled-ship) is keyed off the session role instead of a URL param, and **customer
  order search is scoped to their own branch** — except a **part-number** match, which
  stays cross-branch per §8.1. Admins see all orders + the `Users` admin page.
- **Known limitations (next up):** ~~no email delivery of the set-password link~~ **DONE —
  the link is now emailed on approval/reset (§23)**; ~~magic-link login~~ **DONE (§22)**;
  ~~no self-service "forgot password"~~ **DONE (§24)**; ~~no password-complexity rule~~ **DONE
  (§25)**; ~~no send rate-limiting~~ **DONE (§25)**. **Auth is now feature-complete.**
- **Not verified live on this machine** — this checkout has no PHP/`config.php`
  installed (the §12 dev env was stood up elsewhere). Needs a lint + click-through
  where PHP + MariaDB are present.

## 15. Order-entry slice (built 2026-07-06)

Roadmap item **#3, minus email** — the app's namesake capability. Adds the ability to
actually **enter and submit a new order**, with auto-pricing, then store it. Email
notification to the plant is deliberately deferred (PHPMailer not installed) and left as
a clearly-marked hook.

> **Requested Delivery Date added 2026-07-09:** the New Order form now has an optional
> **Requested delivery date** field (`<input type="date">`, min = today). Stored in a new
> `site_orders.requested_delivery_date DATE NULL` column (schema + `migrate.php`
> `add_column_if_missing`), passed through `create_site_order()`, validated server-side
> (real date, not in the past), and shown on the order view (`order.php`) and in the
> plant-notification email (`notify.php` meta). Shown for all roles entering an order.
>
> **URGENT flag added 2026-07-09:** a **Mark URGENT** checkbox on New Order (all roles).
> Stored in `site_orders.urgent TINYINT(1)` (schema + migration), threaded through
> `create_site_order($…, bool $urgent)`. When set, the plant email gets a `🚩 URGENT —`
> **subject prefix** + a red "⚠ URGENT ORDER — PLEASE PRIORITISE" banner (`notify.php`), and
> the order view shows a red **URGENT** pill (`order.php` + `.statuspill.urgent` in style.css).
>
> **Ship-to / Bill-to / Ship-method are CUSTOMER-only** (the `if ($role==='customer')` block
> in `new-order.php`, per §28/§29 — they come from the customer's saved address books). Admins
> entering an order don't see them (they have no personal address book). Not a regression.
> **Reminder: run `php app/bin/migrate.php` after pulling schema changes** — the DB isn't in git,
> so each machine needs the migration run (this is what caused the "Unknown column
> requested_delivery_date" fatal on the Windows box).
>
> **Email spreadsheet format + Shipment Reference # + UOM (2026-07-09, from `Excel Examples
> Folder/Order email tweaks.xlsx`):** the plant email meta is now a **bordered spreadsheet-style
> grid** in the requested field order — **Date Submitted · PO # · Shipment Reference # · Entered by ·
> Plant Site · Ship to · Ship method · Bill to** (Branch dropped; "Plant"→"Plant Site";
> "Submitted"→"Date Submitted"). The line-item table gained two columns: **UOM** (snapshot of
> `items.primary_uom` → new `site_order_lines.uom`; `find_item` now selects it, cart captures it) and
> **Requested Delivery Date** (the order-level date, shown per line). New optional **Shipment
> Reference #** order field → `site_orders.shipment_ref` + a form input; shown on the order view too.
> The New Order **date field** was restyled to match the site, and the browser's un-styleable native
> calendar popup was **replaced with a themed custom date picker** (`app/public/datepicker.js` +
> `.dp*` styles) — Wesco charcoal/green, month nav, green selected day, today outline, disabled past
> days (respects the input `min`), Clear/Today. Progressive enhancement: keeps a hidden ISO
> `delivery_date` input for the form; native `type=date` still works with JS off. NOTE: Requested
> Delivery Date is currently **one date per order** shown in the item column — per-line dates TBD.

- **Site orders are their own dataset.** New durable tables `site_orders` +
  `site_order_lines` (`app/sql/orders.sql`), separate from the imported Oracle
  `order_lines`. They reconcile with Oracle on **PO#** per §8.1 (plant keys the site
  order into Oracle; it later returns via the rg import with status/tracking).
- **Flow (`app/public/new-order.php`):** search parts → **Add** builds a session cart
  (price resolved server-side, never trusted from the form) → pick **plant** → **PO#**
  (branch prefix fixed from the account + a lot the user types) → **Submit** → one
  transactional insert → redirect to the confirmation (`order.php`). Auto-pricing reuses
  the two-source rule: assembly tier by qty; buy-item price via Oracle `list_price`
  (admins only — customers still can't see/add buy items, so their orders are
  assemblies-only in this slice). **Prices are snapshotted** onto each line.
- **Files:** `app/sql/orders.sql`, `app/src/orders.php` (org list, session cart,
  `find_item`, `price_for_item`, `create_site_order`, `get_site_order`),
  `app/src/notify.php` (stub hook), pages `new-order.php` + `order.php`, plus a
  `New Order` nav link everywhere. `app/bin/migrate.php` applies the durable schema
  (auth + orders); `bootstrap_admin.php` now applies both files too.
- **Email hook (roadmap #3):** `notify_new_order()` resolves the plant contact from
  `orgs.contact_email` and currently **logs** `app/storage/notifications.log`
  ("would email: …"). Swapping in a PHPMailer send later is a one-function change.
- **Access control:** New Order requires login; customers' PO branch is fixed to their
  account branch; `order.php` lets a customer view only their **own branch's** site
  orders (admins see all).
- **Known limitations (next up):** no order editing/cancel after submit; customers
  can't add buy items (consistent with the pricing-leak rule); no order-history list
  page yet (view is by direct id); email still stubbed; dates via DB defaults.
- **Not verified live on this machine** — same as §14, no PHP/`config.php` here.
  Verify with `php app\bin\migrate.php` then a click-through.

## 16. Admin assembly-pricing slice (built 2026-07-06; quotes redesign 2026-07-13) — ⛔ RETIRED 2026-07-15 (§36)

> **RETIRED:** `admin-pricing.php` was deleted in overhaul Batch 2 (§36). New Order assembly
> pricing now resolves from **quote Transfer Prices** (quote_summary_tiers), falling back to the
> legacy `assembly_pricing` tiers only for parts with no quote. The table + `pricing.php`
> helpers remain (fallback + history). Everything below is historical.

Roadmap item **#5, first half** — the admin UI to manage the assembly tiers that feed
the new-order auto-pricing (§15). Previously those tiers existed only as seeded SQL.

> **2026-07-13 — redesigned as "Assembly Pricing Quotes"** per Matt's Excel mockup
> (`Excel Examples Folder/Assembly_Tiered_Pricing_page.xlsx`). Each tier is now a **quote**:
>
> - `assembly_pricing` gained `quote_date` + `expire_date` (durable columns via
>   `pricing.sql` + `add_column_if_missing` in `migrate.php`; legacy rows keep NULLs and
>   show a "No dates" badge until re-saved).
> - **Quote date autofills today** (editable, themed datepicker); **expire date autofills
>   quote date + 3 months** — "all quotes last 3 months by default" — and follows the
>   quote date in JS until the admin picks an expire date manually (datepicker.js now
>   fires `change` on real picks and exposes a `dpSet()` programmatic setter).
> - **Unit price: blank = automatic from the daily file; typed = override (final form,
>   2026-07-13).** First pass made the price fully automatic (frozen cost, auto-set on
>   save, no input) per Matt's picker answers; his follow-up ("all fields should be
>   editable such as price") relaxed it: the price field is back and editable, and a
>   BLANK price grabs the item's **frozen cost — the per-ONE-unit standard cost from the
>   daily item file** — at save time (`resolve_unit_price()`). Blank price + no frozen
>   cost in the file → refused with a clear error. So auto is the default path; a typed
>   price wins.
> - **Update opens an edit POPUP with the item's WHOLE tier set (2026-07-13 per Matt).**
>   ONE **Update** button per part (in the item block's header — no per-row buttons, and
>   per-row Delete is gone; removal happens inside the popup). The popup lists every tier
>   (qty + price editable; blank price = daily file), a **"+ New tier"** button, ✕
>   mark-for-removal per row, and one **Save all** that applies the whole set atomically
>   (`save_item_quotes()`: per-row validation, duplicate-min-qty check, transaction;
>   validation failures reopen the popup). The single-item Create New Quote panel stays
>   for first quotes.
> - **ONE quote date + expire date per ITEM, not per tier (2026-07-13 per Matt).** The
>   date pair covers the entire quote (all tiers): shown once per item block in the
>   results (with the Expired / No-dates badge), edited once in the popup (expire still
>   auto-follows quote +3 months until touched), and EVERY save — popup or Create panel —
>   re-syncs the pair across all of the item's rows. Storage stays per-row in
>   `assembly_pricing` (rows are simply kept identical), so no migration was needed.
> - Quotes **past their expire date are flagged "Expired"** (row highlight + badge) —
>   pricing older than the 3-month window is immediately visible. Expired quotes still
>   price orders (§8.2 unchanged); the flag is a re-quote prompt, not a block.
> - **Search Quotes panel** (left, per mockup): search saved quotes by part # (app-wide
>   exact-unless-`%` rule, `list_quotes()`); filter survives save/delete round-trips.
> - Page shows **UOM + frozen cost** from the item master next to every item (quote list
>   headers, the quote form via `quote_item_info()`, and the "no quote yet" helper list).
>   `items.frozen_cost` (Oracle standard cost, ADMIN-only like `list_price`) is now
>   captured by the item import — see §34.
> - **Updating a quote** (per mockup): item/qty/price prefill; the dates reset to
>   today/+3 months so a re-save is a fresh quote.
> - Helper renames: `list_all_tiers` → `list_quotes(partNo='')`; `save_tier()` now takes
>   `quote_date`/`expire_date` (blank → today / +3 months, validated).

- **Durability fix (important):** `assembly_pricing` was living in the drop-and-recreate
  `app/sql/schema.sql`, so a data reset would erase real admin pricing. Moved it to the
  **durable** `app/sql/pricing.sql` (`CREATE TABLE IF NOT EXISTS`, now with a
  `UNIQUE(item_number, min_qty)`), removed it from `schema.sql`, and the demo tiers are
  now **seeded only when the table is empty** (`migrate.php`) so fresh DBs get samples
  while existing pricing is never touched. `migrate.php`/`bootstrap_admin.php` apply
  `pricing.sql` alongside auth + orders.
- **Page (`app/public/admin-pricing.php`, admin-only):** add/edit/delete tiers grouped
  by item; **re-saving the same item + min-qty updates** that tier (upsert done by
  existence check in PHP, so it works even on legacy DBs without the unique key); a
  helper lists **assemblies in the item master with no tier yet** (one-click "Add tier")
  so orders don't hit "No tier price set".
- **Helpers added to `app/src/pricing.php`:** `list_all_tiers`, `save_tier`,
  `delete_tier`, `assemblies_missing_tiers` (alongside the existing `assembly_price`
  resolver the tiers feed).
- **Nav:** admin-only **Pricing** link added across the app headers.
- **Not verified live here** (no PHP/config on this checkout). Verify:
  `php app\bin\migrate.php` then edit a tier and confirm the new price shows in New Order.

## 17. Contact directory slice (built 2026-07-06)

Roadmap item **#5, second half** — completes the admin pages. Admin-editable directory
of **plant contacts** (the email-routing targets) and a **branch directory**
(branch ↔ plant ↔ customer contact); customers get a read-only view of who handles
their orders.

- **Durable, engine-portable tables** (`app/sql/contacts.sql`): `plant_contacts`
  (per `inventory_org`) and `branches` (per 4-digit branch). Deliberately **new tables,
  not new columns on `orgs`** — a plain `CREATE TABLE IF NOT EXISTS` works identically on
  MariaDB (dev) and MySQL (prod), avoiding engine-specific `ALTER` on the legacy dev DB.
  Demo plant contacts seed only when the table is empty (`migrate.php`).
- **Email routing now reads the directory.** `notify.php::plant_contact_for_org()`
  prefers `plant_contacts.contact_email`, falling back to the legacy `orgs.contact_email`
  — so editing a plant's contact on this page changes where new-order notifications go
  (once roadmap #3's email is wired).
- **Page (`app/public/contacts.php`):** admins edit plant contacts (rendered as cards —
  a `<form>` can't wrap a `<tr>`, so no in-table forms) and add/edit/delete branches
  (with a default-plant selector); customers see plant contacts + **their own branch's**
  entry, read-only.
- **Helpers (`app/src/contacts.php`):** `list_plants_with_contacts`, `save_plant_contact`,
  `list_branches`, `get_branch`, `save_branch`, `delete_branch`. Upserts use positional
  placeholders + `VALUES(col)` (native prepares — `ATTR_EMULATE_PREPARES=false` — forbid
  reusing a named placeholder).
- **Nav:** **Contacts** link added for all roles.
- **MVP status:** with this, the MVP roadmap (§11) is **feature-complete except email**
  (#3) — Foundation, Auth, Order entry, Search, Admin pricing + contacts, and Imports are
  all built. Email is the one remaining piece, blocked on PHPMailer.
- **Not verified live here** (no PHP/config on this checkout). Verify:
  `php app\bin\migrate.php`, then as admin edit a plant contact and a branch.

## 18. Live verification — full stack stood up & smoke-tested (2026-07-06)

> **2026-07-13 — Order search filters, sort, and on-hand stock allocation (per Matt).**
> - **Filter & sort bar** (`app/public/index.php`): a dedicated card **below the search box and
>   above the results** (moved out of the main search grid, per Matt) holding **Order Status** and
>   **Ship Status** dropdowns (distinct values from `order_lines`), an **Actual-Ship-Date range**
>   (from/to, themed datepicker), and the **Sort** dropdown. It's part of the same GET form and
>   **auto-applies on change** (dropdown or date pick), preserving the text fields; the card's
>   Search button is the no-JS fallback. Styled to match the site (card, focus glow, fadeUp).
>   Dates are stored as text (M/D/YYYY from the export, ISO from seeds), so the range and sorts
>   parse with `COALESCE(STR_TO_DATE(col,'%c/%e/%Y'), STR_TO_DATE(col,'%Y-%m-%d'))`. Any filter
>   alone triggers a search; status filters live inside the customer branch-scope.
> - **Sort:** Order # (default) · **Most recent invoice** (invoice_date DESC) · **Soonest
>   request date** (request_date ASC); undated rows sort last.
> - **On-hand STOCK ALLOCATION (admin-only), the headline feature.** `order_lines.on_hand_qty`
>   (RG 'On Hand Qty', §34) is allocated across an item's OPEN orders (ordered − shipped > 0, not
>   cancelled) in **request-date order** — soonest-due consumes first. Each card shows the item's
>   on-hand, how much stock is **available to that line after earlier-due orders take their share**,
>   and a covered/short pill. `allocate_on_hand()` in `app/src/orders.php` computes across ALL of
>   the item's lines (not just the search result set), so allocation is correct under any filter.
>   Verified live to Matt's exact example: on-hand 400 with 25(7/22)+200(7/31)+150(8/05)+50(8/15) →
>   the 200 line shows **375 available**, and the 50 line comes up **short 25**.
> - Also: New Order item lookup (`lookup_items`) bumped 50 → 100; index.php now loads
>   `datepicker.js` so the ship-date range uses the themed picker.
> - **Results are grouped by PO (2026-07-13):** one card per `customer_po_number`, listing
>   each part with its own line/ship status, detail grid, and allocation bar — only the lines
>   matching the search/filters appear. Customer part-number search stays cross-branch (§8.1)
>   but now honors the status/date filters (the old cross-branch OR bypassed them). On-hand
>   reads from **column AC** (index 28) as a positional fallback (§34).

The MVP was **run and verified end-to-end** on a fresh machine (the §12 dev box was a
different computer — this one started bare).

- **Environment stood up here (portable, no-admin), matching §12:** PHP 8.3.32 NTS →
  `C:\Dev\tools\php` (php.ini extensions enabled); MariaDB 11.4.9 → `C:\Dev\tools\mariadb`,
  data at `C:\Dev\tools\mariadb-data`, started via a recreated `C:\Dev\tools\start-db.ps1`
  on 127.0.0.1:3306; DB `order_entry` + user `oe_app`; `app/config/config.php` written
  (gitignored). Setup path that works from scratch:
  `php app\bin\bootstrap_admin.php <email> <pw>` → `php app\bin\seed_demo.php` →
  `run-dev.ps1`.
- **Bug found by running (now fixed):** `migrate.php`/`bootstrap_admin.php` split SQL files
  on `;` with a naive `explode`, which broke on a **semicolon inside a `--` comment** in
  `auth.sql`. Centralized a comment-stripping `run_sql_script()` in `db.php`; both bin
  scripts now use it. (The schema files were fine — only the PHP splitter was wrong.)
- **New dev helper:** `app/bin/seed_demo.php` — inserts a few `items` + `order_lines`
  (branches 1932 & 1918) so New Order / Price Lookup / Order Search work **without** the
  real Oracle exports. Idempotent: skips if `items` already has rows.
- **Smoke tests (24 assertions, all green):** admin login/CSRF/nav; order search + admin
  price columns; price lookup; pricing & contacts pages. Customer flow: request access →
  admin approve (role+branch) → token set-password → login → **branch scoping** (sees own
  1932 orders; blocked from 1918 by branch#, but **finds 1918 by part#** per §8.1) →
  **role gating** (no Unit Price) → **submit new order** (`1932-500123`) → confirmation →
  **notification hook logged**, routed to the plant contact (`littlerock-orders@…`).
- **Result:** every MVP screen works against real PHP + MariaDB. Only email delivery (#3)
  remains stubbed (logs instead of sends).

## 19. Email notifications wired (roadmap #3 complete, 2026-07-06)

The last MVP gap. New orders now email the plant contact over SMTP via **PHPMailer**,
routed by the Contact directory (§17). Built to degrade safely and swap providers by
config alone.

- **PHPMailer vendored (no Composer):** `app/lib/PHPMailer/` (v7.1.1 src + LICENSE),
  `require`d directly by `app/src/mailer.php`. The prod IIS box needs no Composer.
- **Config-driven transport:** a `mail` block in `config.php` (host/port/user/pass/
  encryption/from). `app/src/mailer.php::send_email()` builds the SMTP message; it
  **never throws** (returns `[ok, error]`).
- **`notify.php` now sends:** resolves the plant contact → builds a text+HTML order
  summary (lines, qty, tier price, total) → sends if enabled → **always** writes an
  audit line to `app/storage/notifications.log` (`SENT` / `SEND FAILED: …` /
  `LOGGED ONLY` / `SKIPPED`). Wrapped so a mail problem **cannot break order
  submission** (the order is already committed).
- **Resting default = OFF.** `config.php` ships `mail.enabled = false` so orders never
  fail on a box without SMTP (they just log). Turn-on modes documented in-config:
  - **Local test:** a capture server on `127.0.0.1:1025`, `enabled=true`, encryption `''`.
  - **POC:** Mailtrap sandbox (`sandbox.smtp.mailtrap.io:2525`, `tls`, creds).
  - **Prod:** company relay / Brevo.
- **Verified live (this machine):** installed `aiosmtpd`, ran a local catcher on :1025,
  enabled mail, and submitted an order **through the web app** → PHPMailer delivered a
  multipart message **to `littlerock-orders@example.com`** (the A10 plant contact) with
  subject `New order 1932-500999 — Little Rock Assembly (A10)` and the correct
  qty-tier total ($10 × 250 = $2,500). Log line: `SENT`. Also confirmed the direct
  `notify_new_order()` path. Mail then set back to disabled + catcher stopped.
- **Known follow-ups:** send is **synchronous** (a slow relay adds up to `Timeout=10s`
  to order submit — a queue/async send is a future nicety); no retry on transient
  failure (logged, not requeued); magic-link login (§8.1) still Phase 2.

### 🎉 MVP COMPLETE
All six roadmap items (§11) are built **and verified live** on real PHP + MariaDB:
Foundation, Auth, Order entry (**incl. email**), Search, Admin pricing + contacts, and
Imports. Remaining work is hardening/Phase-2 (HTTPS + prod hosting at go-live, async
email, quoting module, magic-link, supplier scraping) — not MVP.

## 20. Submitted-orders list (post-MVP, 2026-07-06)

Closes the §15 gap "no order-history list page (view is by direct id)". Portal-entered
orders (`site_orders`) now have a browsable list — separate from **Order Search**, which
reads the *imported Oracle* `order_lines` and only shows an order after the plant keys it
into Oracle and it re-imports.

- **Page (`app/public/my-orders.php`), nav label "Submitted":** table of portal orders
  newest-first — PO, plant, status, line count, total, submitted-at, View link. Customers
  see **only their branch**; admins see **all branches** (with a Branch column).
- **Helper `list_site_orders(?branch, limit)` in `app/src/orders.php`:** aggregates line
  count + total per order. `LIMIT` is inlined as a cast int (native prepares mis-bind a
  placeholder inside `LIMIT`).
- **Access:** login required; branch scoping mirrors the order-view rule (`order.php`).
- **Verified live:** admin sees both demo orders + Branch column; customer sees only
  their branch's, no Branch column, no admin nav. 7/7 assertions green.

## 21. Quoting module — Bid Prep + Costed BOM + Cost roll-up (Phase 2 start, 2026-07-07)

> ⚠️ **Heavily reworked 2026-07-15 by overhaul Batch 2 — see §36** (new page header, Pre-Bid
> field changes, spreadsheet BOM + per-line price breaks, Labor Breakdown replaces Cost
> roll-up, new Quote Summary with Transfer/Sale prices, Search-or-Create landing). The data
> model, cost_rollup() legacy math, and one-save/auto-revision mechanics below still apply
> where §36 doesn't supersede them.

First slice of the **Phase 2 quoting module** (§8/§11): an admin/quoting-side workspace
that mirrors the plant's quote workbook (`Examples/Example Quote template.xlsx`). The
workbook's four sheets map 1:1 onto four durable tables and one page.

- **Reference → data model.** `Bid Preb` (Pre-Bid Proposal) → **`quotes`** (the must-have +
  additional header info: customer, part #, quote/TSG/Kit-SIM #, description, revision,
  branch, sales roles, EAU, dates, and the yes/no qualifiers + notes). `Costed BOM` →
  **`quote_bom_lines`** (level, customer P/N, MFG item, description, UOM, qty-per, type, MOQ,
  FLM, lead time, manufacturer/supplier/SIM, standard cost). `Cost page` →
  **`quote_cost_tiers`** (per build-qty: labor rate/hours, burden, OSP, margin). `Quote Rev`
  → **`quote_revisions`** (rev #, date, approved-by, description). Schema in
  `app/sql/quotes.sql` (all `IF NOT EXISTS`, `ON DELETE CASCADE` from `quotes`); applied by
  `app/bin/migrate.php`.
- **Cost math is computed, never stored stale.** `quotes.php::cost_rollup()` reproduces the
  workbook's Cost-page formulas from the BOM material cost + tier inputs:
  material/unit `E = Σ(standard_cost × qty_per)`; burdened material `F = E/(1−burden)`;
  labor/unit `G = rate×hours/(1−burden)`; transfer `I = F+G+OSP`; resale `J = I/(1−margin)`.
  **Verified to the cent against the sample workbook** (qty-25 row: F 2053.12, G 82.06,
  I 2135.18, J 2846.90).
- **Pages:** `app/public/quotes.php` (list + "start new quote") and `app/public/quote.php`
  (the workspace — Bid Prep form, Costed BOM add/edit/delete with a live material-cost
  footer, Cost roll-up with computed resale, and the revision log). Helpers in
  `app/src/quotes.php` (whitelisted-column updates; no field is writable unless in the
  `QUOTE_FIELDS`/`BOM_FIELDS`/`COST_TIER_FIELDS` maps).
- **Access:** **admin-only** (`require_admin`) on both pages — the whole module carries
  cost/margin data, which the §8.2 customer-visibility rules forbid exposing to branches.
  A **Quotes** nav link was added for admins across every page.
- **Verified live** (PHP 8.3 + MariaDB, this machine): migration applied the four tables;
  a headless test passed cost math + full CRUD (create → save header → BOM lines → material
  roll-up → tier → revision → cascade delete, 20/20 checks); and an authenticated HTTP
  click-through created a quote, populated all four sections, and rendered the workspace with
  the correct computed resale ($6,217.65) and material footer ($3,894.00). Auth gate
  (logged-out → login), 404 on missing quote, and BOM edit-prefill all confirmed.
- **Known limitations / next up:** no PDF/Excel export of a finished quote; no "promote a
  won quote into assembly tiered pricing / an order" hand-off; BOM line reordering is by
  insertion order (no drag). ~~Per-line volume price-break curve (the workbook's S–X
  tiered-purchase columns)~~ — **dropped per Matt (2026-07-13): components do NOT get a
  tiered-pricing section on the quote page**; each line carries one standard cost.

> **2026-07-13 — workspace redesign (per Matt).** `quote.php` became a single-form workspace:
>
> - **One Save for everything.** A sticky Save bar at the bottom submits the whole page
>   (header + every BOM line + cost tiers) as one atomic `save_quote_all()` transaction.
>   JS dirty-tracking lights the bar up ("Unsaved changes…") the moment anything is edited
>   and warns before navigating away unsaved.
> - **Every save that changes anything auto-logs a revision.** The save diffs each field
>   against the DB and writes ONE `quote_revisions` row (auto rev # 01, 02…; date; saved-by
>   = the admin's email) whose new `changes` TEXT column lists every change —
>   `Eau: — → 500`, `BOM PDGXAC: Qty Per 2 → 3`, `BOM removed: X`, `Cost tier added…`.
>   A save with no changes logs nothing. The manual "log a revision" form was removed
>   (the log is automatic now); rev rows remain deletable.
> - **Components are added ALL AT ONCE, not one line at a time.** The per-line add/edit
>   forms were removed. A bulk box takes one `PART # [qty]` per line (whitespace-separated —
>   part numbers contain commas); on Save each part auto-fills description, UOM, type
>   (WES-ETO → Sub Assembly, else Purchase Item), MOQ, FLM, lead time (export days → weeks),
>   supplier, SIM and **standard cost** from the item warehouse via
>   `bom_autofill_from_item()` — cost resolves **frozen cost → assembly tier price (the
>   Pricing-page quotes) → buy list price**. Parts not in the item master are still added
>   (part # only) with a warning. **The app-wide `%` wildcard works here too** (added
>   2026-07-13 per Matt): `320%` expands to every item-master part starting with 320 (each
>   line logged with the pattern it matched); no match → warning, and a pattern matching
>   more than 50 parts is refused so a stray `%` can't add the whole catalog. Existing BOM lines + cost tiers are edited **in place**
>   (inline inputs; a Details toggle holds the rarer fields; ✕ checkboxes mark rows for
>   removal on Save; a blank bottom row adds a cost tier).
> - **The header Part Number autofills its tied fields** (added 2026-07-13 per Matt):
>   on quote creation AND on every save, `quote_part_autofill()` resolves the PN against
>   the item master (the `%` wildcard works here too, but only when it names exactly ONE
>   part — else it's left as typed with a warning) and fills **Description, Kit SIM #
>   (items.sim_number) and Plant/Org** (items.organization's leading token → orgs by
>   inventory_org or plant_code). Only EMPTY fields are filled — typed values are never
>   overwritten — and save-time fills are logged in the revision like any other change
>   (e.g. `Part Number: 320% → 320FP23,00`).
> - `src/quotes.php` now requires `src/pricing.php` (tier-price fallback) — pricing's
>   quote-list helper was renamed `list_price_quotes()` to avoid colliding with the
>   quote-workbook `list_quotes()`.

## 22. Magic-link (passwordless) sign-in (Phase 2, 2026-07-07)

The auth fast-follow the Bible flagged three times (§8.1, §14, §15). A user can now sign in
with a **one-time link emailed to them** — no password, and no admin needed to hand-issue a
set-password link every time. Reuses the email transport from §19 and the token pattern from
§14.

- **New durable table `login_tokens`** (`app/sql/auth.sql`) — same shape as `password_tokens`
  (sha256-only, single-use, expiring) but **separate**, so a sign-in link can never be
  confused with a set-password link. Applied by `migrate.php`/`bootstrap_admin.php`.
- **Token lifecycle in `app/src/auth.php`** (pure DB/session, no mail dependency):
  `issue_login_token()` (20-min TTL, invalidates the user's prior unused link),
  `find_valid_login_token()`, and `login_with_token()` — which consumes the token
  **atomically** (`UPDATE … WHERE used_at IS NULL`, `rowCount()===1`) so a link can't be
  replayed even under a double-click race, then `session_regenerate_id(true)` + sets the
  session (identical to password login).
- **Mail/orchestration in `app/src/magic.php`** (kept out of the always-loaded `auth.php` so
  PHPMailer isn't pulled into every page — mirrors `notify.php`): `request_and_send_magic_link()`
  looks up the **active** user, issues a token, builds the link, and sends via `send_email()`
  — or, when `mail.enabled=false`, writes the link to `app/storage/notifications.log`
  (server-side only) as the honest stand-in. `app_base_url()` reads `config.app.base_url` or
  derives it from the request.
- **Page `app/public/magic-login.php`:** GET `?token=…` consumes + signs in; the bare page
  shows an "email me a link" form; POST sends it. `login.php` now links to it ("Email me a
  sign-in link instead"). New optional `app.base_url` config key (blank = derive from request;
  set at go-live) in both `config.php` and `config.example.php`.
- **Security posture (verified live):** **no account enumeration** — a request for any address
  returns the same "if that email has an active account, a link is on its way" message, and the
  raw token is **never** shown to the requester (emailed, or logged server-side when SMTP is
  off); single-use + 20-min expiry; inactive/disabled accounts get no link; tokens stored as
  sha256 only. Verified end-to-end through the running app: request → grab logged link →
  click → session established (protected page 200) → **replay blocked** (session not
  authenticated) → non-existent email yields the identical message. Plus headless checks for
  expiry, re-issue invalidation, and inactive-user rejection.
- **Known follow-ups:** ~~no per-email/IP rate limiting on link requests~~ **DONE (§25)**;
  email send is synchronous
  (shared with §19's note); requires SMTP to be turned on for real delivery (rests OFF, logs
  instead — same safe default as order email).

## 23. Branded emails + onboarding set-password email (2026-07-07)

Two things: outbound email now actually **sends** (not just logs), and the onboarding
approval **emails** the set-password link instead of the admin copy-pasting it — closing
the last §14 gap. All emails share one branded template matching the site.

- **Live SMTP (dev):** `config.php`'s `mail` block is wired to a personal **Gmail** app
  password over SMTP (`smtp.gmail.com:587`, STARTTLS) and `enabled => true`. This is the
  self-service stand-in until the app is on the company network / a domain sender — the
  transport is provider-agnostic (Gmail / Brevo / SMTP2GO / company Exchange relay are all
  just a config swap; see the in-file notes). Deliverability from a personal Gmail is
  spam-prone for automated mail — the durable fix is a domain sender with SPF/DKIM/DMARC.
- **Shared branded template — `app/src/email_theme.php`:** `email_wrap($heading, $bodyHtml,
  $preheader)` renders the site look (navy header band, Order​Entry wordmark, white card,
  footer) with table + inline styles so Gmail/Outlook render it; `email_button()` is a
  bulletproof CTA. Used by all three outbound emails: the magic-link email (§22, rewritten
  to use it), the onboarding set-password email, and the order-notification email (§19).
- **Onboarding now emails the link — `app/src/account_mail.php`:** `email_password_link($email,
  $link, $isNew)` sends a branded "set your password" email on **approve** and on **reset**
  (`admin-users.php`). Returns `[sent, err]`; the page **falls back to showing the link
  on-screen** when mail is disabled or a send fails, so onboarding never breaks on a box
  without SMTP. New `user_email_by_id()` helper in `auth.php`. Always audit-logged
  (`ACCOUNT-MAIL … SENT / SEND FAILED / LOGGED ONLY`).
- **Verified live:** a real Gmail send landed in the inbox; the themed **magic-link** email
  was received and its link signed the user in; and an **admin approval through the web UI**
  emailed the branded set-password link (`SENT`) with **no on-screen link leaked** (fallback
  only shows when mail is off). 
- **Known follow-ups:** personal-Gmail deliverability (spam) — move to a domain sender for
  production; no send rate-limiting yet.
- **Order-notification email branded (2026-07-07):** `notify.php::notify_build_message()` was
  moved onto `email_theme.php` (meta block + inline-styled line-item table). All three emails
  now share the site look. Verified live — a themed order preview delivered to the inbox.

## 24. Self-service password reset (2026-07-07)

Closes the last §14 auth gap. A user can now reset their own password without an admin —
built almost entirely from existing plumbing (issue token → email branded link →
`set-password.php`), so there was no new token machinery.

- **Page `app/public/forgot-password.php`** (public, linked from `login.php`): enter email →
  POST → uniform "if that email has an active account, a reset link is on its way" message.
- **`account_mail.php::request_and_send_password_reset($email, $baseUrl)`:** finds an **active**
  account, issues a set-password token (`issue_password_token()` — invalidates prior unused),
  and emails the branded reset link via the existing `email_password_link(..., isNew:false)`
  ("Reset your password" wording). Pending (needs admin approval) and disabled accounts get
  **no** token; unknown emails do nothing — all return the **same** message (no enumeration),
  and the raw link is never shown to the requester (emailed, or logged server-side when mail
  is off — there's no admin in this flow to relay it).
- **Shared helper centralized:** `app_base_url()` moved from `magic.php` into `email_theme.php`
  (now used by all three email link builders — magic-link, set-password, reset); the duplicate
  in `magic.php` was removed.
- **Verified:** enumeration safety (active issues a token; unknown / pending / disabled issue
  none, all with the identical response), the issued token sets a working password
  (round-trip), the page renders + links from login, POST returns the uniform message, and a
  real reset email was delivered to an active-account inbox. 5/5 headless checks + live HTTP.
- **Known follow-ups:** ~~send rate-limiting~~ and ~~password-complexity~~ — both **DONE (§25)**.
  Auth polish is complete.

## 25. Auth hardening — rate-limiting + password policy (2026-07-07)

The last two auth polish items (§22/§24 follow-ups). With these, **the auth system is
feature-complete.**

- **Fixed-window rate limiter** — new durable table `auth_rate_limits` (one self-resetting
  row per `sha256(action|key)`) + `auth.php::rate_limit_hit($action, $key, $limit, $windowSec)`
  returning `[allowed, retryAfterSec]`. **Fails open** on any DB error so a limiter bug can
  never lock users out. `client_ip()` helper (REMOTE_ADDR; add X-Forwarded-For behind a
  trusted proxy at go-live). Wired into the public endpoints:
  - `login.php` — 10 / 10 min per IP (brute-force slowdown).
  - `magic-login.php` & `forgot-password.php` — 8 / 15 min per IP **and** 4 / 15 min per typed
    email. The block message is neutral ("you've requested several… wait a few minutes"), keyed
    on the *typed* email so it never reveals whether an account exists.
  - `request-access.php` — 6 / hour per IP (signup-spam guard).
  Admin actions (approve / reissue) are unthrottled — already behind admin auth.
- **Password policy** — `auth.php::password_policy_error()` (min **10** chars, must include a
  letter **and** a number, rejects a small common-password list). `set_password_with_token()`
  now enforces it (replacing the 8-char-only check), so it applies to onboarding, admin reset,
  and self-service reset alike; `set-password.php` updated (`minlength=10` + hint).
- **Verified:** 10/10 headless checks (limiter allows→blocks→isolates by key/action, sane
  retry-after; policy accepts/rejects the right inputs) **and** a live run — hammering
  `magic-login.php` with one email got 4 accepted then blocked. Schema applied via `migrate.php`.
- **Known follow-ups:** IP detection is `REMOTE_ADDR` only (fine on the PHP built-in server;
  needs `X-Forwarded-For` handling once behind IIS/a proxy); limiter is per-app-server (fine for
  a single box).

## 26. Contact page → Program Assignments list (2026-07-08)

Per Matt's request, the old plant-contact/branch **Contact Directory** page was **replaced**
with a **Program Assignments** contact list modeled on `Examples/Contact_list.xlsx`.

- **Model / columns:** Customer · PM (Program Manager) · **Plant Order Inbox** · Plant site ·
  Sales Contact · Sales Branch · BDM. The spreadsheet's row-1 tags mark **Plant Order Inbox as
  the only "Admin View" column** — so it's shown/edited by admins only; every other column is
  visible to all roles.
- **Access:** **admins add / edit / delete** any row; **sales & customers are view-only** (no
  edit form, no row actions, and the Plant Order Inbox column is omitted entirely — not just
  hidden — so the email never reaches a non-admin's HTML). Non-admin POSTs are rejected 403.
  *(Role note: the app still has only `customer`/`admin`; "sales team" = non-admin viewer. Add a
  dedicated `sales` role later if the two need to diverge.)*
- **Data:** new durable table `program_assignments` (`app/sql/contacts.sql`) seeded with the
  **105 rows** from `app/sql/seed_program_assignments.sql` (generated from the workbook; loaded
  by `migrate.php` only when the table is empty). Helpers `list/get/save/delete_program_assignment`
  in `app/src/contacts.php`. The page has a **search** box (customer / contact / branch / PM / BDM).
- **What stayed:** the legacy `plant_contacts` + `branches` tables remain (still read by
  `notify.php` for order-email routing); only their **admin UI** was removed with the old page.
- **Verified live:** 105 rows seeded; search works; admin add/edit/delete round-trips; the
  customer/sales view shows the list **without** the Plant Order Inbox column or email and returns
  403 on edit attempts.
- **Known follow-up:** order-notification routing still uses `plant_contacts`, not the new
  `Plant Order Inbox` — wire that in if orders should go to `3908orders@wescodist.com`.

## 28. Account setup v2 — company defaults, titles, address book, ship methods (2026-07-08)

Reworks §27 per Matt's 6-point spec. **Supersedes the §27 data model** (per-branch bill-to →
admin global defaults; phone → title; single ship-to → an address book).

- **Admin global defaults (`admin-defaults.php`, `company_defaults` single row):** admins set a
  default **bill-to AND ship-to** that **pre-fill every new account's** setup. New "Defaults"
  admin nav link. (Matt #1, #2.)
- **"Your info" (`account-setup.php`):** Full name + **Title** dropdown (Buyer / Inside Sales Rep /
  Outside Sales Rep / …) + **Branch** shown read-only from the account request. (Removed the old
  company & phone fields.) (Matt #3.)
- **Bill-to** subnote is now exactly **"Verify Bill-To-Address Below. Will Auto-Populate On Future
  Orders"** with a verify checkbox. (Matt #4.)
- **Ship method** block at setup — shipping terms, method (UPS Ground, R&L Freight…), carrier
  account #. (Matt #5.)
- **Account settings page (`account.php`, nav "Account"):** customers add/change profile + bill-to,
  and keep **multiple ship-to addresses and multiple ship methods** with a **★ default** each.
  (Matt #6.)
- **New Order:** ship-to and ship-method are **dropdowns** of the customer's saved options (default
  pre-selected); bill-to shown read-only. The **chosen** ship-to/method + bill-to are snapshotted
  onto the order (`site_orders.ship_to/bill_to/ship_method`) and shown on the order view + email.
- **Data model (`profile.sql`):** `company_defaults`, reshaped `customer_profiles`
  (name/title/bill-to + `default_ship_id`/`default_method_id`/`setup_complete`),
  `customer_ship_addresses`, `customer_ship_methods`. `profile.php` rewritten. `migrate.php` does a
  one-time drop of the §27-shape `customer_profiles`/`branch_billing` (brand-new feature, no prod
  data) and adds `site_orders.ship_method`.
- **Verified live end-to-end:** admin sets defaults → new customer gated to setup with those
  defaults pre-filled → finishes (creates first ship-to + method as defaults) → adds a 2nd of each
  on the Account page → New Order shows both in dropdowns → an order submitted with the **non-default**
  choice snapshots the chosen West-DC / R&L-Freight correctly. Admins not gated. All files lint-clean.
- **Follow-ups:** no address validation; ship-method is free text (could become a managed list);
  "sales team" still = any non-admin (no dedicated `sales` role).

## 27. Customer account setup (post-approval profile) (2026-07-08) — SUPERSEDED by §28

Per Matt: after a plant admin approves an account, the customer is **prompted to finish account
setup** — Amazon-style info that then **autopopulates their orders**.

- **Forced setup gate:** `require_login()` redirects any **customer** whose profile isn't
  `setup_complete` to `account-setup.php` (admins exempt; `account-setup`/`logout`/`set-password`
  exempt to avoid a loop). So the first login after approval lands on setup.
- **What's captured (`account-setup.php`):**
  - **Your info** — full name, phone, company.
  - **Ship-to location** (per user) — attention, street, city/state/ZIP, country. *Finalized* by
    the customer.
  - **Bill-to location** (per **branch**, shared by everyone on that branch) — **auto-fills** from
    the branch's saved bill-to; the customer **confirms** (checkbox required). First user of a
    branch enters it; later users just confirm.
- **Data model:** `app/sql/profile.sql` → `customer_profiles` (per-user, incl. `setup_complete`)
  and `branch_billing` (per-branch bill-to). `app/src/profile.php` (get/save/`profile_complete`,
  `format_ship_to`/`format_bill_to`). `site_orders` gained `ship_to`/`bill_to` snapshot columns
  (added via a portable `add_column_if_missing()` in `migrate.php`).
- **Autopopulation:** `new-order.php` shows the ship-to + bill-to (from the profile/branch,
  with an "edit in account setup" link) and **snapshots** them onto the order; `order.php` and the
  **order-notification email** now display Ship-to / Bill-to.
- **Verified live:** an incomplete customer is redirected to setup from every page; submitting
  setup saves the profile + branch bill-to and flips `setup_complete`; New Order then shows the
  autopopulated addresses; a submitted order snapshots both; admins are not gated.
- **Assumptions / follow-ups (confirm with Matt):** bill-to is **per-branch shared** (his note
  said the saved bill-to is used for every branch — if he means one company-wide bill-to, it's a
  small change); one ship-to per user (no address book yet); no address validation; "sales team"
  = any non-admin (no dedicated `sales` role yet — same note as §26).

## 29. Menu nav, Settings + address books, admin account view (2026-07-08)

Matt's 6-point follow-up on account UX.

- **Shared header + menu system (`app/src/header.php` → `render_header($active)`):** the top
  tab-bar is replaced by a **☰ Menu** dropdown (all destinations, role-gated) and a **user
  dropdown** (click the email → **Settings** / Sign out) — native `<details>`, no JS. Every page
  now renders its header from this one partial (converted `index`, `new-order`, `order`,
  `my-orders`, `contacts`, `quotes`, `quote`, `admin-pricing`, `admin-users`, `admin-defaults`),
  ending the per-page nav churn. (Matt #1, #3.)
- **Title is free text** with placeholder examples (`e.g. Buyer, Inside Sales Rep, Outside Sales
  Rep`) instead of a dropdown. (Matt #2.)
- **Settings hub (`settings.php`):** account info (name/title editable; branch/email read-only),
  two cards → **Ship-To Addresses** and **Bill-To Addresses**, plus ship-method management.
  Replaces the old `account.php` (deleted). (Matt #3, #4.)
- **Address books (`addresses.php?type=ship|bill`):** one parameterized page lists a customer's
  saved addresses as cards; the current default shows a **★ Default** badge, others get a **Set To
  Default** button; add/edit/delete. **Bill-to is now an address book too** (new
  `customer_bill_addresses` table + `default_bill_id`), mirroring ship-to. Changing the default
  auto-populates it on the next order. (Matt #4, #5.)
- **New Order:** ship-to, bill-to, and ship-method are all dropdowns of the customer's saved
  options, each defaulting to the chosen default; the picked ones snapshot onto the order.
- **Admin "View Account Information" (`admin-user-account.php`):** a button on the Users page opens
  a read-only view of any user's signup info + all their ship-to / bill-to addresses + ship
  methods (defaults flagged). (Matt #6.)
- **Schema:** `profile.sql` v3 — `customer_profiles` drops the single bill-to (→ book) and gains
  `default_bill_id`; new `customer_bill_addresses`. `migrate.php` drops the pre-v3 profiles table
  (no prod data) and recreates. **Supersedes §28's bill-to model.**
- **Verified live end-to-end:** menu + user dropdown render; free-text Title; fresh customer gated
  → setup pre-filled from admin defaults → completes (creates ship+bill+method defaults) → Settings
  cards → added a 2nd bill address and **Set To Default** → New Order defaulted to it and the
  submitted order snapshotted the new default (Reno); admin View-Account page shows it all. All
  pages 200 for both roles; lint clean.

## 31. Admin edit-user, Defaults removed, multi-field wildcard search (2026-07-08)

- **Admin can edit any user's account** (`admin-user-account.php`): the read-only "View Account
  Information" page is now **fully editable** — profile (name/title), ship-to & bill-to address
  books (add/edit/delete + Set-To-Default), and ship methods — all operating on the target user
  (`?id=`, carried as a hidden `uid` on every form). The per-user `save_*`/`set_default_*` helpers
  already took a `$uid`, so admin just acts on the target. Still `require_admin` (403 otherwise).
- **Defaults removed:** the admin "Defaults" page + menu tab are **deleted** (`admin-defaults.php`
  gone, dropped from `header.php`). Removed the `company_defaults` prefill from account setup and
  the now-unused `get/save_company_defaults()` helpers. (The dormant `company_defaults` table is
  left in place, unreferenced — harmless.) **Supersedes §28's "admin global defaults" piece.**
- **Order Search + Price Lookup — centered, multi-field, `%` wildcard:** the single search box is
  replaced by a **centered panel** of separate fields — Order Search: PO # / Order # / Part # /
  Description (+ Branch for admins); Price Lookup: Part # / Description / Qty. Each field is an
  **exact match**, or a **`LIKE` wildcard when it contains `%`** (user-controlled — `%123%` =
  contains, `123%` = starts-with), with an on-screen tip explaining `%`. New
  `pricing.php::search_items()`; customer branch-scoping preserved (part # stays cross-branch per
  §8.1; customers don't get a Branch field).
- **Verified live:** admin edited a customer's name/title + added a ship-to; Defaults 404s and is
  off the menu; multi-field search returns correctly for exact and `%`-wildcard on both pages;
  customer search has no Branch field and part # works cross-branch; all touched pages 200.

## 32. Wesco brand theme + macOS dev environment (2026-07-09)

The site was restyled to **Wesco's actual brand**, and a runnable **macOS dev environment** was
stood up on Matthew's Mac (previously the app had only ever run on the Windows box).

- **Brand palette (from wesco.com):** charcoal-navy `#1D252D` + **Wesco green `#00AA13`**, white
  cards, generous whitespace, **Source Sans 3** typeface. Green is the accent / primary-CTA color;
  money-green kept for prices & confirm; a muted red is used **only** for errors/delete, never as brand.
  *(A first pass used a generic corporate red; corrected to the real green/charcoal after reading
  wesco.com's live CSS.)*
- **Logo:** the official green folded-**"W"** mark (from Matt's `wesco_logo.svg`) is the brand mark in
  the shared header and on all auth pages, with a lowercase **"wesco"** wordmark + an "Order Entry" tag.
- **One design system:** `app/public/style.css` was rebuilt around CSS variables (`:root` tokens), so the
  whole UI re-themes from one place; every component maps onto the tokens. Shared brand lockup lives in
  `app/src/header.php`; the five auth pages share the `.brandbig` lockup.
- **Bug fixed in passing:** a header `overflow:hidden` (added for a faint diagonal-line motif) was
  clipping the ☰ Menu / user dropdowns — removed (the motif is bounded by its own `inset:0`).
- **macOS dev env (Homebrew, no-admin):** `php@8.3` (`/opt/homebrew/opt/php@8.3/bin/php`, keg-only) +
  `mariadb` via `brew services`. DB `order_entry` + `oe_app`/`oe_app_dev_pw`. `app/config/config.php`
  adapted for the Mac (`import_dir` → a local folder; **mail OFF** — the committed config still carries a
  live Gmail app password). Shared snapshot loaded (`migrate.php` → `load_snapshot.php`). Admin login
  reset to a known dev credential. New **`run-dev.sh`** = the Mac equivalent of `run-dev.ps1`
  (serves `app/public` at http://127.0.0.1:8000). Verified live end-to-end on the Mac.
- **Order Search results → cards + animations (2026-07-09):** the wide horizontally-scrolling Order Search
  results **table** was replaced with per-line **cards** (`.order-card` in `index.php`/`style.css`) — a big
  monospace PO# header, colour-coded line/ship **status pills** (blue = in-progress, green = done), the item
  + description, and a labeled **field grid** (Ordered/Shipped qty, tracking, dates, invoice; admins also get
  Unit/Ext Price, Unit Cost, Sched Ship, Plant per §8.2). Added a sitewide **animation layer**: fade-up
  entrance for result/list cards with a light stagger, pop-in for dropdowns + address-suggestion menus, a
  `main` fade-in — all behind a `prefers-reduced-motion` guard.
- **Follow-ups:** Source Sans loads from Google Fonts (needs internet; falls back to system sans offline)
  — self-host at go-live if offline rendering matters; ~~the branded **emails** (`email_theme.php`) were
  **not** rethemed to the new palette yet~~ **DONE 2026-07-09** — `email_theme.php` now uses the Wesco
  charcoal `#1D252D` header with the "ASSEMBLIES" wordmark + green "Order Entry" tag, green `#00AA13`
  buttons (matches the site). Also fixed an email **encoding bug**: `mailer.php` never set `CharSet`, so
  PHPMailer defaulted to ISO-8859-1 and UTF-8 chars (the `·` separator in ship-method) rendered as
  mojibake (`Â·`) in Outlook — now `CharSet = 'UTF-8'`.

## 33. Address autocomplete + country/state dropdowns + verified-address gate (2026-07-09)

Re-introduced address autocomplete (the §30-era Google Places version had been removed to avoid an
external key) as a **no-key, provider-swappable** system, and added a hard **verified-address gate**.

- **Suggestions (as-you-type):** **Photon** (OpenStreetMap, no key) via `app/public/address-suggest.php`.
  Typing a partial street returns real matches; picking one **autofills** city / state / zip / country
  in the same field group. (Photon replaced the US Census `onelineaddress` endpoint, which only matched
  fully-typed addresses and so couldn't do typeahead.) **Typeahead-quality overhaul (2026-07-09)** —
  Photon (free, no-key OSM) is a weak autocomplete engine, so `geocode_suggest()` does the ranking itself
  and works around its quirks:
  - **We rank results ourselves, by TEXT SIMILARITY only, not Photon and not geography.** Photon orders
    by global prominence, which buries the match being typed. We ignore its order and sort purely by
    **`geocode_match_score()`** — how similar each candidate is to the typed text (starts-with bonus >
    whole-string-contains > per-word exact/prefix/substring, plus a fine-grained `similar_text()`
    tiebreak), scored against the full `street city state` line so that **typing a city lifts the right
    city** (`233 south main st little rock` → the Little Rock one; `1600 pennsylvania ave washington` → DC;
    `350 fifth avenue new york` → NYC). Geography is deliberately NOT a ranking factor — `657 midland dr`
    ranks an Ogden UT and a Mena AR "657 Midland Drive" side by side by similarity, not by distance. (Matt,
    2026-07-09: "closest" means most *similar*, not geographically near.) An earlier same-day pass used a
    distance-to-plant tiebreak; that was removed. NB: Photon's `location_bias_scale` is **ignored** by its
    public server (tested), so we can't lean on its bias for ranking.
  - **House-number stripping + re-attach.** Photon, when the query contains a house number, returns *only*
    features that have that exact number — so a street with no house numbers mapped in OSM (common for
    warehouse/industrial roads, e.g. `West 69th Street, Little Rock`) is excluded the moment you type
    `3601`, and partial typing (`657 mid`) degrades to odd global house-number matches. We strip a leading
    house number before querying (when ≥3 chars of street text remain), then **re-attach the typed number**
    to street results — so `3601 W 69th St` yields the pickable `3601 West 69th Street, Little Rock, AR
    72209` even though OSM has no `3601` point on that road. Too-short remainder (`3601 W`) → query as typed.
  - **Country restriction — US / CA / MX only.** Photon has no country-filter query param, so
    `geocode_suggest()` drops any result whose `countrycode` isn't `US`/`CA`/`MX` (with a country-name
    fallback) via `geocode_allowed_country()` — matching the app's only supported country/state dropdowns.
    No more Poland/Australia/etc. suggestions; Canada and Mexico addresses still flow through.
  - **Road objects vs. address points.** A road feature carries its name in `name` with `street` empty
    (`type == "street"`); address points/POIs carry it in `street`. We read `street`, falling back to
    `name` only for `type == "street"`, and skip anything with no usable street line (drops bare
    house-number / region junk).
  - **Region bias config — retrieval only.** The query is biased toward the plant via
    **`config.geocode.bias_lat/bias_lon`** (default Little Rock, AR; blank disables) ONLY to improve which
    candidates Photon returns (without a hint its retrieval is poor — `south main` comes back as Chicago
    "State Street"). It never affects ordering, which is text-similarity only.
  - **Honest limits.** Photon can't invent data it lacks (e.g. a famous `350 Fifth Avenue, NYC` may not
    surface well), and ZIP autofills at street level for unmapped house numbers. For production-grade CASS
    autocomplete, swap the adapter to Google Places / Smarty (the code is structured for it — one file).
- **Country + dependent State dropdowns:** the plain country/state text inputs are **upgraded to
  `<select>`s** by JS (progressive enhancement — degrade to text inputs without JS). Countries = US /
  Canada / Mexico, each with full subdivisions; the State list depends on the chosen country. Data lives
  once in the client; provider state names (e.g. "Illinois") map onto the option codes (`IL`).
- **Address-save gate — blocks clearly-incomplete input (⚠ RELAXED 2026-07-09, see changelog):**
  - **Server-side (authoritative):** `save_ship_address()` / `save_bill_address()` in `app/src/profile.php`
    call `geocode_verify()` — covers the address books, the admin edit-user page, **and** account-setup;
    can't be bypassed by disabling JS. **Client-side** shows an inline error + preserves input before submit.
  - **Verifier is now a lightweight sanity check** (`geocode_verify`): accepts any well-formed address
    (street name + city + state + ZIP); rejects only "35"-style junk (no street name) and missing fields.
    The earlier strict **two-tier Census + Photon confirm** was removed — it kept false-rejecting real
    warehouse/industrial addresses whose exact house-number point isn't mapped (e.g. a *suggested*
    "West 69th Street, Little Rock" that Photon returns with no house number). Trade-off: typo'd/fake streets
    now pass; the Photon *suggestions* still steer users to real addresses. Restore the strict confirm from
    git history if go-live needs CASS-grade validation.
- **Files:** shared `app/src/geocode.php` (`geocode_suggest` + `geocode_verify`, provider-swappable in one
  place); JSON endpoints `address-suggest.php` + `address-verify.php`; client `address-autocomplete.js`
  (prefix-aware — handles plain `addr1` and `ship_`/`bill_` prefixed fields). Wired into `addresses.php`,
  `admin-user-account.php`, `account-setup.php`. Data © OpenStreetMap contributors (Photon) + US Census.
- **Verified live:** partial-typeahead suggests; pick → autofills with correct state code; country→state
  dependency switches lists; junk "35" blocked client-side (inline error, input kept) **and** server-side
  (bypassing JS → flash error, not saved); real picked address saves.
- **Follow-ups:** swappable to Google Places / Smarty later by replacing the adapter functions in
  `geocode.php`. Verification adds a ~1s geocoder call per **save**; the single-threaded `php -S` dev
  server briefly blocks during it (non-issue on prod IIS/FPM). `X-Forwarded-For` / prod hardening TBD.

## 34. Admin Import page + shared import library (2026-07-09)

Per Matt: an admin **Daily Import** page + a one-button pull of **today's** item + order reports from
the Oracle export server shares. Built so **Claude never sees the data** — the code only reads whatever
files sit in the server's configured folders at runtime.

- **Per-feed source folders — committed default in `app/config/sources.php`.** Each feed reads from its
  OWN folder (item warehouse vs RG report, different server shares). Resolution: `config.php`
  `import_sources[$key]` override → **committed `sources.php`** → `import_dir` fallback. The real prod
  UNC shares are baked into `sources.php` (committed like config.php), so the **work computer needs NO
  config edit** — they arrive on `git pull`:
  `\\brwn-1931-fls-01\B1931\public01\#Oracle\Daily Exports\A10\item_warehouse_all` (items) and
  `…\all-org RG\A10` (orders). **These resolve on the Windows work computer, not the Mac.** (Doubled
  backslashes in the single-quoted PHP strings; UNC starts with `\\\\`.)
- **Launchers auto-migrate.** `run-dev.ps1` (Windows) and `run-dev.sh` (Mac) now run
  `php app/bin/migrate.php` on every launch (idempotent — only adds missing tables/columns), so a fresh
  `git pull` needs **no separate migrate step**. Just run the launcher.
- **DATE-PINNED to today (per Matt).** The importer pulls the file whose name carries **today's date** —
  `import_item_pattern()` = `lr_item_warehouse_all_<Y-m-d>.xlsx`, `import_order_pattern()` =
  `*_daily_rg_<Y-m-d>.csv`. On 2026-07-19 it looks for `…_2026-07-19.*`; the date auto-advances daily. So
  it never silently re-imports a previous day's leftover file (this replaced the old "newest file" logic
  and made the earlier erase-deletes-files behaviour unnecessary — see below).
- **Shared library `app/src/import.php`** — one code path for the page AND the CLI. `import_items($dir,$date)`
  and `import_order_lines($dir,$date)` (both default `$dir`→`import_source(...)`, `$date`→today),
  `import_items_source()` / `import_orders_source()`, `import_source($key)`, `import_matching_files()`
  (scandir + `fnmatch`, **not glob** — safe on UNC paths + folder names with glob metachars like `#Oracle`),
  `erase_items()` (DB only), `count_items()`. **Atomic replace:** delete + reload in one transaction
  (`DELETE`, not `TRUNCATE`, so a failed load **rolls back**). Each returns `['ok','file','count','error']`,
  never throws.
- **`erase_items()` is LOCAL-DB-ONLY now.** The earlier `erase_item_files()` (deleting the drop-folder
  file on erase) was **removed** — the source is now the shared Oracle export server share, and deleting
  the company's exports off it is unsafe; date-pinning already prevents stale re-imports. Erase just
  truncates the `items` table.
- **Page `app/public/admin-import.php`** ("Daily Import", `require_admin`, **Import** nav link): shows the
  **items-loaded** stat, "Looking for files dated `<today>`", and a status block per feed (Item warehouse /
  RG report) — folder path + the exact filename it wants today + a **today's-file-found / not-found /
  folder-unreachable** pill. One **Import today's reports** button pulls BOTH feeds; **Erase item data**
  (confirm modal) clears the local catalog only.
- **`app/bin/import.php`** calls the library (`import_items()` + `import_order_lines()`, default today) —
  same code as the button, for the morning OS-scheduled job.
- **Verified live (Mac, scratch folders w/ dated files):** date-pinning picks today's `…_2026-07-13.*`
  and ignores an old `…_2026-07-01.*`; a missing date fails cleanly; the button imported 2 items + 2 order
  lines; UNC paths resolve to the correct `\\…` string. Real UNC run happens on Windows.
- **Zero-touch on the work computer (2026-07-13):** paths moved to committed `sources.php` + launchers
  auto-migrate, so the work computer just needs `git pull` + run `run-dev.ps1` — no config edit, no manual
  migrate. (`config.php` stays uncommitted/env-specific: mail, `import_dir`, geocode.)
- **Columns captured (2026-07-13):** the item import now also stores **`frozen_cost`** (Oracle standard
  cost; ADMIN-only like `list_price` — feeds the Pricing page's cost display, §16). `primary_uom` was
  already captured. The RG order-line import now also captures **`On Hand Qty` → `order_lines.on_hand_qty`**,
  which drives the order-search stock allocation (§18).
- **Duplicate rows MERGE, not last-row-wins (2026-07-13, per Matt).** The real export's duplicate
  (org, item) rows carry different populated fields (sourcing on one row, planning on another); the
  upsert previously let a later sparse row wipe populated values with blanks. The duplicate handler now
  merges per column (`COALESCE(NULLIF(VALUES(col),''), col)`) — a value is only replaced by a non-blank
  value. Also added alternate-column fallbacks when the primary is blank: MOQ ← `approved_min_order_qty`,
  FLM ← `approved_flm`, Supplier ← `vendor_name`. Verified with a synthetic sparse duplicate row
  (populated sourcing survived; the dup's one new field landed).
- **Follow-ups:** in-app scheduler (the "certain time every morning" goal — currently via OS scheduler);
  import summary history.

## 35. Site overhaul — Batch 1 (2026-07-14, per Matt's "Order Entry updates and Overhaul.xlsx")

Executed as a multi-agent pipeline per §10 (Sonnet workers on disjoint file sets, fresh-context
Sonnet verifier; all items passed). Source spec: `Order Entry updates and Overhaul.xlsx`
(Downloads), items 1–3 & 5–8; items 4a/4b (Quoting Presets + Quote revamp) are Batch 2.

- **Nav & page renames (overhaul item 1, per the embedded mockups):** `header.php` gained
  **top-bar quick links** right of ☰ Menu — **Order Status** (index.php) + **New Order** —
  active-highlighted. Menu is now: Order Status · Components · New Order · **Pending**
  (my-orders.php, was "Submitted") · **Contact list** · Quotes/Import/Users (admin). The
  **Pricing and Price Lookup menu items are GONE**; `admin-pricing.php` is still reachable by
  direct URL until Batch 2 retires it (decision 2026-07-14: quotes' Transfer Price becomes the
  New Order pricing source; tier data kept in DB). index.php is titled **"Order Status"**; its
  old `?page=price` view was removed (falls back to order search).
- **Simplified order statuses (item 5):** each line's displayed status maps from the RG
  **Line Status** (col J): Closed→**Shipped**, Cancelled→**Cancelled**, Awaiting Shipping/
  Entered→**Open**, Awaiting Return→**RMA** (case/space-insensitive, `map_line_status()` in
  index.php; unknown raw values shown as-is in grey — the PO-summary pills key off label+class
  so an unmapped value that collides with a bucket name keeps grey). The two old Order-/Ship-
  Status filters became ONE **Status** filter (the 4 buckets). **"Promise Date" now displays as
  "Target Ship Date"** (data still from the RG Promise Date column).
- **Collapsible PO cards + sort (items 6–7):** each PO renders as a `<details>` card,
  **collapsed by default** — summary = PO#, order#/date, line count, per-status pill counts;
  **open lines listed before closed** inside. Sort = **field selector** (Cust PO # / Request
  Date / Order Date / Actual Ship Date) **+ asc/desc control**, computed over PO groups
  (min/max of the group's dates), replacing the old single sort dropdown.
- **Components page + Material Stats feed (item 3):** Price Lookup is replaced by
  **`components.php`** — search **plus a per-plant availability grid** (org × on-hand qty, UOM,
  demand, excess, aged/months-inactive) from the new **`material_stats`** table.
  **⚠ Re-scoped 2026-07-15 (per Neal):** this is an **EXPERIMENTAL quoting aid for RAW
  MATERIALS/components only** — now **ADMIN-ONLY**, **assemblies (WES-ETO) excluded entirely**
  (they're priced on the Quote page / ordered on New Order), and component prices come
  **straight from the item warehouse** (list price + frozen cost), never from quotes/tiers.
  If it proves useful, the same lookup may be embedded in the quote page (see §11 Phase-2 #4). New daily feed (§34 pattern, date-pinned, atomic replace):
  `all_orgs_material_stats_<Y-m-d>.xlsx` (sheet `df_oh`) from
  `\\brwn-1931-fls-01\B1931\public01\#Oracle\Daily Exports\All Orgs\material_stats` (committed
  in `sources.php`); third feed block on the Daily Import page + CLI. Items present only in
  material_stats (no item-master row) show as "Availability only" cards. `bin/import.php` now
  resolves **each feed's own source folder** (was overriding all feeds with `import_dir`).
- **Contact list editing + canonical customers (item 8):** admins can **edit rows in place**
  and add lines; the Customer field is a **datalist type-ahead over a new canonical `customers`
  table** (seeded once from the 105 program_assignments rows → 102 unique names,
  case-insensitive UNIQUE). Unknown names are **rejected** unless the explicit "add new
  customer" checkbox is used — kills TKE/ThyssenKrupp/TkE duplicates. §26 gating unchanged
  (non-admins view-only, no Plant Order Inbox column, 403 on POST).
- **Address autocomplete fix (item 1-addendum):** root cause of "typed addresses don't find
  real addresses" was **config drift, not code** — this box's `config.php` was missing the §33
  `geocode.bias_lat/bias_lon` block (present in config.example.php), which silently disabled
  Photon retrieval bias. Restored (Little Rock 34.7465/-92.2896); the exact user case
  `3601 W 69th St` now suggests `3601 West 69th Street, Little Rock, AR 72209` first and
  autofills city/state/zip/country. ⚠️ **Check the Windows box's config.php for the same
  missing block.**
- **Folder-lock answer + `stop-dev.ps1` (item 2):** `app\public` can't be deleted because
  run-dev.ps1 starts php.exe **hidden with app\public as its working directory**; closing
  windows doesn't stop it — not an app bug. New **`stop-dev.ps1`** kills the dev server (by
  recorded PID, fallback to any php.exe; `-IncludeDb` also stops MariaDB) so the folder can be
  deleted/replaced.
- **Mail flipped back OFF on this Mac** (`config.php mail.enabled=false`) — it had drifted to
  `true` against the CLAUDE.md rule and a pipeline test triggered a real Gmail send.

## 36. Site overhaul — Batch 2: quoting (2026-07-14/15, per Matt's overhaul spreadsheet items 4a/4b)

Same pipeline as §35 (Sonnet workers, fresh-context Sonnet verifier — all sections passed; two
verifier flags fixed by the orchestrator and re-verified). Interrupted mid-batch on 07-14,
resumed cleanly 07-15.

- **Quoting Presets (`quoting-presets.php`, admin-only, nav after Quotes):** per-plant editable
  quoting info that auto-fills quotes — **Engineering Labor Rate, Production Labor Rate, Plant
  Burden Materials, Plant Burden Labor**. New durable `quoting_presets` (one row per
  `inventory_org`; burdens stored as FRACTIONS matching `quote_cost_tiers`, UI shows percent;
  collation pinned `utf8mb4_general_ci` to match orgs). Helpers in `app/src/presets.php`
  (`labor_rate_for($org, 'Production'|'Engineering')`, `get_quoting_preset()`); dev data: A10
  85/45/15%/20%, AA1 90/50/10%/18%.
- **Quote workspace revamp (`quote.php` + `src/quotes.php` rewritten):**
  - **New page header:** Customer (canonical `customers` dropdown) · Assembly Plant (orgs
    dropdown) · Part Number · auto-generated **Quote Number** (`Q-<YYYY>-<seq>`,
    `generate_quote_number()`, assigned on create/first save) + prominent current Rev.
  - **Pre-Bid Proposal:** REMOVED TSG #, new-build/currently-manufactured, facility/outside-
    supplier, FAI, C of C, UL Label (DB columns kept). ADDED **Program manager** (auto-filled
    from `program_assignments` by customer + plant, empty-only, JS + save-time) and
    **Customer Quality requirements** (free text).
  - **Costed BOM = spreadsheet:** bulk add-all-at-once box REMOVED; inline-editable rows +
    **"+ New Line"**; typeahead autofill on MFG item/description via new authenticated
    `quote-item-suggest.php` (contains-match, **excludes Obsolete item_status**) filling Type
    (WES-ETO→Sub-Assembly, WES-PUR-RE→Buy item, WES-OSP→OSP), description, part #, UOM, MOQ,
    FLM, Supplier, Supplier Item. **Type dropdown sits right of Lvl**; NO Details toggle —
    every field always visible (wide grid, in-card scroll). **Per-line price breaks** (new
    `quote_bom_price_breaks`, CASCADE) always visible as sub-rows; a line with breaks
    auto-resolves **Std Cost from its MOQ** against them. **Sub-assembly rows grey out / null**
    Std Cost, Ext Cost, MOQ, FLM, Manufacturer, Project Supplier, SIM/Supplier Item, Quote #,
    Crossed Items (client + server). *(Reverses the 2026-07-13 "no per-component tiers" call —
    Matt's overhaul spec explicitly asks for visible tiered pricing per component.)*
  - **Labor Breakdown** (replaces "Cost roll-up" heading): rows of Labor Type (Production/
    Engineering, FIRST column) · Build qty · Labor rate (**auto from type + plant via
    presets**; typed rate wins) · Hours — nothing right of Hours. `quote_cost_tiers` gained
    `labor_type`; its burden/osp/margin columns are legacy-only (removed from the save/diff
    field map — they'd logged false revision changes, caught & fixed in build).
  - **NEW Quote Summary block** (new `quote_summary_tiers`, UNIQUE quote+build_qty, CASCADE):
    per build-qty tier — Component cost (Σ BOM std×qty-per, computed) · Labor cost (computed)
    · Burden (auto from presets) · **Margin keyed-in with grey 25% placeholder (blank ⇒ 25%)**
    · **Transfer Price = material/(1−burden_mat) + labor/(1−burden_labor)** · **Sale Price =
    Transfer/(1−margin)**. Live JS recompute + authoritative save-time compute; margins/breaks
    logged in the auto-revision history. Verified to the cent (e.g. A10, mat $8, labor $88.75
    @25 → transfer 120.3493; sale @25% = 160.4657).
  - One-save atomicity + **auto up-rev on any change** retained (no-op saves log nothing).
- **Quotes landing (`quotes.php`) = Search-or-Create:** search by Quote # / Customer / Part #
  (app-wide `%` wildcard rule) with per-row **Edit** → workspace (saving up-revs, per above);
  Create (customer + plant + part) → new quote → straight into the workspace; recent-15 list
  by default; Delete retained (full CASCADE verified).
- **🔴 New Order pricing switch (decision 2026-07-14):** `price_for_item()` now prices
  assemblies from the **most recent quote's transfer price** (tier = largest build_qty ≤ qty;
  below the smallest tier ⇒ smallest tier) via `pricing.php::quote_transfer_price()`; **legacy
  `assembly_pricing` tier is the fallback** for parts with no quote. Buy-item list-price path
  unchanged. Price source is **snapshotted** (`site_order_lines.price_source` =
  `quote:Q-2026-NNNN` / `legacy-tier`) and shown in the cart. **Components page uses the same
  resolution** (fixed post-verification — it had still shown legacy tiers, disagreeing ~10×
  with order entry on the demo part; now identical + source-tagged).
- **`admin-pricing.php` DELETED** (§16 retired; table + helpers kept for fallback/history).
- **Misc fix from verification:** the New Order "clear order" link was dead in real browsers
  (a `<form>` nested in `<p>` gets reparented, breaking `nextElementSibling.submit()`) —
  replaced with a link-styled submit button inside its own form (`.clear-order-link`).
- **Verifier env note:** Browser-pane coordinate clicks were unreliable on this box (fell back
  to `form_input`/`requestSubmit()`); server-side flows fully verified via HTTP either way.

## Changelog

- **2026-07-15 (Components re-scoped: raw materials only, admin-only, warehouse pricing)** —
  §35/§11: per Neal, Components is an experimental quoting aid for COMPONENTS, not assemblies:
  reverted the same-day change that priced assemblies there from quote transfer prices (that
  "inconsistency" was correct-by-design — component cost vs finished-assembly price), excluded
  WES-ETO from its search entirely, pricing now item-warehouse only (list price + frozen cost),
  page + nav item now admin-only. Recorded the refined spot-market vision (distributor APIs —
  DigiKey/Mouser first — not scraping; maybe embedded in the quote page later) in §11 Phase-2
  #4. Verified live: assembly search returns nothing, PDGXAC shows the $10 daily-file price,
  material-only availability cards intact, anonymous → login redirect.
- **2026-07-15 (Site overhaul Batch 2 — quoting)** — §36: Quoting Presets page (per-plant labor
  rates + burdens), quote workspace revamp (new header w/ generated Q-number + Rev, Pre-Bid
  field swap incl. PM autofill, spreadsheet BOM w/ typeahead + price breaks + sub-assembly
  grey-out, Labor Breakdown, Quote Summary w/ Transfer/Sale math), quotes Search-or-Create
  landing, **New Order assembly pricing switched to quote transfer prices** (legacy tier
  fallback, source snapshotted per line), `admin-pricing.php` deleted (§16 retired),
  Components page repointed to the same price resolution, "clear order" form bug fixed.
  Independently verified (math re-derived by hand, up-rev/no-op behavior, role gating,
  obsolete exclusion, cascade deletes). §21 partially superseded.
- **2026-07-14 (Site overhaul Batch 1)** — §35, per Matt's overhaul spreadsheet: top-bar quick
  links + page renames (Order Status / Components / Pending / Contact list; Pricing & Price
  Lookup off the nav), 4-bucket status mapping + single Status filter + "Target Ship Date"
  label, collapsed-by-default PO cards (open lines first) + field/direction sort controls,
  new `components.php` + `material_stats` daily feed (3rd import block), contact-list inline
  edit + canonical `customers` table with reject-unknown rule, address-autocomplete fix (missing
  geocode bias block in this box's config.php — check Windows box too), `stop-dev.ps1` for the
  php.exe folder-lock, per-feed source resolution in `bin/import.php`, mail flipped back OFF on
  the Mac. Verified by an independent click-through (admin + customer sessions); two cosmetic
  finds (stale nav key on components.php, summary-pill color on label collisions) fixed and
  re-verified. Batch 2 (Quoting Presets + Quote revamp + pricing-page retirement) next.
- **2026-07-13 (Order search: PO grouping, filter fix, on-hand from column AC)** — §18/§34, per Matt:
  (1) results now render **one card per PO**, listing each part number with its own line/ship status,
  detail grid, and stock-allocation bar — instead of a separate card per line (`$byPo` grouping in
  index.php; new `.po-card/.po-line` styles). Only lines matching the search/filters appear in a block.
  (2) **Filter fix:** a customer part-number search was cross-branch via an OR that *bypassed* the
  status/date filters — rewrote the customer query so a part search is cross-branch but ALL filters still
  apply (verified: VR-2 + Ship=Shipped now returns only the shipped line, not the awaiting one). Admin
  filtering was already correct. (3) **On Hand Qty** now reads from **column AC** (0-based index 28) as a
  positional fallback after the named-header match, since that's where the RG report keeps it — verified
  it populates even under a mismatched header. Verified live: PO 1932-100010 shows 3 parts with distinct
  statuses; adding a Ship-Status filter drops the shipped part and empty POs.
- **2026-07-13 (RG import: tolerant header matching for On Hand Qty)** — §34: made the RG order-line
  import match column headers case/spacing-insensitively (normalise → lowercase, single-spaced) and
  added spelling fallbacks for on-hand (`On Hand Qty` / `Onhand Qty` / `On-Hand Qty` / `On Hand
  Quantity` / `Qty On Hand`), so `order_lines.on_hand_qty` populates even if the real report's header
  differs slightly. NOTE for the work computer: the feature needs **git pull → run the launcher (auto-
  migrates the new `on_hand_qty` column) → re-run the import** (the importer DELETE+reloads, so a fresh
  import is required to fill the new column); then the allocation shows on admin Order Search for OPEN
  lines. Verified end-to-end against a synthetic RG file with On Hand Qty populated (400 → 375 → 175).
- **2026-07-13 (Order search: filters moved to a filter/sort bar below the search box)** — §18: per Matt,
  relocated Order Status / Ship Status / ship-date range / Sort out of the main search grid into a
  dedicated "Filter & sort" card that sits under the search box and above the results, styled to match
  the site (card, focus glow, fadeUp entrance, themed datepicker at full size). The bar auto-applies on
  change (same GET form; Search button is the no-JS fallback). Verified live: bar renders below the card
  / above results, dropdown change auto-submits preserving the text search, and the calendar opens
  full-size. Follow-up: the ship-date calendar was being painted OVER by the result cards below it (they
  out-stacked the overflowing popup) — fixed with `.ordersearch { position: relative; z-index: 10 }`
  (kept under the header's z-40 so its menu still overlays), so the full calendar renders on top.
- **2026-07-13 (Order search: filters, sort, on-hand stock allocation)** — §18/§34: per Matt. Added
  Order Status + Ship Status dropdowns, an actual-ship-date range, and a sort (most-recent-invoice /
  soonest-request; text dates parsed via STR_TO_DATE tolerant of M/D/YYYY + ISO). Imported the RG
  'On Hand Qty' into `order_lines.on_hand_qty` (schema + migrate add-column) and built the headline
  feature: an admin-only per-line stock-allocation bar that spreads an item's on-hand across its open
  orders in request-date order (soonest-due first), showing available-to-this-line + covered/short.
  `allocate_on_hand()` in src/orders.php computes across ALL of the item's orders, not just the result
  set. New Order lookup bumped 50 → 100; index.php now loads datepicker.js. Verified live to Matt's
  exact numbers (400 on hand → 375 available for the 200 order; last order short 25) plus each filter
  and sort. Demo seed reworked to stage the scenario (3 branches, 320FP23,00 × 4 open orders).
- **2026-07-13 (datepicker: month-nav no longer closes the calendar)** — fixed a bug where clicking the
  `‹`/`›` month arrows closed the calendar. Root cause: the nav click re-renders `pop.innerHTML`, which
  detaches `e.target`; the document-level outside-click handler then read `pop.contains(e.target)` as
  false and closed it. Fix: `e.stopPropagation()` on clicks inside the calendar so they never reach the
  outside-click handler (intentional closes still fire via `close()`). Affects `datepicker.js` — every
  date field in the app benefits (pricing popup, quote page, order entry). Verified live: paged
  Jul→Aug→Sep→Oct→Sep with the calendar staying open, and an outside click still closes it.
- **2026-07-13 (Pricing page: one Update per part; one date pair per item)** — §16: per Matt, the
  search results now show ONE **Update** button per part (header of the item block; per-row
  Update/Delete removed — tier removal lives in the popup) and ONE quote/expire date pair for the
  item's entire tier set (shown once per block with the Expired badge; edited once in the popup;
  every save re-syncs the pair across all the item's rows — storage stays per-row, kept identical).
  Popup tier rows are now just qty + price. Verified live: popup shows a single date pair (no per-row
  dates), expire follows a quote-date change (+3 mo), and a save stamped all 3 tiers of 320FP23,00
  with the same pair.
- **2026-07-13 (Pricing page: Update → all-tiers edit popup; price editable again)** — §16: per Matt,
  Update now opens a modal with the item's whole tier set — qty, price, quote/expire dates all editable,
  "+ New tier" button (auto dates today/+3mo), ✕ removal, one atomic "Save all" (`save_item_quotes()`).
  This also supersedes the same-day "price is never typed" pass: the price input is back everywhere;
  BLANK still auto-grabs the daily file's frozen cost per one unit (`resolve_unit_price()`), typed
  overrides. Verified live: override $6.25 + blank→$5 auto + new tier 100 in one save; row removal;
  legacy blank dates reset to today/+3mo. Follow-up per Matt ("box needs to be bigger to see the
  date"): modal widened 680→960px; dropped the modal table's `.tablewrap` (its overflow-x clipped the
  calendar); un-squeezed the calendar (`.modal .modaltiers .dp { max-width:none }` — the 300px popup was
  shrinking to its table cell); datepicker.js `scrollIntoView`s the calendar on open so it's never
  below the fold.
- **2026-07-13 (item import: duplicate rows merge; alternate-column fallbacks)** — §34: per Matt ("all
  info listed as — can be found in the item warehouse all reports"), fixed why populated report fields
  showed as "—" on the site: the real export's duplicate item rows carry different populated fields and
  the upsert's last-row-wins let sparse rows blank out good values. Duplicates now MERGE per column
  (non-blank wins), and blank primaries fall back to the report's alternate columns (MOQ ←
  approved_min_order_qty, FLM ← approved_flm, Supplier ← vendor_name). Verified with a synthetic sparse
  duplicate. NOTE: the 2-row zeroed example file genuinely has blank sourcing fields for 320FP23,00, so
  dev still shows "—" there — the fix shows up against the real work-machine report.
- **2026-07-13 (Price Lookup card: full item-warehouse info + buy-item price)** — §13/§18: per Matt
  ("missing frozen cost … all necessary info is in the item warehouse template, plus a part not shown"),
  the Price Lookup card now shows everything the daily file carries: **UOM, Status, Lead time** (all
  roles) and **Frozen cost $/unit (ADMIN-only, §8.2)**; buy items — admin-only by construction, e.g.
  PDGXAC — now get a real **price line from the daily file's list price** (× qty) beside the "Buy item"
  badge instead of a bare sourcing-info badge. This deliberately re-adds what the 52e6980 revert removed
  — that revert was "back to original BEFORE adding anything new", and this is the new, asked-for shape.
  `search_items()` selects the extra columns. Verified live (320FP23,00: frozen $5/unit, UOM Each,
  lead 20 days; PDGXAC: $10/ea × 5 = $50 + full sourcing block).
- **2026-07-13 (Pricing page: unit price auto-grabbed from the daily file)** — §16: per Matt (asked +
  answered: source = **frozen cost**, behavior = **auto-set on save**), the Pricing page's unit price is
  no longer typed. `save_tier()` pulls the item's frozen cost (per one unit) from the daily item file at
  save time; the Create/Update form shows a disabled price preview; an Update refreshes a quote to the
  current daily price; items missing from the file (or without a frozen cost) can't be quoted (clear
  error). Listed prices are therefore always the one-unit daily-file price as of the quote date.
  Verified live (320FP23,00 saved at its $5 frozen cost; not-in-master part refused). Domain note:
  new-order auto-pricing reads these tiers, so assemblies now sell at Oracle frozen cost.
- **2026-07-13 (Quote workspace: one Save + auto revision log + bulk BOM autofill)** — §21: `quote.php`
  is now a single form with a sticky bottom Save — header, every BOM line (edited in place), and cost
  tiers save together atomically, and any save that changed something auto-logs a `quote_revisions` row
  (auto rev #, new `changes` TEXT column) listing every field that moved; no-change saves log nothing.
  Components are added all at once via a bulk `PART # [qty]`-per-line box that autofills description/UOM/
  type/MOQ/FLM/lead/supplier/SIM/standard-cost from the item warehouse (cost: frozen cost → assembly tier
  price → list price). Per-line add/edit forms and the manual revision form are gone; per-component
  tiered pricing is explicitly out (per Matt). Also: Pricing page now shows saved price quotes ONLY
  after a search (no default full listing); renamed pricing's helper to `list_price_quotes()` (collision
  with quoting's `list_quotes()`). Verified live end-to-end (bulk add w/ auto-fill + not-found warning,
  inline qty edit, row removal, tier add, rev 01/02 logs, no-op save). Follow-up the same day:
  the bulk box honors the app-wide `%` wildcard — a pattern expands to every matching item-master part
  (>50 matches refused; no match warns), verified live (`PDG%` → PDGXAC autofilled, `%NOPE%` → warning).
  Second follow-up: the header **Part Number now autofills its tied fields** (Description, Kit SIM #,
  Plant/Org) from the item master on create and save — wildcard resolves when it names exactly one part,
  empty-fields-only so typed values survive, fills logged in the revision. Verified live on Matt's own
  `320%` quote (resolved to `320FP23,00` + 3 autofills logged as rev 02) and at creation (`PDG%` → PDGXAC
  fully prefilled).
- **2026-07-13 (Pricing page → "Assembly Pricing Quotes" + frozen cost import)** — §16, §34: rebuilt
  `admin-pricing.php` to Matt's Excel mockup — Search Quotes panel (part-# search over saved quotes) +
  Create/Update New Quote panel. Every quote now has a **quote date** (autofills today, editable) and an
  **expire date** (autofills +3 months, follows the quote date until manually set); quotes past their
  expire date get an **"Expired"** badge + row highlight (legacy date-less rows show "No dates").
  Item import now also captures **`items.frozen_cost`** (Oracle standard cost, ADMIN-only), shown with
  UOM throughout the pricing page. Schema: `assembly_pricing.quote_date/expire_date` +
  `items.frozen_cost` via `migrate.php` column-adds (idempotent, no reset needed). Verified live
  (create → expired flag → search → update round-trip). Open q for Matt: should order entry warn when
  it prices from an expired quote?
- **2026-07-13 (item import — upsert on duplicate key)** — §34: the REAL Oracle item export contains
  duplicate `(organization, item_number)` rows (e.g. `3908 - Little Rock Assembly (MFG)` / `THT-22-423-2`),
  which violated `items.uq_item` and rolled back the whole item load ("0 items loaded"; the RG feed of
  11,939 lines imported fine). Changed the item INSERT to `INSERT … ON DUPLICATE KEY UPDATE` (dedupe,
  last row wins); reported count is now the actual unique rows via `count_items()`. First surfaced live on
  the work computer — the zeroed example file had no dupes.
- **2026-07-09 (Daily Import — date-pinned dual-folder pull)** — §34: reworked the import per Matt.
  Per-feed source folders via new `config.import_sources` (items + RG report come from different Oracle
  server UNC shares — real prod paths under `\\brwn-1931-fls-01\…`, resolve on Windows). The importer is
  now **date-pinned to today** (`lr_item_warehouse_all_<Y-m-d>.xlsx` / `*_daily_rg_<Y-m-d>.csv`, auto-advancing
  daily) so it never grabs a stale day's file. One **"Import today's reports"** button pulls both feeds;
  the page ("Daily Import") shows per-feed today's-file status. File matching switched glob→scandir+fnmatch
  (safe on UNC + `#Oracle`-style names). **Removed `erase_item_files()`** — erase is local-DB-only now
  (never delete the company's exports off the shared server). Verified live with dated scratch files
  (picks today, ignores old, clean miss).
- **2026-07-13 (zero-touch work-computer setup)** — §34: moved the per-feed UNC paths into committed
  `app/config/sources.php` (so no `config.php` edit is needed on the work computer), made `import_source()`
  resolve override→sources.php→import_dir, and made `run-dev.ps1`/`run-dev.sh` auto-run the idempotent
  `migrate.php` on launch. Result: on the work computer it's just `git pull` + run the launcher — nothing
  else. `config.php` remains env-specific/uncommitted. Verified: defaults resolve to the real `\\…` paths;
  migrate re-runs clean.
- **2026-07-09 (admin Import page + shared import library)** — §34: added `app/src/import.php` (shared
  by the page + CLI; atomic delete-in-transaction replace of `items`/`order_lines`; never throws),
  refactored `app/bin/import.php` onto it, and built admin-only `app/public/admin-import.php` (Import
  + Erase buttons, drop-folder + next-file status, confirm-modal on erase) with an **Import** nav link.
  Gitignored the `import_data/` drop folder. Base for the automatic morning refresh (schedule the CLI
  for now). Built so Claude never accesses the data — code only reads the server's configured folder.
  Verified live (CLI + both buttons).
- **2026-07-09 (themed custom date picker)** — §15: the native browser date-picker calendar can't be
  CSS-themed, so replaced it with a self-contained on-brand picker (`app/public/datepicker.js` + `.dp*`
  styles): Wesco charcoal/green calendar, month nav, green selected day, disabled past days (honors
  `min`), Clear/Today. Progressive enhancement — hidden ISO `delivery_date` input submits with the form;
  native input still works without JS. Verified live: opens themed, next-month nav, picking Aug 20 sets
  display "Aug 20, 2026" + hidden "2026-08-20", past days disabled.
- **2026-07-09 (email spreadsheet format + Shipment Ref # + UOM + date-field theme)** — §15: reworked the
  plant email per `Excel Examples Folder/Order email tweaks.xlsx`. Meta is now a **bordered spreadsheet
  grid** in the order Date Submitted · PO # · Shipment Reference # · Entered by · Plant Site · Ship to ·
  Ship method · Bill to. Item table gained **UOM** (`site_order_lines.uom` ← `items.primary_uom`, captured
  via `find_item`/cart) and **Requested Delivery Date** columns. New optional **Shipment Reference #** field
  (`site_orders.shipment_ref`) on New Order + order view. Restyled the New Order **date field** to match the
  site + focus/hover animation (`style.css`). Migration adds `shipment_ref` + `uom`. Verified live: synthetic
  full email renders the grid + both new columns + clean `·`; a submitted order stored `shipment_ref` and
  captured UOM `EA`. (Requested Delivery Date is one-per-order shown per line — per-line TBD.)
- **2026-07-09 (URGENT flag + email retheme + email encoding fix)** — §15/§32: (1) New Order gets a
  **Mark URGENT** checkbox → `site_orders.urgent` column (+migration), red banner + `🚩 URGENT —` subject
  in the plant email, red URGENT pill on the order view. (2) Rethemed `email_theme.php` to the Wesco brand
  (charcoal `#1D252D` header, "ASSEMBLIES" wordmark, green `#00AA13` buttons) so emails match the site —
  was still the old navy "OrderEntry" look. (3) Fixed mojibake: `mailer.php` now sets `CharSet='UTF-8'`
  (PHPMailer defaulted to ISO-8859-1, so `·`/`—` showed as `Â·` in Outlook). Verified live: urgent order
  stored, email renders the Wesco theme + red URGENT banner + correct subject, order view shows the pill.
  NOTE: Mac dev box has `mail.enabled=false` (logs only); Windows has it on (Gmail) — that's why an order
  submitted on Windows emails but the same on Mac doesn't. Ship-to/bill-to/ship-method remain customer-only.
- **2026-07-09 (example export folder moved into the project)** — §8.2: the Excel/CSV example exports
  now live in-repo at `Excel Examples Folder/` (was the external Windows path
  `C:\Dev\Exported data examples\`). Updated the §8.2 location + data-constraint lines and the §11
  "Blocked on" reference. Reminder flagged: only **zeroed/scrubbed** samples may go here — real company
  data must stay out of the repo (CLAUDE.md §5); gitignore the folder if any file could carry live data.
- **2026-07-09 (New Order — Requested Delivery Date field)** — §15: added an optional **Requested
  delivery date** to the new-order flow. New `site_orders.requested_delivery_date DATE NULL` column
  (`orders.sql` + `migrate.php add_column_if_missing`), threaded through `create_site_order()`, an
  `<input type="date" min=today>` on `new-order.php` with server-side validation (valid date, not in the
  past; optional), and surfaced on the order view (`order.php`) and the plant-notification email meta
  (`notify.php`). Verified live end-to-end: submitted an order with a date → persisted → shown on the
  order page and included in the built email; all touched files lint-clean; migration added the column.
- **2026-07-09 (address suggestions — restrict to US / CA / MX)** — §33: suggestions must not offer
  countries the app doesn't support. Photon has no country-filter param, so added
  `geocode_allowed_country()` and a post-fetch drop in `geocode_suggest()` keeping only `countrycode`
  US/CA/MX (country-name fallback). Verified live: `350 fifth avenue` returns only US + Canada (no
  Australia); a Poland query (`69 brozec`) returns nothing; Toronto → all CA, Mexico City → all MX.
- **2026-07-09 (address typeahead — ranked by text similarity only, geography dropped)** — §33: refined
  the earlier same-day ranking pass per Matt — "closest" meant most *textually similar*, not geographically
  near, and the Midland example was illustrative, not a real address. Removed the distance-to-plant tiebreak
  (`geocode_distance()` deleted); `geocode_suggest()` now ranks purely by `geocode_match_score()` (starts-with
  > contains > per-word exact/prefix/substring + `similar_text()` tiebreak) against the full `street city
  state` line, so typing a city lifts the right city and the most similar address wins regardless of region.
  The plant bias stays on the Photon *query* for candidate-retrieval quality only (no bias → "south main"
  returns Chicago "State Street"), never on ordering. Verified: `233 south main st little rock` → Little Rock
  #1; `1600 pennsylvania ave washington` → DC; `350 fifth avenue new york` → NYC; `657 midland dr` → UT and
  AR ranked by similarity, not distance.
- **2026-07-09 (address typeahead — self-ranked by text match + proximity)** — §33: Matt's core complaint
  was that typing a real address gave poor/irrelevant suggestions (e.g. `657 mid` didn't surface a local
  `657 Midland …`). Root cause: Photon (free OSM geocoder) ranks by global prominence and ignores
  `location_bias_scale` on its public server, so far-away matches floated to the top. Reworked
  `geocode_suggest()` to **rank results ourselves**: `geocode_match_score()` (token-containment +
  whole-string + leading-prefix bonuses) primary, then **distance to the plant region**
  (`geocode_distance()` on Photon's returned coords) as tiebreak; bumped fetch to `limit=25`. Kept the
  house-number stripping/re-attach and road-object (`type=="street"`) fallback; removed the old
  house-number-only `geocode_suggest_score()`. Verified live in the browser UI: `657 mid` →
  Little Rock Midland/Midtown/Middle; `657 midl` narrows to Midland; `1600 penn` → all Arkansas;
  `233 south` → all Little Rock; `3601 W 69th St` → Little Rock #1. Honest limit noted: Photon can't
  surface data OSM lacks — swap to Google Places/Smarty for CASS-grade autocomplete.
- **2026-07-09 (address suggestions — house-number stripping, road-object fallback, region bias)** — §33:
  Matt couldn't get `3601 W 69th St, Little Rock AR` to appear — Photon only returns features with the exact
  typed house number, and OSM has no `3601` mapped on that warehouse road, so it fell back to Indianapolis's
  mapped `3601 West 69th Street`. Reworked `geocode_suggest()`: (1) **strip a leading house number** before
  querying (when street text remains) and **re-attach** it to street matches, so unmapped-number streets
  surface as the full address; (2) fall back to the road's `name` when `street` is empty for `type=="street"`
  features (OSM road objects) and skip streetless junk; (3) **bias toward the plant region** via new
  `config.geocode.bias_lat/bias_lon` (default Little Rock). Kept `geocode_suggest_score()` (from the earlier
  same-day pass — sinks street-only results on the non-stripped path, e.g. `3601 W` → `West Howard Street`
  last) and `limit=15` + stable sort. Verified live through the authenticated `address-suggest.php`:
  `3601 W 69th St` → #1 `3601 West 69th Street, Little Rock, Arkansas 72209`; POIs, `1600 Pennsylvania Ave`,
  and plain streets all still resolve. Added `geocode` block to `config.php` + `config.example.php`.
- **2026-07-09 (address verify → permissive sanity check)** — §33: the strict geocoder confirm was still
  false-rejecting real warehouse/industrial addresses that Photon returns without a mapped house-number
  point (e.g. the *suggested* "West 69th Street, Little Rock" — residential addresses have points, many
  warehouse ones don't). Per Matt, `geocode_verify()` is now a lightweight well-formed check: accepts any
  address with a **street name + city + state + ZIP**, blocks only "35"-style junk / missing fields.
  Removed the Census/Photon confirm helpers from `geocode.php`; Photon **suggestions** are unchanged. Side
  benefit: no more ~1s geocoder call (or single-threaded-dev-server stall) on save. Verified live. Trade-off:
  typo'd/fake streets now pass — restore the strict confirm from git history if go-live needs CASS-grade validation.
- **2026-07-09 (fixes: `%` wildcard in New Order search + address false-rejections)** — §33: (1) The **New
  Order** part search now uses the same rule as Order Search / Price Lookup — **exact match unless the term
  contains `%`** ("320" → only an item that is exactly "320"; `%320%` contains, `320%` starts-with, `%23,00`
  ends-with). Removed the old `wildcard_to_like()` contains-by-default; `lookup_items()` mirrors
  `search_items()` (`= ?` vs `LIKE ?`). (2) Address
  verification loosened from exact-house-number matching to **street + city/zip** level in
  `geocode_photon_confirm()` — real addresses whose exact house number isn't an individually-mapped point
  (e.g. "3600 W 69th St, Little Rock") are no longer falsely rejected, while junk ("35") and made-up streets
  are still blocked. Verified live.
- **2026-07-09 (wordmark → "ASSEMBLIES")** — §32: replaced the "wesco" wordmark beside the green W with
  **ASSEMBLIES** in the header (`header.php`) and on all five auth pages' `.brandbig` lockup — kept at the
  prominent wordmark size the old WESCO mark had (22px header / 26px auth, weight 700, white in header /
  charcoal on auth), sitting above the small green "Order Entry" tag. The green W mark is unchanged.
- **2026-07-09 (menu cascade fix + shine on all search/find/submit)** — §32: the dropdown-item cascade now
  restarts on each menu open — scoped to `details[open]` so the animation-name flips `none`→`ddItem` on open
  (it was running once, stale, at page load, so items appeared all at once). Extended the hover shine to the
  `.searchbar` Search/Find buttons (contacts, new-order) so every search/find/submit CTA shimmers. `style.css`.
- **2026-07-09 (micro-interactions — subtle sitewide life)** — §32: layered tasteful, mostly
  hover/action-triggered animations on top of the existing entrance/dropdown/modal layer — button
  press-feedback, a playful Wesco-"W" hover wiggle, flash-message slide-in, cascading dropdown-menu items
  (+ hover slide), settings-card arrow nudge, and a shine-sweep on the hero filled CTAs. All under the
  `prefers-reduced-motion` guard. `style.css`.
- **2026-07-09 (Users delete button + smoother warning glyph)** — §14/§32: added a **Delete** action to the
  Users page — `delete_user()` (`auth.php`) permanently removes any account (FK CASCADE clears profile /
  addresses / ship-methods / tokens; submitted `site_orders` are preserved — order view LEFT-joins the
  user). Button shown on active/disabled rows, never on your own account, behind the themed confirm modal
  with a strong message. Also swapped the confirm modal's stroked warning triangle for a smoother **filled**
  rounded one (fixes jagged thin-line corners). `admin-users.php`, `confirm-modal.js`.
- **2026-07-09 (confirm/delete modal redesign + animations)** — §32: gave the sitewide confirm modal a
  bolder look — animated SVG warning glyph in a badge with pulsing "sonar" rings, spring-pop entrance,
  staggered title/message/actions reveal, gradient top accent, and a hover shine-sweep on the confirm
  button. Applies to every destructive action (deny/deletes). Motion-safe (`prefers-reduced-motion`).
  `confirm-modal.js` + `.cmodal` styles.
- **2026-07-09 (pricing-delete confirmation — was missing)** — §16/§32: the Assembly Tiered Pricing
  **Delete** had no confirmation at all (an admin accidentally deleted a tier). Added a descriptive
  `data-confirm` (item + qty tier + price) so it now uses the themed confirm modal. `admin-pricing.php`.
  (Also restored the deleted `320FP23,00` qty≥50 → $10.00 tier from the snapshot.)
- **2026-07-09 (Submitted page → cards + "View order" modal)** — §20/§32: rebuilt `my-orders.php` from a
  plain table into themed order **cards** (matching Order Search — mono PO# header, status pill, labeled
  Lines/Total/Submitted/Branch grid, View-order footer). "View order" now opens the order detail in a
  **blurred-backdrop modal** fetched on demand from a new `order-view.php` HTML fragment (`order-modal.js`
  + `.vmodal` styles); degrades to the full `order.php` page without JS. Verified live.
- **2026-07-09 (themed confirm modal — no more native confirm())** — §32: replaced every browser
  `confirm()` dialog with one reusable on-brand modal — `app/public/confirm-modal.js` + `.cmodal` styles:
  a centered card over a **blurred/dimmed backdrop**, red "!" for destructive actions, confirm-label +
  danger styling auto-derived from the trigger button, Esc/Enter/backdrop dismiss, motion-safe. Loaded
  once from `header.php` (sitewide). All destructive forms now use `data-confirm="…"` instead of
  `onsubmit="return confirm()"` (users deny, and delete/remove across addresses, admin-user-account,
  contacts, quotes, settings). Verified live.
- **2026-07-09 (deny pending requests + control font match)** — §14/§32: added a **Deny** action to the
  Users page — `deny_user()` (`auth.php`) deletes a *pending* request (guarded to `status='pending'`, cleans
  up tokens, frees the email for a re-request); confirm-gated red button in the approve row. Also matched the
  role-`<select>` / branch-input font weight to the buttons (`.ctl` → 600). Verified (pending deleted, active
  protected).
- **2026-07-09 (Users page controls + button polish)** — §32: themed the admin approve-row role `<select>`
  (custom chevron via `.ctl`) and branch input to match the site, aligned each user's actions in a
  `.row-actions` row, and refined `.btn-sm` **globally** (consistent 34px height, hover-lift, new green
  `.ok` variant for Enable). `admin-users.php` + `style.css`.
- **2026-07-09 (order-search results as cards + animations)** — §32: replaced the wide scrollable Order
  Search results table with per-line **cards** (big PO# header, colour-coded line/ship status pills, item +
  description, labeled field grid; admins keep pricing/cost/sched/plant per §8.2). Added a sitewide
  **animation layer** (fade-up card entrances with stagger, pop-in dropdowns/suggestion menus, `main`
  fade-in) behind a `prefers-reduced-motion` guard. `index.php` + `style.css`. Verified live.
- **2026-07-09 (address autocomplete + verified-address gate)** — §33: no-key, provider-swappable address
  autocomplete (Photon suggestions) with autofill; country + dependent state dropdowns (US/CA/MX) as
  progressive enhancement; and a two-layer **verified-address gate** (client + authoritative server-side in
  `profile.php`) that blocks unreal addresses like "35". New `app/src/geocode.php`, `address-suggest.php`,
  `address-verify.php`, `address-autocomplete.js`; wired into the address books, admin edit-user, and
  account-setup. Two-tier Census+Photon verify, fail-open on total outage. Verified live.
- **2026-07-09 (Wesco brand theme + macOS dev env)** — §32: restyled the whole UI to Wesco's real brand
  (charcoal-navy `#1D252D` + green `#00AA13`, Source Sans, the official green "W" logo) via a CSS-variable
  design system in `style.css` + the shared `header.php` lockup; fixed a header `overflow` bug that clipped
  the dropdowns. Stood up a runnable macOS dev env (Homebrew php@8.3 + mariadb, adapted `config.php`, loaded
  snapshot, new `run-dev.sh`) and verified the app live on the Mac. Emails not yet re-themed.
- **2026-07-08 (admin edit-user + Defaults removed + wildcard search)** — §31: made
  `admin-user-account.php` editable (admin edits any user's profile/addresses/methods); deleted the
  Defaults page + menu tab + `company_defaults` prefill/helpers; rebuilt Order Search & Price Lookup
  as centered multi-field forms with a user-controlled `%` wildcard (`search_items()`). Verified live.
- **2026-07-08 (address autocomplete removed)** — Built Google Places address autocomplete/autofill
  (former §30), then removed it entirely at Matt/Neal's call (no external key pursued). Component JS,
  config `google.maps_api_key`, CSS, and all page hooks backed out; address fields are plain inputs again.
- **2026-07-08 (menu nav + settings/address books + admin account view)** — §29: shared
  `header.php` menu + user-dropdown (Settings), free-text Title, `settings.php` hub,
  `addresses.php` ship/bill address books with Set-To-Default (bill-to now a book:
  `customer_bill_addresses`), New Order dropdowns, and admin `admin-user-account.php`. Deleted
  `account.php`; converted all pages to `render_header()`. Verified live end-to-end.
- **2026-07-08 (account setup v2 — company defaults, titles, address book, ship methods)** — §28:
  admin `company_defaults` (bill+ship) pre-fill new accounts, `admin-defaults.php`, per-user
  ship-to address book + ship methods, Title, branch read-only. (Refined further by §29.)

- **2026-07-08 (customer account setup)** — Added post-approval account setup (§27): forced
  `account-setup.php` for customers until complete (gate in `require_login`), capturing contact +
  ship-to (`customer_profiles`) and a confirmed per-branch bill-to (`branch_billing`). New
  `profile.sql`, `app/src/profile.php`; `site_orders` gained `ship_to`/`bill_to` snapshot columns.
  New Order autopopulates + snapshots them; order view + email show them. Verified live end-to-end.
- **2026-07-08 (Contact page → Program Assignments)** — Replaced the plant-contact/branch Contact
  page with a Program Assignments contact list from `Examples/Contact_list.xlsx` (§26): new
  `program_assignments` table + 105-row seed, `app/src/contacts.php` helpers, rewritten
  `contacts.php` with search. Admins edit; sales/customers are view-only and never see the
  admin-only **Plant Order Inbox** column (403 on edit). Legacy `plant_contacts`/`branches` tables
  kept for email routing. Verified live (seed, search, admin CRUD, customer view-only gating).
- **2026-07-07 (auth hardening — rate-limit + password policy)** — Added a fixed-window rate
  limiter (`auth_rate_limits` table, `rate_limit_hit()`, fail-open) on login / magic-link /
  limiter (`auth_rate_limits` table, `rate_limit_hit()`, fail-open) on login / magic-link /
  password-reset / request-access, and a password-complexity rule (`password_policy_error()`,
  min 10 + letter&number + common-list, enforced in `set_password_with_token()`; `set-password.php`
  updated). Verified 10/10 headless + a live block after 4 requests. **Auth is now
  feature-complete** (§25).
- **2026-07-07 (self-service password reset)** — Added a forgot-password flow (§24):
  `forgot-password.php` + `request_and_send_password_reset()` in `account_mail.php`, linked from
  `login.php`. Active-only, enumeration-safe, reuses the token + branded-email plumbing and
  `set-password.php` (no new machinery). Centralized `app_base_url()` into `email_theme.php`
  (removed the `magic.php` duplicate). Verified: 5/5 behavior checks + live HTTP + a real reset
  email delivered. Closes the last §14 auth gap.
- **2026-07-07 (order email branded)** — Moved the new-order notification (§19) onto the
  shared `email_theme.php` template (meta block + inline-styled line-item table), so all three
  emails — magic-link, set-password, order notification — match the site look. Verified live
  (themed preview delivered). Closes the §23 follow-up.
- **2026-07-07 (branded emails + onboarding email)** — Turned email on for real (Gmail SMTP,
  dev) and gave every message a shared branded template (`app/src/email_theme.php`). Onboarding
  approval/reset now **emails** the set-password link (`app/src/account_mail.php`,
  `user_email_by_id()`, wired into `admin-users.php`) with an on-screen fallback when mail is
  off — closing the last §14 gap. Magic-link email reuses the same template. Verified live end
  to end (real inbox delivery, magic-link sign-in, web-UI approval emails the link). See §23.
- **2026-07-07 (magic-link sign-in — Phase 2)** — Built passwordless sign-in (§22): durable
  `login_tokens` table, token lifecycle in `auth.php` (issue/find/atomic single-use consume +
  session), mail/orchestration in a new `app/src/magic.php` (PHPMailer kept out of `auth.php`),
  and the `magic-login.php` page linked from `login.php`. Added optional `app.base_url` config.
  No account enumeration, sha256-only single-use 20-min tokens, mail-off → logs the link.
  Verified live end-to-end (request → click → session → replay blocked → no-leak) + headless
  expiry/inactive/re-issue checks. Went in Bible order per Matthew (Phase-2 §11); material/
  on-hand items deferred pending example data, so this unblocked item came next.
- **2026-07-07 (quoting module — Phase 2 start)** — Built the quoting workspace (§21) from
  `Examples/Example Quote template.xlsx`: durable `app/sql/quotes.sql` (quotes +
  quote_bom_lines/quote_cost_tiers/quote_revisions), `app/src/quotes.php` (whitelisted CRUD +
  `cost_rollup()` reproducing the workbook's burden/margin formulas), and admin-only pages
  `quotes.php` (list) + `quote.php` (Bid Prep · Costed BOM · Cost roll-up · Revisions).
  Wired into `migrate.php` and added a **Quotes** admin nav link app-wide. Verified live —
  cost math matches the sample workbook to the cent, 20/20 CRUD checks, and an authenticated
  HTTP click-through renders every section. Admin-gated (cost/margin never shown to
  customers, per §8.2). First Phase-2 feature; MVP was already complete (§19).
- **2026-07-06 (Bible reconcile)** — Refreshed the stale front matter to match reality:
  header status, §1, §2 snapshot, and §3 tech stack now describe the live PHP/MariaDB MVP;
  §4–§6 tagged **HISTORICAL** (retired React/Node/Flask prototype); cleared the obsolete
  "Blocked on" line in §11; noted the project is now on GitHub. Detail sections §8–§19
  (Neal's) left intact. Docs-only change.
- **2026-07-06 (submitted-orders list)** — Added a portal order-history page
  (`my-orders.php`, nav "Submitted") + `list_site_orders()` helper (§20). Customers see
  their branch's submissions; admins see all. Closes the §15 "no history list" gap.
  Verified live (7/7). Post-MVP polish.
- **2026-07-06 (email — MVP complete)** — Wired roadmap #3 email (§19): vendored
  PHPMailer 7.1.1 (`app/lib`, no Composer), `app/src/mailer.php` SMTP transport, and a
  rewritten `notify.php` that emails the plant contact a text+HTML order summary and logs
  every outcome (never breaking order submission). Config-driven (`mail` block), resting
  default OFF, Mailtrap/relay swap documented. Verified live end-to-end via a local
  aiosmtpd catcher — a web-submitted order delivered SMTP mail routed to the A10 contact.
  **MVP is now feature-complete and verified.**
- **2026-07-06 (live verification)** — Stood up the portable PHP 8.3.32 + MariaDB 11.4.9
  stack on a fresh machine and ran the app end-to-end (§18). Fixed a real bug surfaced by
  running — the SQL-file splitter choked on a `;` inside an `auth.sql` comment; added
  `run_sql_script()` (comment-stripping) in `db.php`. Added `app/bin/seed_demo.php` for
  export-free demo data. 24-assertion admin + customer smoke test all green, incl. branch
  scoping, role gating, order submit, and notification routing. MVP now verified live;
  only email (#3) still stubbed.
- **2026-07-06 (contact directory slice)** — Built roadmap #5's Contact directory (§17):
  durable `plant_contacts` + `branches` tables, admin edit UI (plant contact cards +
  branch add/edit/delete), customer read-only view. `notify.php` now routes order emails
  via `plant_contacts` (fallback to legacy `orgs.contact_email`). New `app/src/contacts.php`
  helpers (upserts via `VALUES(col)` for native-prepare safety). Contacts nav for all
  roles. MVP is now feature-complete except email (#3). Not yet run live here.
- **2026-07-06 (admin pricing slice)** — Built roadmap #5's Assembly Tiered Pricing
  admin page (§16): add/edit/delete tiers grouped by item, "assemblies missing tiers"
  to-do, admin-only `Pricing` nav. Moved `assembly_pricing` from the drop-and-recreate
  `schema.sql` into the durable `app/sql/pricing.sql` (so admin pricing survives data
  resets); demo tiers now seed only when empty. Added tier CRUD helpers to `pricing.php`.
  Contact directory (the other half of #5) still to build. Not yet run live here.
- **2026-07-06 (order-entry slice)** — Built roadmap #3 minus email (§15): New Order
  page with session cart, server-side auto-pricing (assembly tier / Oracle list),
  fixed-branch PO composition, plant selection, transactional submit, and a confirmation
  view. New durable tables `site_orders`/`site_order_lines`; `app/src/orders.php`,
  `notify.php` (stubbed plant-email hook logging to `app/storage/notifications.log`),
  `new-order.php`, `order.php`, and `app/bin/migrate.php`. Email to the plant is deferred
  until PHPMailer is installed — left as a one-function hook. Not yet run live here.
- **2026-07-06 (auth slice)** — Built roadmap #2: real session auth + onboarding in the
  PHP app (§14). Request-access → admin approval (role + branch) → one-time token →
  set-password → login. Added `app/src/auth.php`, `app/sql/auth.sql`,
  `app/bin/bootstrap_admin.php`, and the login/logout/request/set-password/admin-users
  pages. Retired the fake Customer/Admin URL toggle: gating + branch-scoped order search
  now driven by the session role/branch (part-number search stays cross-branch). bcrypt
  hashing, per-session CSRF, session-id regeneration, uniform login errors. Not yet run
  live here (no PHP/config on this checkout) — pending lint + click-through.
- **2026-07-01 (slice refinements)** — Per Matthew's review: (1) customers can no longer
  price buy items (WES-PUR-RE excluded from customer lookup — no margin leakage);
  (2) item lookup is wildcard-tolerant (`*`/`?`, else contains); (3) lookup card now shows
  MOQ, FLM, Supplier (sourcing rule), SIM, Supplier Item instead of item-type/Oracle price
  (added those cols to `items` + importer); (4) order search is a single box across PO#,
  order#, item#, description, and branch (removed the column picker). All verified live.
- **2026-07-01 (slice)** — Built & verified the first MVP thin slice (new PHP app in
  `app/`): xlsx+csv import, branch parsing, order search (branch/PO/part), Customer/Admin
  column gating (hides cost/price/scheduled-ship), and two-source auto-pricing. Launcher
  `run-dev.ps1` added. See §13.
- **2026-07-01 (later)** — Dev environment stood up & verified: PHP 8.3.32 +
  MariaDB 11.4.9 (portable, no-admin) with a passing PHP→PDO roundtrip. Confirmed the
  customer-visibility whitelist (no pricing/scheduled-ship on existing orders), plant/org
  keyed off rg `Inventory Org` (last col), branch = first 4 chars of PO#. Stack (PHP 8 +
  MySQL/MariaDB) approved. Next: build the thin MVP slice (import → PO#/branch search →
  auto-pricing).
- **2026-07-01** — Vision locked. Oracle = file-based only. Branches are the
  customers (PO# = `<branch>-<lot>`). Multi-org plant selection. Two-source pricing
  (Oracle buy items vs. admin-entered assembly tiers). Proposed stack pivot to
  **PHP 8 + MySQL on IIS** (retiring Node/Flask/React/SQLite as reference). MVP
  roadmap + decisions logged. Blocked on Matthew's OK + example export files.
- **2026-06-30** — Project Bible created. Documented current architecture (dual
  Node/Flask backends), data model, API surface, client pages, and loose pieces.
  Recorded open scope questions and AI orchestration working agreement.
