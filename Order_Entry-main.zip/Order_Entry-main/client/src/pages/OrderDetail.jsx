import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { api } from '../api';

const STATUS_BADGE = {
  Draft: 'badge-draft', Submitted: 'badge-submitted',
  Processing: 'badge-processing', Fulfilled: 'badge-fulfilled', Cancelled: 'badge-cancelled'
};

const STATUSES = ['Draft', 'Submitted', 'Processing', 'Fulfilled', 'Cancelled'];

export default function OrderDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);

  useEffect(() => { api.orders.get(id).then(setOrder).catch(console.error); }, [id]);

  const changeStatus = async (status) => {
    const updated = await api.orders.update(id, { ...order, status });
    setOrder(updated);
  };

  const handleDelete = async () => {
    if (!confirm('Delete this order?')) return;
    await api.orders.delete(id);
    navigate('/orders');
  };

  if (!order) return <div className="content"><div className="empty">Loading…</div></div>;

  return (
    <>
      <div className="topbar">
        <h1>Order #{order.id}</h1>
        <div className="actions">
          <Link to="/orders" className="btn btn-secondary">Back</Link>
          <Link to={`/orders/${id}/edit`} className="btn btn-secondary">Edit</Link>
          <button className="btn btn-danger" onClick={handleDelete}>Delete</button>
        </div>
      </div>
      <div className="content">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20 }}>
          <div>
            <div className="card">
              <h2 style={{ marginBottom: 16, fontSize: 15 }}>Line Items</h2>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr><th>Product</th><th>Qty</th><th>Unit Price</th><th>Subtotal</th></tr>
                  </thead>
                  <tbody>
                    {order.items?.map(item => (
                      <tr key={item.id}>
                        <td>{item.product_name}</td>
                        <td>{item.quantity}</td>
                        <td>${item.unit_price.toFixed(2)}</td>
                        <td>${(item.quantity * item.unit_price).toFixed(2)}</td>
                      </tr>
                    ))}
                    {(!order.items || order.items.length === 0) && (
                      <tr><td colSpan={4} className="empty">No items</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
              <div className="total-row">
                <span className="total-label">Total</span>
                <span className="total-value">${(order.total || 0).toFixed(2)}</span>
              </div>
            </div>
            {order.notes && (
              <div className="card mt-16">
                <h2 style={{ marginBottom: 8, fontSize: 15 }}>Notes</h2>
                <p style={{ color: '#555', lineHeight: 1.6 }}>{order.notes}</p>
              </div>
            )}
          </div>

          <div>
            <div className="card">
              <h2 style={{ marginBottom: 16, fontSize: 15 }}>Details</h2>
              <div className="form-group">
                <div className="form-label">Status</div>
                <span className={`badge ${STATUS_BADGE[order.status]}`}>{order.status}</span>
              </div>
              <div className="form-group">
                <div className="form-label">Change Status</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {STATUSES.filter(s => s !== order.status).map(s => (
                    <button key={s} className="btn btn-secondary btn-sm" onClick={() => changeStatus(s)}>{s}</button>
                  ))}
                </div>
              </div>
              <hr className="divider" />
              <div className="form-group">
                <div className="form-label">Customer</div>
                <div>{order.customer_name || <span className="text-muted">None</span>}</div>
                {order.customer_email && <div className="text-muted">{order.customer_email}</div>}
                {order.customer_phone && <div className="text-muted">{order.customer_phone}</div>}
                {order.customer_address && <div className="text-muted">{order.customer_address}</div>}
              </div>
              <hr className="divider" />
              <div className="form-group">
                <div className="form-label">Created</div>
                <div className="text-muted">{order.created_at?.slice(0, 16).replace('T', ' ')}</div>
              </div>
              <div className="form-group">
                <div className="form-label">Last Updated</div>
                <div className="text-muted">{order.updated_at?.slice(0, 16).replace('T', ' ')}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
