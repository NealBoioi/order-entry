import React, { useEffect, useState } from 'react';
import { api } from '../api';

const EMPTY = { name: '', description: '', unit_price: '', sku: '' };

export default function Products() {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState('');

  const load = () => api.products.list().then(setProducts);
  useEffect(() => { load(); }, []);

  const setField = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const openNew = () => { setEditing(null); setForm(EMPTY); setShowForm(true); setError(''); };
  const openEdit = (p) => { setEditing(p.id); setForm({ name: p.name, description: p.description || '', unit_price: p.unit_price, sku: p.sku || '' }); setShowForm(true); setError(''); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const payload = { ...form, unit_price: Number(form.unit_price) || 0 };
      if (editing) { await api.products.update(editing, payload); }
      else { await api.products.create(payload); }
      setShowForm(false);
      load();
    } catch (err) { setError(err.message); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete product?')) return;
    await api.products.delete(id);
    load();
  };

  return (
    <>
      <div className="topbar"><h1>Products</h1></div>
      <div className="content">
        {showForm && (
          <div className="card" style={{ marginBottom: 20 }}>
            <h2 style={{ marginBottom: 16, fontSize: 15 }}>{editing ? 'Edit Product' : 'New Product'}</h2>
            {error && <div style={{ color: '#c0392b', marginBottom: 12 }}>{error}</div>}
            <form onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Name *</label>
                  <input className="form-control" value={form.name} onChange={e => setField('name', e.target.value)} required />
                </div>
                <div className="form-group">
                  <label className="form-label">SKU</label>
                  <input className="form-control" value={form.sku} onChange={e => setField('sku', e.target.value)} placeholder="Optional" />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Unit Price</label>
                  <input className="form-control" type="number" min="0" step="0.01" value={form.unit_price} onChange={e => setField('unit_price', e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Description</label>
                  <input className="form-control" value={form.description} onChange={e => setField('description', e.target.value)} />
                </div>
              </div>
              <div className="actions">
                <button type="submit" className="btn btn-primary">{editing ? 'Save' : 'Add Product'}</button>
                <button type="button" className="btn btn-secondary" onClick={() => setShowForm(false)}>Cancel</button>
              </div>
            </form>
          </div>
        )}

        <div className="card">
          <div className="page-header" style={{ marginBottom: 16 }}>
            <h2>All Products</h2>
            {!showForm && <button className="btn btn-primary" onClick={openNew}>+ Add Product</button>}
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>Name</th><th>SKU</th><th>Unit Price</th><th>Description</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {products.map(p => (
                  <tr key={p.id}>
                    <td>{p.name}</td>
                    <td className="text-muted">{p.sku || '—'}</td>
                    <td>${(p.unit_price || 0).toFixed(2)}</td>
                    <td className="text-muted">{p.description || '—'}</td>
                    <td>
                      <div className="actions">
                        <button className="btn btn-secondary btn-sm" onClick={() => openEdit(p)}>Edit</button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDelete(p.id)}>Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
                {products.length === 0 && <tr><td colSpan={5} className="empty">No products yet</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}
