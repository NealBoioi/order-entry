import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';

const STATUS_BADGE = {
  Draft: 'badge-draft', Submitted: 'badge-submitted',
  Processing: 'badge-processing', Fulfilled: 'badge-fulfilled', Cancelled: 'badge-cancelled'
};

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [filter, setFilter] = useState('');

  useEffect(() => { api.orders.list().then(setOrders).catch(console.error); }, []);

  const filtered = filter ? orders.filter(o => o.status === filter) : orders;

  const handleDelete = async (id) => {
    if (!confirm('Delete this order?')) return;
    await api.orders.delete(id);
    setOrders(prev => prev.filter(o => o.id !== id));
  };

  return (
    <>
      <div className="topbar"><h1>Orders</h1></div>
      <div className="content">
        <div className="page-header">
          <div style={{ display: 'flex', gap: 8 }}>
            {['', 'Draft', 'Submitted', 'Processing', 'Fulfilled', 'Cancelled'].map(s => (
              <button key={s} className={`btn ${filter === s ? 'btn-primary' : 'btn-secondary'} btn-sm`} onClick={() => setFilter(s)}>
                {s || 'All'}
              </button>
            ))}
          </div>
          <Link to="/orders/new" className="btn btn-primary">+ New Order</Link>
        </div>
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>#</th><th>Customer</th><th>Status</th><th>Total</th><th>Date</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {filtered.map(o => (
                  <tr key={o.id}>
                    <td>#{o.id}</td>
                    <td>{o.customer_name || <span className="text-muted">—</span>}</td>
                    <td><span className={`badge ${STATUS_BADGE[o.status]}`}>{o.status}</span></td>
                    <td>${(o.total || 0).toFixed(2)}</td>
                    <td className="text-muted">{o.created_at?.slice(0, 10)}</td>
                    <td>
                      <div className="actions">
                        <Link to={`/orders/${o.id}`} className="btn btn-secondary btn-sm">View</Link>
                        <Link to={`/orders/${o.id}/edit`} className="btn btn-secondary btn-sm">Edit</Link>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDelete(o.id)}>Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && <tr><td colSpan={6} className="empty">No orders</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}
