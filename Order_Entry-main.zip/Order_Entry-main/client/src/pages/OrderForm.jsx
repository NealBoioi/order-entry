import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { api } from '../api';

const EMPTY_ITEM = { product_id: '', product_name: '', quantity: 1, unit_price: 0 };

export default function OrderForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({ customer_id: '', notes: '', status: 'Draft' });
  const [items, setItems] = useState([{ ...EMPTY_ITEM }]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.customers.list().then(setCustomers);
    api.products.list().then(setProducts);
    if (isEdit) {
      api.orders.get(id).then(order => {
        setForm({ customer_id: order.customer_id || '', notes: order.notes || '', status: order.status });
        setItems(order.items?.length ? order.items : [{ ...EMPTY_ITEM }]);
      });
    }
  }, [id]);

  const setField = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const setItem = (i, k, v) => setItems(prev => {
    const next = [...prev];
    next[i] = { ...next[i], [k]: v };
    if (k === 'product_id' && v) {
      const p = products.find(p => p.id === Number(v));
      if (p) { next[i].product_name = p.name; next[i].unit_price = p.unit_price; }
    }
    return next;
  });

  const addItem = () => setItems(prev => [...prev, { ...EMPTY_ITEM }]);
  const removeItem = (i) => setItems(prev => prev.filter((_, idx) => idx !== i));

  const total = items.reduce((s, item) => s + (Number(item.quantity) || 0) * (Number(item.unit_price) || 0), 0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const validItems = items.filter(i => i.product_name.trim());
    if (validItems.length === 0) { setError('Add at least one line item.'); return; }
    try {
      const payload = { ...form, customer_id: form.customer_id || null, items: validItems };
      if (isEdit) {
        await api.orders.update(id, payload);
        navigate(`/orders/${id}`);
      } else {
        const created = await api.orders.create(payload);
        navigate(`/orders/${created.id}`);
      }
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <>
      <div className="topbar">
        <h1>{isEdit ? 'Edit Order' : 'New Order'}</h1>
        <Link to={isEdit ? `/orders/${id}` : '/orders'} className="btn btn-secondary">Cancel</Link>
      </div>
      <div className="content">
        <form onSubmit={handleSubmit}>
          {error && <div style={{ color: '#c0392b', marginBottom: 16, padding: '10px 14px', background: '#fee', borderRadius: 6 }}>{error}</div>}

          <div className="card">
            <h2 style={{ marginBottom: 16, fontSize: 15 }}>Order Info</h2>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Customer</label>
                <select className="form-control" value={form.customer_id} onChange={e => setField('customer_id', e.target.value)}>
                  <option value="">— No customer —</option>
                  {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              {isEdit && (
                <div className="form-group">
                  <label className="form-label">Status</label>
                  <select className="form-control" value={form.status} onChange={e => setField('status', e.target.value)}>
                    {['Draft', 'Submitted', 'Processing', 'Fulfilled', 'Cancelled'].map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
              )}
            </div>
            <div className="form-group">
              <label className="form-label">Notes</label>
              <textarea className="form-control" rows={3} value={form.notes} onChange={e => setField('notes', e.target.value)} />
            </div>
          </div>

          <div className="card mt-16">
            <h2 style={{ marginBottom: 16, fontSize: 15 }}>Line Items</h2>
            <div className="table-wrap">
              <table className="items-table">
                <thead>
                  <tr><th>Product</th><th>Name</th><th>Qty</th><th>Unit Price</th><th>Subtotal</th><th></th></tr>
                </thead>
                <tbody>
                  {items.map((item, i) => (
                    <tr key={i}>
                      <td>
                        <select className="form-control" value={item.product_id} onChange={e => setItem(i, 'product_id', e.target.value)} style={{ minWidth: 120 }}>
                          <option value="">— Custom —</option>
                          {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                      </td>
                      <td>
                        <input className="form-control" value={item.product_name} onChange={e => setItem(i, 'product_name', e.target.value)} placeholder="Item name" required style={{ minWidth: 140 }} />
                      </td>
                      <td>
                        <input className="form-control" type="number" min="1" value={item.quantity} onChange={e => setItem(i, 'quantity', e.target.value)} style={{ width: 70 }} />
                      </td>
                      <td>
                        <input className="form-control" type="number" min="0" step="0.01" value={item.unit_price} onChange={e => setItem(i, 'unit_price', e.target.value)} style={{ width: 100 }} />
                      </td>
                      <td>${((Number(item.quantity) || 0) * (Number(item.unit_price) || 0)).toFixed(2)}</td>
                      <td>
                        {items.length > 1 && <button type="button" className="btn btn-danger btn-sm" onClick={() => removeItem(i)}>✕</button>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <button type="button" className="btn btn-secondary btn-sm mt-16" onClick={addItem}>+ Add Item</button>
            <div className="total-row">
              <span className="total-label">Total</span>
              <span className="total-value">${total.toFixed(2)}</span>
            </div>
          </div>

          <div className="mt-24 text-right">
            <button type="submit" className="btn btn-primary">{isEdit ? 'Save Changes' : 'Create Order'}</button>
          </div>
        </form>
      </div>
    </>
  );
}
