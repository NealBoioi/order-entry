import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';

const STATUS_BADGE = {
  Draft: 'badge-draft', Submitted: 'badge-submitted',
  Processing: 'badge-processing', Fulfilled: 'badge-fulfilled', Cancelled: 'badge-cancelled'
};

export default function Dashboard() {
  const [orders, setOrders] = useState([]);

  useEffect(() => { api.orders.list().then(setOrders).catch(console.error); }, []);

  const total = orders.reduce((s, o) => s + (o.total || 0), 0);
  const byStatus = (s) => orders.filter(o => o.status === s).length;

  return (
    <>
      <div className="topbar"><h1>Dashboard</h1></div>
      <div className="content">
        <div className="stats">
          <div className="stat-card"><div className="label">Total Orders</div><div className="value accent">{orders.length}</div></div>
          <div className="stat-card"><div className="label">Open Orders</div><div className="value">{byStatus('Draft') + byStatus('Submitted') + byStatus('Processing')}</div></div>
          <div className="stat-card"><div className="label">Fulfilled</div><div className="value">{byStatus('Fulfilled')}</div></div>
          <div className="stat-card"><div className="label">Revenue</div><div className="value">${total.toFixed(2)}</div></div>
        </div>

        <div className="card">
          <div className="page-header" style={{ marginBottom: 16 }}>
            <h2>Recent Orders</h2>
            <Link to="/orders/new" className="btn btn-primary">+ New Order</Link>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>#</th><th>Customer</th><th>Status</th><th>Total</th><th>Date</th><th></th></tr>
              </thead>
              <tbody>
                {orders.slice(0, 10).map(o => (
                  <tr key={o.id}>
                    <td>#{o.id}</td>
                    <td>{o.customer_name || <span className="text-muted">No customer</span>}</td>
                    <td><span className={`badge ${STATUS_BADGE[o.status]}`}>{o.status}</span></td>
                    <td>${(o.total || 0).toFixed(2)}</td>
                    <td className="text-muted">{o.created_at?.slice(0, 10)}</td>
                    <td><Link to={`/orders/${o.id}`} className="btn btn-secondary btn-sm">View</Link></td>
                  </tr>
                ))}
                {orders.length === 0 && <tr><td colSpan={6} className="empty">No orders yet</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}
