import sqlite3
import openpyxl
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, GradientFill
)
from openpyxl.utils import get_column_letter

DB_PATH = r"C:\Dev\Order Entry\server\orders.db"
OUT_PATH = r"C:\Dev\Order Entry\Schema Review.xlsx"

# ── colours ──────────────────────────────────────────────────────────────────
NAVY      = "1A1A2E"
BLUE      = "6C8EF5"
LIGHTBLUE = "E8F0FE"
GREEN     = "27AE60"
LIGHTGRN  = "E6F9F0"
ORANGE    = "E67E22"
LIGHTOR   = "FFF3E0"
RED       = "C0392B"
LIGHTRED  = "FEE8E8"
GREY      = "F5F6FA"
WHITE     = "FFFFFF"
MIDGREY   = "D8DAE8"

def fill(hex_): return PatternFill("solid", fgColor=hex_)
def font(hex_="000000", bold=False, sz=11):
    return Font(color=hex_, bold=bold, size=sz, name="Segoe UI")
def border():
    s = Side(style="thin", color=MIDGREY)
    return Border(left=s, right=s, top=s, bottom=s)
def center(): return Alignment(horizontal="center", vertical="center", wrap_text=True)
def left():   return Alignment(horizontal="left",   vertical="center", wrap_text=True)

def hdr_cell(ws, row, col, value, bg=NAVY, fg=WHITE, bold=True, sz=11):
    c = ws.cell(row=row, column=col, value=value)
    c.fill = fill(bg); c.font = font(fg, bold, sz)
    c.alignment = center(); c.border = border()
    return c

def data_cell(ws, row, col, value, bg=WHITE, fg="000000", bold=False, align=left):
    c = ws.cell(row=row, column=col, value=value)
    c.fill = fill(bg); c.font = font(fg, bold)
    c.alignment = align(); c.border = border()
    return c

# ── read schema from sqlite ───────────────────────────────────────────────────
conn = sqlite3.connect(DB_PATH)
tables = [r[0] for r in conn.execute(
    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
).fetchall()]

schema = {}
for tbl in tables:
    cols = conn.execute(f"PRAGMA table_info({tbl})").fetchall()
    fks  = conn.execute(f"PRAGMA foreign_key_list({tbl})").fetchall()
    fk_cols = {fk[3]: f"→ {fk[2]}.{fk[4]}" for fk in fks}
    schema[tbl] = [
        {
            "cid": c[0], "name": c[1], "type": c[2],
            "notnull": bool(c[3]), "default": c[4], "pk": bool(c[5]),
            "fk": fk_cols.get(c[1], "")
        }
        for c in cols
    ]
conn.close()

wb = openpyxl.Workbook()
wb.remove(wb.active)   # remove default sheet

# ═══════════════════════════════════════════════════════════════════════════════
# SHEET 1 – Current Schema
# ═══════════════════════════════════════════════════════════════════════════════
ws = wb.create_sheet("Current Schema")
ws.sheet_view.showGridLines = False
ws.freeze_panes = "A3"

# Title row
ws.merge_cells("A1:H1")
t = ws.cell(row=1, column=1, value="Order Entry – Database Schema")
t.font = Font(name="Segoe UI", bold=True, size=14, color=WHITE)
t.fill = fill(NAVY); t.alignment = center()

# Column headers (row 2)
headers = ["Table", "Column", "Data Type", "Primary Key", "Not Null", "Default", "Foreign Key", "Notes"]
widths  = [18,       22,       14,          12,            10,         14,        24,             40]
for i, (h, w) in enumerate(zip(headers, widths), 1):
    hdr_cell(ws, 2, i, h, bg=BLUE)
    ws.column_dimensions[get_column_letter(i)].width = w
ws.row_dimensions[1].height = 28
ws.row_dimensions[2].height = 22

row = 3
TABLE_NOTES = {
    "customers":   "Stores customer master data",
    "products":    "Product/item catalogue with pricing",
    "orders":      "Sales order header",
    "order_items": "Line items belonging to an order",
}
COL_NOTES = {
    ("customers",   "id"):          "Auto-generated unique ID",
    ("customers",   "name"):        "Customer/company name",
    ("customers",   "email"):       "Primary email address",
    ("customers",   "phone"):       "Primary phone number",
    ("customers",   "address"):     "Single-field address (see gap analysis)",
    ("products",    "unit_price"):  "Base price – no tier support yet (see gap analysis)",
    ("products",    "sku"):         "Stock-keeping unit identifier",
    ("orders",      "status"):      "Draft | Submitted | Processing | Fulfilled | Cancelled",
    ("order_items", "unit_price"):  "Price at time of order (snapshot)",
    ("order_items", "quantity"):    "No UOM field yet (see gap analysis)",
}

for tbl in tables:
    cols = schema[tbl]
    tbl_bg = LIGHTBLUE if tables.index(tbl) % 2 == 0 else GREY

    for ci, col in enumerate(cols):
        bg = tbl_bg
        # PK rows slightly different shade
        if col["pk"]:   bg = "DCE8FF"

        data_cell(ws, row, 1, tbl if ci == 0 else "",
                  bg=NAVY if ci == 0 else "2A2A4E",
                  fg=WHITE, bold=(ci==0), align=center)
        data_cell(ws, row, 2, col["name"],    bg=bg)
        data_cell(ws, row, 3, col["type"] or "TEXT", bg=bg, align=center)
        data_cell(ws, row, 4, "✓" if col["pk"] else "",   bg=bg, fg=BLUE if col["pk"] else "000000", align=center)
        data_cell(ws, row, 5, "✓" if col["notnull"] else "", bg=bg, align=center)
        data_cell(ws, row, 6, str(col["default"]) if col["default"] is not None else "", bg=bg, align=center)
        data_cell(ws, row, 7, col["fk"], bg=bg, fg=GREEN if col["fk"] else "000000")
        note = COL_NOTES.get((tbl, col["name"]), TABLE_NOTES.get(tbl, "") if ci == 0 else "")
        data_cell(ws, row, 8, note, bg=bg, fg="555555")
        ws.row_dimensions[row].height = 18
        row += 1

    # blank spacer row between tables
    for c in range(1, 9):
        ws.cell(row=row, column=c).fill = fill(WHITE)
    row += 1


# ═══════════════════════════════════════════════════════════════════════════════
# SHEET 2 – Gap Analysis
# ═══════════════════════════════════════════════════════════════════════════════
ws2 = wb.create_sheet("Gap Analysis")
ws2.sheet_view.showGridLines = False

ws2.merge_cells("A1:G1")
t2 = ws2.cell(row=1, column=1, value="Gap Analysis – Features Needed vs Current Schema")
t2.font = Font(name="Segoe UI", bold=True, size=14, color=WHITE)
t2.fill = fill(NAVY); t2.alignment = center()
ws2.row_dimensions[1].height = 28

h2 = ["Feature Area", "Status", "Table(s) Affected", "Missing Column(s)", "Suggested Type", "Priority", "Notes"]
w2 = [22, 13, 22, 30, 18, 11, 45]
for i, (h, w) in enumerate(zip(h2, w2), 1):
    hdr_cell(ws2, 2, i, h, bg=BLUE)
    ws2.column_dimensions[get_column_letter(i)].width = w
ws2.row_dimensions[2].height = 22

STATUS_STYLE = {
    "Missing":      (LIGHTRED,  RED,    "Missing"),
    "Partial":      (LIGHTOR,   ORANGE, "Partial"),
    "Supported":    (LIGHTGRN,  GREEN,  "Supported"),
}

gaps = [
    # (Feature Area, Status, Tables, Missing Columns, Suggested Type, Priority, Notes)
    ("Tiered Pricing",
     "Missing",
     "products",
     "price_tiers table: min_qty, max_qty, unit_price, customer_group",
     "New table (INTEGER / REAL)",
     "High",
     "Needs a separate price_tiers table linked to products. Can also link to customer groups for customer-specific pricing."),

    ("Unit of Measure (UOM)",
     "Missing",
     "products, order_items",
     "uom (e.g. EA, BOX, KG, LB, FT)",
     "TEXT",
     "High",
     "Add uom to products as default. Copy to order_items at order time so it is preserved as a snapshot."),

    ("Customer Contact Info",
     "Partial",
     "customers",
     "contact_first_name, contact_last_name, contact_email, contact_phone, contact_title",
     "TEXT",
     "Medium",
     "Current schema has a single email/phone. Add structured contact fields or a separate contacts table for multiple contacts per customer."),

    ("Structured Address",
     "Missing",
     "customers, orders",
     "street, city, state, zip, country (billing & shipping)",
     "TEXT",
     "Medium",
     "Current address is a single text field. Split into components and add separate shipping address on the order."),

    ("Customer Groups / Pricing Tiers",
     "Missing",
     "customers",
     "customer_group (e.g. Retail, Wholesale, VIP)",
     "TEXT or FK to groups table",
     "High",
     "Required to drive tiered/customer-specific pricing. Add a customer_groups table and link customers to it."),

    ("Tax",
     "Missing",
     "products, orders, order_items",
     "tax_rate, tax_amount, is_taxable",
     "REAL / INTEGER (bool)",
     "Medium",
     "No tax fields exist. Add is_taxable to products, tax_rate to orders, and tax_amount to order_items."),

    ("Discount",
     "Missing",
     "orders, order_items",
     "discount_pct, discount_amt",
     "REAL",
     "Medium",
     "Support line-level and order-level discounts."),

    ("Currency",
     "Missing",
     "orders, products",
     "currency_code (e.g. USD, EUR)",
     "TEXT (3-char ISO)",
     "Low",
     "Needed for multi-currency support. Default USD if single-currency."),

    ("Order Number / Reference",
     "Missing",
     "orders",
     "order_number (human-readable), po_number (customer's PO ref)",
     "TEXT",
     "High",
     "Auto-generate a readable order number (e.g. ORD-2026-00001) separate from the database id."),

    ("Multiple Contacts per Customer",
     "Missing",
     "customers",
     "New table: contacts (customer_id, first_name, last_name, email, phone, title, is_primary)",
     "New table",
     "Medium",
     "Allows multiple contacts per account (billing, shipping, sales rep, etc.)."),

    ("Shipping / Delivery Info",
     "Missing",
     "orders",
     "ship_to_name, ship_address, ship_city, ship_state, ship_zip, ship_country, shipping_method, tracking_number",
     "TEXT",
     "Medium",
     "No shipping info on the order header currently."),

    ("Order Terms / Payment",
     "Missing",
     "orders",
     "payment_terms (e.g. Net 30), due_date",
     "TEXT / DATE",
     "Low",
     "Add payment terms and due date to order header."),

    ("Product Categories",
     "Missing",
     "products",
     "category_id → categories table",
     "INTEGER (FK)",
     "Low",
     "Group products into categories for filtering/reporting."),

    ("Inventory / Stock",
     "Missing",
     "products",
     "stock_qty, reorder_point",
     "INTEGER",
     "Low",
     "Basic stock tracking. Larger scope — flag for future phase."),

    ("Audit / Created By",
     "Missing",
     "orders, customers, products",
     "created_by, updated_by",
     "TEXT (username)",
     "Low",
     "Track which user created/modified records. Needed if multi-user."),
]

row2 = 3
for feature, status, tables, missing, dtype, priority, notes in gaps:
    bg, fg, label = STATUS_STYLE[status]
    data_cell(ws2, row2, 1, feature,  bg=GREY, bold=True)
    c = ws2.cell(row=row2, column=2, value=label)
    c.fill = fill(bg); c.font = font(fg, True); c.alignment = center(); c.border = border()
    data_cell(ws2, row2, 3, tables,   bg=GREY)
    data_cell(ws2, row2, 4, missing,  bg=WHITE)
    data_cell(ws2, row2, 5, dtype,    bg=WHITE, align=center)
    pri_bg = {"High": LIGHTRED, "Medium": LIGHTOR, "Low": LIGHTGRN}[priority]
    pri_fg = {"High": RED,      "Medium": ORANGE,  "Low": GREEN}[priority]
    c2 = ws2.cell(row=row2, column=6, value=priority)
    c2.fill = fill(pri_bg); c2.font = font(pri_fg, True); c2.alignment = center(); c2.border = border()
    data_cell(ws2, row2, 7, notes, bg=WHITE, fg="555555")
    ws2.row_dimensions[row2].height = 42
    row2 += 1

# ═══════════════════════════════════════════════════════════════════════════════
# SHEET 3 – Proposed Schema
# ═══════════════════════════════════════════════════════════════════════════════
ws3 = wb.create_sheet("Proposed Schema")
ws3.sheet_view.showGridLines = False

ws3.merge_cells("A1:G1")
t3 = ws3.cell(row=1, column=1, value="Proposed Full Schema (Current + Recommended Additions)")
t3.font = Font(name="Segoe UI", bold=True, size=14, color=WHITE)
t3.fill = fill(NAVY); t3.alignment = center()
ws3.row_dimensions[1].height = 28

h3 = ["Table", "Column", "Type", "PK", "Not Null", "Foreign Key", "Description"]
w3 = [22, 28, 18, 8, 10, 26, 50]
for i, (h, w) in enumerate(zip(h3, w3), 1):
    hdr_cell(ws3, 2, i, h, bg=BLUE)
    ws3.column_dimensions[get_column_letter(i)].width = w
ws3.row_dimensions[2].height = 22

proposed = [
    # (table, column, type, pk, notnull, fk, description, is_new)
    # ── customer_groups ──────────────────────────────────────────────────────
    ("customer_groups", "id",          "INTEGER", True,  True,  "",                     "Auto PK", False),
    ("customer_groups", "name",        "TEXT",    False, True,  "",                     "e.g. Retail, Wholesale, VIP", True),
    ("customer_groups", "description", "TEXT",    False, False, "",                     "Optional description", True),
    # ── customers ────────────────────────────────────────────────────────────
    ("customers", "id",                "INTEGER", True,  True,  "",                     "Auto PK", False),
    ("customers", "name",              "TEXT",    False, True,  "",                     "Company / customer name", False),
    ("customers", "customer_group_id", "INTEGER", False, False, "→ customer_groups.id", "Links to pricing tier group", True),
    ("customers", "email",             "TEXT",    False, False, "",                     "Primary email", False),
    ("customers", "phone",             "TEXT",    False, False, "",                     "Primary phone", False),
    ("customers", "bill_street",       "TEXT",    False, False, "",                     "Billing street", True),
    ("customers", "bill_city",         "TEXT",    False, False, "",                     "Billing city", True),
    ("customers", "bill_state",        "TEXT",    False, False, "",                     "Billing state / province", True),
    ("customers", "bill_zip",          "TEXT",    False, False, "",                     "Billing postal code", True),
    ("customers", "bill_country",      "TEXT",    False, False, "",                     "Billing country (default USA)", True),
    ("customers", "payment_terms",     "TEXT",    False, False, "",                     "e.g. Net 30, COD, Prepaid", True),
    ("customers", "created_at",        "TEXT",    False, False, "",                     "Timestamp", False),
    # ── contacts ─────────────────────────────────────────────────────────────
    ("contacts", "id",          "INTEGER", True,  True,  "",               "Auto PK", True),
    ("contacts", "customer_id", "INTEGER", False, True,  "→ customers.id", "Parent customer", True),
    ("contacts", "first_name",  "TEXT",    False, True,  "",               "Contact first name", True),
    ("contacts", "last_name",   "TEXT",    False, False, "",               "Contact last name", True),
    ("contacts", "title",       "TEXT",    False, False, "",               "Job title", True),
    ("contacts", "email",       "TEXT",    False, False, "",               "Contact email", True),
    ("contacts", "phone",       "TEXT",    False, False, "",               "Contact phone", True),
    ("contacts", "is_primary",  "INTEGER", False, False, "",               "1 = primary contact", True),
    # ── products ─────────────────────────────────────────────────────────────
    ("products", "id",          "INTEGER", True,  True,  "",              "Auto PK", False),
    ("products", "name",        "TEXT",    False, True,  "",              "Product name", False),
    ("products", "description", "TEXT",    False, False, "",              "Description", False),
    ("products", "sku",         "TEXT",    False, False, "",              "Unique SKU", False),
    ("products", "uom",         "TEXT",    False, False, "",              "Unit of measure: EA, BOX, LB, KG, FT…", True),
    ("products", "unit_price",  "REAL",    False, True,  "",              "Base / list price", False),
    ("products", "is_taxable",  "INTEGER", False, False, "",              "1 = taxable, 0 = exempt", True),
    ("products", "category_id", "INTEGER", False, False, "→ categories.id","Optional product category", True),
    ("products", "created_at",  "TEXT",    False, False, "",              "Timestamp", False),
    # ── price_tiers ──────────────────────────────────────────────────────────
    ("price_tiers", "id",               "INTEGER", True,  True,  "",                     "Auto PK", True),
    ("price_tiers", "product_id",       "INTEGER", False, True,  "→ products.id",        "Which product", True),
    ("price_tiers", "customer_group_id","INTEGER", False, False, "→ customer_groups.id", "NULL = applies to all groups", True),
    ("price_tiers", "min_qty",          "INTEGER", False, True,  "",                     "Min quantity for this tier", True),
    ("price_tiers", "max_qty",          "INTEGER", False, False, "",                     "Max quantity (NULL = unlimited)", True),
    ("price_tiers", "unit_price",       "REAL",    False, True,  "",                     "Price at this tier", True),
    # ── categories ───────────────────────────────────────────────────────────
    ("categories", "id",   "INTEGER", True,  True,  "", "Auto PK", True),
    ("categories", "name", "TEXT",    False, True,  "", "Category name", True),
    # ── orders ───────────────────────────────────────────────────────────────
    ("orders", "id",              "INTEGER", True,  True,  "",               "Auto PK", False),
    ("orders", "order_number",    "TEXT",    False, False, "",               "Human-readable: ORD-2026-00001", True),
    ("orders", "customer_id",     "INTEGER", False, False, "→ customers.id", "Customer", False),
    ("orders", "contact_id",      "INTEGER", False, False, "→ contacts.id",  "Specific contact for this order", True),
    ("orders", "status",          "TEXT",    False, True,  "",               "Draft|Submitted|Processing|Fulfilled|Cancelled", False),
    ("orders", "po_number",       "TEXT",    False, False, "",               "Customer's purchase order reference", True),
    ("orders", "currency_code",   "TEXT",    False, False, "",               "ISO currency: USD, EUR…", True),
    ("orders", "tax_rate",        "REAL",    False, False, "",               "Tax % applied to order", True),
    ("orders", "discount_pct",    "REAL",    False, False, "",               "Order-level discount %", True),
    ("orders", "payment_terms",   "TEXT",    False, False, "",               "e.g. Net 30", True),
    ("orders", "due_date",        "TEXT",    False, False, "",               "Payment due date", True),
    ("orders", "ship_to_name",    "TEXT",    False, False, "",               "Ship-to contact name", True),
    ("orders", "ship_street",     "TEXT",    False, False, "",               "Shipping street", True),
    ("orders", "ship_city",       "TEXT",    False, False, "",               "Shipping city", True),
    ("orders", "ship_state",      "TEXT",    False, False, "",               "Shipping state", True),
    ("orders", "ship_zip",        "TEXT",    False, False, "",               "Shipping postal code", True),
    ("orders", "ship_country",    "TEXT",    False, False, "",               "Shipping country", True),
    ("orders", "shipping_method", "TEXT",    False, False, "",               "e.g. UPS Ground, FedEx, Pickup", True),
    ("orders", "tracking_number", "TEXT",    False, False, "",               "Carrier tracking number", True),
    ("orders", "notes",           "TEXT",    False, False, "",               "Internal notes", False),
    ("orders", "created_at",      "TEXT",    False, False, "",               "Timestamp", False),
    ("orders", "updated_at",      "TEXT",    False, False, "",               "Last update timestamp", False),
    # ── order_items ──────────────────────────────────────────────────────────
    ("order_items", "id",           "INTEGER", True,  True,  "",               "Auto PK", False),
    ("order_items", "order_id",     "INTEGER", False, True,  "→ orders.id",    "Parent order (cascade delete)", False),
    ("order_items", "product_id",   "INTEGER", False, False, "→ products.id",  "Linked product (optional)", False),
    ("order_items", "product_name", "TEXT",    False, True,  "",               "Snapshot of product name", False),
    ("order_items", "uom",          "TEXT",    False, False, "",               "Snapshot of UOM at order time", True),
    ("order_items", "quantity",     "INTEGER", False, True,  "",               "Quantity ordered", False),
    ("order_items", "unit_price",   "REAL",    False, True,  "",               "Snapshot of price at order time", False),
    ("order_items", "discount_pct", "REAL",    False, False, "",               "Line-level discount %", True),
    ("order_items", "tax_amount",   "REAL",    False, False, "",               "Calculated tax for this line", True),
]

row3 = 3
prev_tbl = None
for rec in proposed:
    tbl, col, dtype, pk, notnull, fk, desc, is_new = rec
    ci = [r[0] for r in proposed].index(tbl) if tbl != prev_tbl else -1
    is_first = tbl != prev_tbl
    prev_tbl = tbl

    row_bg = LIGHTGRN if is_new else WHITE

    data_cell(ws3, row3, 1, tbl if is_first else "",
              bg=NAVY if is_first else "2A2A4E", fg=WHITE, bold=is_first, align=center)
    data_cell(ws3, row3, 2, col,   bg=row_bg)
    data_cell(ws3, row3, 3, dtype, bg=row_bg, align=center)
    data_cell(ws3, row3, 4, "✓" if pk     else "", bg=row_bg, fg=BLUE,  align=center)
    data_cell(ws3, row3, 5, "✓" if notnull else "", bg=row_bg, align=center)
    data_cell(ws3, row3, 6, fk,   bg=row_bg, fg=GREEN if fk else "000000")
    data_cell(ws3, row3, 7, desc, bg=row_bg, fg="555555")
    ws3.row_dimensions[row3].height = 18
    row3 += 1

    if is_first:
        pass  # no spacer before first col of table

# Legend row
row3 += 1
ws3.merge_cells(f"A{row3}:G{row3}")
leg = ws3.cell(row=row3, column=1, value="  Green rows = new columns recommended to be added    |    White rows = already exists in current schema")
leg.fill = fill(GREY); leg.font = Font(name="Segoe UI", italic=True, size=10, color="555555")
leg.alignment = left()

wb.save(OUT_PATH)
print(f"Saved: {OUT_PATH}")
