Dim shell
Set shell = CreateObject("WScript.Shell")

' Start the Flask server silently (no console window)
shell.Run "python ""C:\Dev\Order Entry\server\app.py""", 0, False

' Give the server a moment to start
WScript.Sleep 2500

' Open the browser
shell.Run "http://localhost:5000"
