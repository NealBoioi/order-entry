# Order Entry — working guide for Claude

## 1. Read the Bible first — every session
**Before doing any work, read `PROJECT_BIBLE.md`.** It is the single source of truth: scope,
architecture, domain rules (branches-as-customers, PO# format, two-source pricing, customer
visibility rules), decisions log, and a full changelog. Skim the front-matter status snapshot,
then read the §sections relevant to whatever you're about to touch. Don't infer domain behavior
from code alone when the Bible states it.

## 2. Keep the Bible current — every change
Updating `PROJECT_BIBLE.md` is part of "done", not an afterthought. When you make any material
change, before you finish:
1. Update the relevant **§section** so it matches reality (mark superseded pieces).
2. Add a dated entry to the **Changelog** at the bottom (newest first): what changed and why.
A change isn't complete until the Bible reflects it.

## 3. The app
- **Live app = server-rendered PHP 8.3 + MariaDB/MySQL under `app/`** (webroot `app/public/`).
- `client/` and `server/` are the **retired** React/Node/Flask prototype — reference only, never live.
- Repo: private GitHub `MatteoZoid/Order_Entry`. Commit/push only when asked; branch off before committing.

## 4. Local dev on this Mac
- Toolchain (Homebrew, no-admin): **`php@8.3`** at `/opt/homebrew/opt/php@8.3/bin/php` (keg-only, not
  linked — use the full path or `run-dev.sh`); **`mariadb`** via `brew services`.
- MariaDB auth: connect as your **OS user** (`/opt/homebrew/opt/mariadb/bin/mariadb …`); Homebrew
  rejects `root` unless via sudo. DB `order_entry`, app user `oe_app` / `oe_app_dev_pw`.
- Config: `app/config/config.php` (committed to the repo; holds a **live Gmail app password**, so
  mail is set **OFF** on this box — notifications only log). Don't turn mail on casually.
- **Run it:** `./run-dev.sh` → http://127.0.0.1:8000/login.php · admin login `admin@example.com` / `OrderEntry2026`.
- Data: `php app/bin/migrate.php` (schema), `php app/bin/load_snapshot.php` (shared data),
  `php app/bin/seed_demo.php` (export-free demo rows).
- Lint PHP before finishing: `/opt/homebrew/opt/php@8.3/bin/php -l <file>`.

## 5. Conventions
- **Verify by running the app** (preview tools / a click-through), not just by reading code.
- The `php -S` dev server is **single-threaded** — a slow upstream (e.g. address geocoding) briefly
  blocks it; that's a dev-only artifact, fine on the prod IIS/FPM host.
- Never commit real company data; keep exports in `import_dir` (outside the repo).
